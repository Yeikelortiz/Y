-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-09-2026 a las 17:56:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencias`
--

CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `estado` enum('Presente','Ausente','Justificado','Tardanza') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencias_momento`
-- (asistencia por momento académico: totales de asistencias e inasistencias por estudiante)
--

CREATE TABLE `asistencias_momento` (
  `id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `momento_id` int(11) NOT NULL,
  `asistencias` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Días asistidos en el momento',
  `inasistencias` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Días de inasistencia en el momento',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora`
--

CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre_usuario` varchar(100) NOT NULL,
  `rol_usuario` varchar(50) NOT NULL,
  `accion` varchar(50) NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bitacora`
--

INSERT INTO `bitacora` (`id`, `usuario_id`, `nombre_usuario`, `rol_usuario`, `accion`, `modulo`, `descripcion`, `ip`, `fecha_registro`) VALUES
(1, 6, 'Beikel ortiz', 'admin', 'INICIO_SESION', 'Autenticación', 'El usuario Beikel ortiz (admin) inició sesión correctamente.', '::1', '2026-09-24 02:37:10'),
(2, 6, 'Beikel ortiz', 'admin', 'CIERRE_SESION', 'Autenticación', 'El usuario cerró sesión en el sistema.', '::1', '2026-09-24 02:37:40'),
(3, 6, 'Beikel ortiz', 'admin', 'INICIO_SESION', 'Autenticación', 'El usuario Beikel ortiz (admin) inició sesión correctamente.', '::1', '2026-09-24 02:44:45'),
(4, 1, 'Administrador Test', 'admin', 'PRUEBA', 'Bitácora', 'Registro de prueba manual para verificar vista', '127.0.0.1', '2026-09-24 03:00:10'),
(5, 6, 'Beikel ortiz', 'admin', 'CIERRE_SESION', 'Autenticación', 'El usuario cerró sesión en el sistema.', '::1', '2026-09-24 03:28:21'),
(6, 1, 'Juan Pérez', 'secretaria', 'INICIO_SESION', 'Autenticación', 'El usuario Juan Pérez (secretaria) inició sesión correctamente.', '::1', '2026-09-24 03:28:40'),
(7, 1, 'Juan Pérez', 'secretaria', 'CIERRE_SESION', 'Autenticación', 'El usuario cerró sesión en el sistema.', '::1', '2026-09-24 03:28:43'),
(8, 6, 'Beikel ortiz', 'admin', 'INICIO_SESION', 'Autenticación', 'El usuario Beikel ortiz (admin) inició sesión correctamente.', '::1', '2026-09-24 03:29:04'),
(9, 6, 'Beikel ortiz', 'admin', 'INICIO_SESION', 'Autenticación', 'El usuario Beikel ortiz (admin) inició sesión correctamente.', '::1', '2026-09-25 00:16:52'),
(10, 6, 'Beikel ortiz', 'admin', 'INICIO_SESION', 'Autenticación', 'El usuario Beikel ortiz (admin) inició sesión correctamente.', '::1', '2026-09-26 15:00:46'),
(11, 6, 'Beikel ortiz', 'admin', 'CIERRE_SESION', 'Autenticación', 'El usuario cerró sesión en el sistema.', '::1', '2026-09-26 15:42:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificaciones`
--

CREATE TABLE `calificaciones` (
  `id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `momento_id` int(11) NOT NULL COMMENT '1er, 2do o 3er Momento',
  `literal_o_estado` enum('Aprobado','Reprobado') NOT NULL,
  `descripcion_desempeno` text NOT NULL COMMENT 'Descripción cualitativa del desempeño del alumno',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docentes`
--

CREATE TABLE `docentes` (
  `id` int(11) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` enum('M','F','Otro') NOT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE `estudiantes` (
  `id` int(11) NOT NULL,
  `cedula_escolar` varchar(160) NOT NULL,
  `nombres` varchar(150) NOT NULL,
  `apellidos` varchar(150) NOT NULL,
  `representante_cedula` varchar(150) NOT NULL,
  `registrado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_nacimiento` date NOT NULL,
  `genero` enum('M','F','Otro') NOT NULL,
  `seccion_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`id`, `cedula_escolar`, `nombres`, `apellidos`, `representante_cedula`, `registrado_en`, `fecha_nacimiento`, `genero`, `seccion_id`) VALUES
(1, '31022149-1', 'yeikel', 'ortiz', '31022149', '2026-09-14 02:10:23', '0000-00-00', 'M', NULL),
(2, '31022149-2', 'yeikel', 'ortiz', '31022149', '2026-09-14 02:11:47', '0000-00-00', 'M', NULL),
(3, '31022192-1', 'Diego', 'perez', '31022192', '2026-09-14 02:13:54', '0000-00-00', 'M', NULL),
(4, '22423425-1', 'Julio', 'Ortega', '22423425', '2026-09-14 02:42:12', '0000-00-00', 'M', NULL),
(7, '222323222-1', 'Diego', 'LOPEZ', '222323222', '2026-09-15 01:24:00', '0000-00-00', 'M', NULL),
(8, '2231313-1', 'Julio', 'linares', '2231313', '2026-09-20 17:52:20', '0000-00-00', 'M', NULL),
(9, '312121313-1', 'yeikel', 'alfonso', '312121313', '2026-09-20 22:19:59', '0000-00-00', 'M', NULL),
(12, '312121313-3', 'yeikelñ', 'alfonso', '312121313', '2026-09-21 00:10:08', '0000-00-00', 'M', NULL),
(16, '232322232-1', 'Luis Alfons', 'Yeikel Ortiz', '232322232', '2026-09-25 02:19:45', '2026-09-11', 'F', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `momentos_academicos`
--

CREATE TABLE `momentos_academicos` (
  `id` int(11) NOT NULL,
  `periodo_id` int(11) NOT NULL COMMENT 'Año escolar al que pertenece',
  `nombre` varchar(50) NOT NULL COMMENT 'Ej: 1er Momento, 2do Momento, 3er Momento',
  `estado` enum('activo','cerrado') NOT NULL DEFAULT 'activo' COMMENT 'RF-10: Cierre por el Director',
  `fecha_cierre` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periodos`
--

CREATE TABLE `periodos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `estado` enum('activo','cerrado') NOT NULL DEFAULT 'activo',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representantes`
--

CREATE TABLE `representantes` (
  `cedula` varchar(150) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` text DEFAULT NULL,
  `num_hijo` int(2) NOT NULL,
  `registrado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `representantes`
--

INSERT INTO `representantes` (`cedula`, `nombre`, `apellido`, `telefono`, `direccion`, `num_hijo`, `registrado_en`) VALUES
('222323222', 'Ezequiel', 'Mateos', '04244940533', 'tocuyito', 1, '2026-09-15 01:24:00'),
('2231313', 'luis', 'perez', '042453563763', '23', 1, '2026-09-20 17:52:20'),
('22423425', 'Maria', 'renfigo', '04244939339', 'zocorro', 1, '2026-09-14 02:42:12'),
('2322233', 'luis', 'alfonso', '04244955142', 'san luis', 1, '2026-09-14 03:25:44'),
('23222334', 'luis', 'Reyes', '0524256536363', '2', 1, '2026-09-20 23:48:19'),
('232322232', 'Ezequiel', 'alfonso', '042449551423', 'aasss', 1, '2026-09-25 02:19:45'),
('31022149', 'Ezequiel', 'Ortiz', '04244940553', 'tocuyito', 2, '2026-09-14 02:10:23'),
('31022192', 'luis', 'sss', '04242526373', 'safari', 2, '2026-09-14 02:13:54'),
('312121313', 'Ezequiel', 'alfonso', '015425533626', '2', 6, '2026-09-20 22:19:59'),
('[31022149]', '[Yeikel]', '[Ortiz]', '[04244940553]', '[urbanizacion valles de san francisco]', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secciones`
--

CREATE TABLE `secciones` (
  `id` int(11) NOT NULL,
  `periodo_id` int(11) NOT NULL,
  `grado` tinyint(4) NOT NULL CHECK (`grado` between 1 and 6),
  `seccion` char(1) NOT NULL CHECK (`seccion` in ('A','B')),
  `docente_id` int(11) NOT NULL COMMENT 'Profesor guía o titular de la sección',
  `aula` varchar(30) DEFAULT NULL,
  `horario` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','director','secretaria') NOT NULL,
  `intentos_fallidos` int(11) DEFAULT 0,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultima_sesion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `rol`, `intentos_fallidos`, `bloqueado_hasta`, `created_at`, `ultima_sesion`) VALUES
(1, 'Juan Pérez', 'usuario@test.com', '$2y$10$tt2eTmFoeAObz.4BYnoIZOtC44zFXrJOz28gtalju7XE.mktyXaze', 'secretaria', 0, NULL, '2026-08-23 20:04:30', NULL),
(5, 'Yeikel Ortiz', 'beikel@gmail.com', '$2y$10$NnYfwIDTK8pJ.glv2WQIk.UjmaRnFmWD5LAhnYh39X1oG3Di6yQxe', 'secretaria', 0, NULL, '2026-08-25 00:46:07', NULL),
(6, 'Beikel ortiz', 'beikel.13@gmail.com', '$2y$10$.wscOZ58aYLF4qiyKrRTMuiv9uJPHcgKJGzRVasBTv2nJlQD5liJO', 'admin', 0, NULL, '2026-08-25 01:03:54', NULL),
(7, 'Beikel ortiz', 'tt@gmail.com', '$2y$10$PzVS8mG.0KPqrb067umhCOLdO7gJVRNTdzN6BG/Y8czSGeywzbsMu', 'director', 0, NULL, '2026-08-25 01:44:00', NULL),
(8, 'Yeikel Ortiz', 'yeikel@gmail.com', '$2y$10$jvxtH/wnR2KvO2dFqxcDNuo8zhCOe./WuXZ2xef8AgYQwBW0u726i', 'director', 0, NULL, '2026-09-13 15:03:47', NULL),
(10, 'Juan Isaac', 'juan@gmail.com', '$2y$10$4YsgNHECrHcaLJxxUCjZKO12WJtOia.ZusbcFTJwDkWg0yplrqNVi', 'admin', 0, NULL, '2026-09-21 02:43:02', NULL),
(11, 'Angel Jesus', 'angel@gmail.com', '$2y$10$7LZbA6WoSIKED92LN4t0luKVUH8k.XLZjsFPgQe9q63tvCfw8MIc2', 'director', 0, NULL, '2026-09-21 02:44:43', NULL),
(12, 'Carlos', 'Carlos@gmail.com', '$2y$10$bHuILfT5J2g5rIt0e7dmfODXoypej4axeRFwYLtUWVzBPnYgZQZ.2', 'secretaria', 0, NULL, '2026-09-21 02:49:56', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asistencias`
--
ALTER TABLE `asistencias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_asistencia_estudiante_fecha` (`estudiante_id`,`fecha`),
  ADD KEY `fk_asistencia_seccion` (`seccion_id`);

--
-- Indices de la tabla `asistencias_momento`
--
ALTER TABLE `asistencias_momento`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_asistencia_estudiante_momento` (`estudiante_id`,`momento_id`),
  ADD KEY `fk_asistmom_seccion` (`seccion_id`),
  ADD KEY `fk_asistmom_momento` (`momento_id`);

--
-- Indices de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_filtros` (`modulo`,`accion`,`fecha_registro`),
  ADD KEY `fk_bitacora_usuario` (`usuario_id`);

--
-- Indices de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_calificacion_estudiante_momento` (`estudiante_id`,`momento_id`),
  ADD KEY `fk_calificacion_momento` (`momento_id`);

--
-- Indices de la tabla `docentes`
--
ALTER TABLE `docentes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cedula` (`cedula`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cedula_escolar_unique` (`cedula_escolar`),
  ADD KEY `fk_estudiantes_representante` (`representante_cedula`),
  ADD KEY `seccion_id` (`seccion_id`);

--
-- Indices de la tabla `momentos_academicos`
--
ALTER TABLE `momentos_academicos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_momento_periodo` (`periodo_id`);

--
-- Indices de la tabla `periodos`
--
ALTER TABLE `periodos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `representantes`
--
ALTER TABLE `representantes`
  ADD PRIMARY KEY (`cedula`);

--
-- Indices de la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_grado_seccion_periodo` (`periodo_id`,`grado`,`seccion`),
  ADD KEY `fk_seccion_profesor` (`docente_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asistencias`
--
ALTER TABLE `asistencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `asistencias_momento`
--
ALTER TABLE `asistencias_momento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `docentes`
--
ALTER TABLE `docentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `momentos_academicos`
--
ALTER TABLE `momentos_academicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `periodos`
--
ALTER TABLE `periodos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `secciones`
--
ALTER TABLE `secciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asistencias`
--
ALTER TABLE `asistencias`
  ADD CONSTRAINT `fk_asistencia_estudiante` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_asistencia_seccion` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `asistencias_momento`
--
ALTER TABLE `asistencias_momento`
  ADD CONSTRAINT `fk_asistmom_estudiante` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_asistmom_seccion` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_asistmom_momento` FOREIGN KEY (`momento_id`) REFERENCES `momentos_academicos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `bitacora`
--
ALTER TABLE `bitacora`
  ADD CONSTRAINT `fk_bitacora_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `fk_calificacion_estudiante` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_calificacion_momento` FOREIGN KEY (`momento_id`) REFERENCES `momentos_academicos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD CONSTRAINT `estudiantes_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`),
  ADD CONSTRAINT `fk_estudiantes_representante` FOREIGN KEY (`representante_cedula`) REFERENCES `representantes` (`cedula`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `momentos_academicos`
--
ALTER TABLE `momentos_academicos`
  ADD CONSTRAINT `fk_momento_periodo` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD CONSTRAINT `fk_seccion_periodo` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`),
  ADD CONSTRAINT `fk_seccion_profesor` FOREIGN KEY (`docente_id`) REFERENCES `docentes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
