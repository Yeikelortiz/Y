(function () {
    'use strict';

    const panel = document.getElementById('panelGuardados');
    if (!panel) return;

    const { el, peticion, esExito } = window.Comun;
    const BASE     = document.body.dataset.baseUrl || '/';
    const URL      = BASE + panel.dataset.url;
    const columnas = JSON.parse(panel.dataset.columnas || '[]');

    const ui = {
        seccion:  document.getElementById('selectSeccion'),
        buscar:   document.getElementById('buscarGuardados'),
        cabecera: document.getElementById('cabGuardados'),
        cuerpo:   document.getElementById('cuerpoGuardados'),
        contador: document.getElementById('cntGuardados'),
        vacio:    document.getElementById('vacioGuardados'),
    };

    const CLASES = {
        Presente: 'insignia-aprobado', Ausente: 'insignia-reprobado', Justificado: 'insignia-aviso', Tardanza: 'insignia-primaria',
        Aprobado: 'insignia-aprobado', Reprobado: 'insignia-reprobado',
    };

    // Texto sin tildes ni mayúsculas, para que "garcia" encuentre "García"
    const normalizar = (t) => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

    const fecha = (iso) => {
        const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/.exec(iso || '');
        return m ? m[3] + '/' + m[2] + '/' + m[1] + (m[4] ? ' ' + m[4] + ':' + m[5] : '') : (iso || '');
    };

    function texto(col, valor) {
        if (col.tipo === 'fecha' || col.tipo === 'fechahora') return fecha(valor);
        return valor === null || valor === undefined || valor === '' ? '—' : String(valor);
    }

    function crearFila(f) {
        const celdas = columnas.map((col) => {
            const t = texto(col, f[col.campo]);
            if (col.tipo === 'estado') {
                return el('td', {}, el('span', { class: 'insignia-pildora ' + (CLASES[t] || ''), text: t }));
            }
            return el('td', { class: col.campo === 'descripcion' ? 'celda-descripcion-guardada' : '', text: t });
        });
        const fila = el('tr', {}, celdas);
        fila.dataset.buscar = normalizar(columnas.map((c) => texto(c, f[c.campo])).join(' ') + ' ' + (f.fecha || ''));
        return fila;
    }

    function filtrar() {
        const palabras = normalizar(ui.buscar.value).trim().split(/\s+/).filter(Boolean);
        let visibles = 0;
        for (const fila of ui.cuerpo.rows) {
            const coincide = palabras.every((p) => fila.dataset.buscar.includes(p));
            fila.style.display = coincide ? '' : 'none';
            if (coincide) visibles++;
        }
        ui.contador.textContent = String(visibles);
        ui.vacio.hidden = visibles > 0;
        ui.vacio.textContent = ui.cuerpo.rows.length === 0
            ? 'No hay registros guardados para esta sección.'
            : 'Ningún registro coincide con la búsqueda.';
    }

    async function cargar() {
        const id = ui.seccion.value;
        if (!id) { panel.hidden = true; return; }

        panel.hidden = false;
        ui.vacio.hidden = false;
        ui.vacio.textContent = 'Cargando registros guardados...';

        const data = await peticion(URL + '&seccion=' + encodeURIComponent(id));
        if (ui.seccion.value !== id) return;

        if (!esExito(data)) {
            ui.cuerpo.replaceChildren();
            ui.contador.textContent = '0';
            ui.vacio.textContent = data.message || 'No se pudieron cargar los registros guardados.';
            return;
        }
        ui.cuerpo.replaceChildren(...(data.filas || []).map(crearFila));
        filtrar();
    }

    function init() {
        ui.cabecera.replaceChildren(el('tr', {}, columnas.map((c) => el('th', { text: c.titulo }))));
        ui.buscar.addEventListener('input', filtrar);
        ui.seccion.addEventListener('change', cargar);
        document.addEventListener('registros:actualizar', cargar);
        if (ui.seccion.value) cargar();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
