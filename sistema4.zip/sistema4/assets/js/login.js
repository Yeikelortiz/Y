document.addEventListener('DOMContentLoaded', function() {
    // Inicializar componentes si usas Materialize
    if (typeof M !== 'undefined' && M.AutoInit) {
        M.AutoInit();
    }

   
    const errorCard = document.getElementById('error-card');

    if (errorCard) {
        const errorMsg = errorCard.innerText.trim();

        if (errorMsg) {
            
            if (typeof Swal !== 'undefined') {
                // Ocultamos el cuadro feo y lanzamos la alerta elegante
                errorCard.style.display = 'none';

                Swal.fire({
                    icon: 'error',
                    title: '¡No pudimos iniciar sesión!',
                    text: errorMsg,
                    confirmButtonText: 'Entendido',
                    confirmButtonColor: '#d32f2f',
                    timer: 4000,
                    timerProgressBar: true
                });
            } else {
                // Fallback de seguridad: si estás offline, se muestra el cuadro normal de PHP
                errorCard.style.display = 'block';
            }
        }
    }
});