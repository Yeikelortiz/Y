(function () {
    'use strict';

    const {
        el, debounce, peticion, esExito, alerta, toast,
        abrirModal, cerrarModal, modalAbierto,
        dibujarPaginacion, limpiarErrores, marcarError, autoLimpiarErrores,
    } = window.Comun;

    const cuerpo         = document.body;
    const BASE_URL       = cuerpo.dataset.baseUrl || '/';
    const PUEDE_EDITAR   = cuerpo.dataset.puedeEditar === '1';
    const PUEDE_ELIMINAR = cuerpo.dataset.puedeEliminar === '1';
    const URL_CTRL       = BASE_URL + 'index.php?controller=representante&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        busqueda:   $('inputBusqueda'),
        btnLimpiar: $('btnLimpiarBusqueda'),
        btnNuevo:   $('btnNuevoRepresentante'),
        tbody:      $('cuerpoTabla'),
        estado:     $('estadoTabla'),
        total:      $('contadorTotal'),
        paginacion: $('paginacion'),
        form:       $('formRepresentante'),
        titulo:     $('tituloModalRepresentante'),
        btnGuardar: $('btnGuardarRep'),
        bloqueIni:  $('bloqueEstudianteInicial'),
        chkIni:     $('chkAgregarEstudiante'),
        camposIni:  $('camposEstudianteInicial'),
        notaCedula: $('notaCambioCedula'),
        formAdd:    $('formAgregarEstudiante'),
        btnGuardarEst: $('btnGuardarEst'),
    };

    const estado = {
        pagina: 1,
        busqueda: '',
        representantes: new Map(),
        detalle: null,
        abortar: null,
    };

    const nombreCompleto = (r) => ((r.nombre || '') + ' ' + (r.apellido || '')).trim();
    const REGEX_NOMBRE   = /^\p{L}[\p{L}\s'.\-]*$/u;
    const plural = (n, s, p) => n + ' ' + (n === 1 ? s : p);

    async function cargarLista() {
        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        ui.tbody.classList.add('cargando');
        const params = new URLSearchParams({ pagina: estado.pagina, busqueda: estado.busqueda });

        let data;
        try {
            data = await peticion(URL_CTRL + 'listar&' + params, { signal: estado.abortar.signal });
        } catch (_) {
            return;
        }
        ui.tbody.classList.remove('cargando');

        if (!esExito(data)) {
            ui.tbody.replaceChildren();
            ui.paginacion.hidden = true;
            mostrarEstado(data.message || 'No se pudo cargar el listado.', true);
            return;
        }

        const { representantes, paginacion } = data;
        estado.pagina = paginacion.pagina;
        estado.representantes = new Map(representantes.map((r) => [String(r.cedula), r]));

        ui.total.textContent = paginacion.total;
        ui.tbody.replaceChildren(...representantes.map(crearFila));
        mostrarEstado(representantes.length ? '' : (estado.busqueda ? 'No se encontraron coincidencias con la búsqueda.' : 'No hay representantes registrados.'));
        dibujarPaginacion(ui.paginacion, paginacion);
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('error', esError);
    }

    function crearFila(r) {
        const n = r.total_estudiantes;

        const celdaHijos = n > 0
            ? el('div', { class: 'celda-hijos' }, el('button', {
                type: 'button', class: 'enlace', dataset: { accion: 'ver', cedula: r.cedula },
                title: 'Ver estudiantes', text: plural(n, 'estudiante', 'estudiantes'),
            }))
            : el('div', { class: 'celda-hijos' }, [
                el('span', { class: 'sin-hijos', text: 'Sin estudiantes' }),
                PUEDE_EDITAR ? el('button', {
                    type: 'button', class: 'boton boton-contorno-secundario boton-sm',
                    dataset: { accion: 'agregar', cedula: r.cedula }, text: '+ Agregar',
                }) : null,
            ]);

        const nombre = nombreCompleto(r);
        const botones = [
            el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Ver información', 'aria-label': 'Ver ' + nombre, dataset: { accion: 'ver', cedula: r.cedula }, text: '👁' }),
        ];
        if (PUEDE_EDITAR) {
            botones.push(el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Editar', 'aria-label': 'Editar ' + nombre, dataset: { accion: 'editar', cedula: r.cedula }, text: '✏️' }));
        }
        if (PUEDE_ELIMINAR) {
            botones.push(el('button', { type: 'button', class: 'boton boton-peligro boton-sm', title: 'Eliminar', 'aria-label': 'Eliminar ' + nombre, dataset: { accion: 'eliminar', cedula: r.cedula }, text: '🗑' }));
        }

        return el('tr', {}, [
            el('td', {}, el('code', { text: r.cedula })),
            el('td', { class: 'nombre', text: nombre }),
            el('td', { text: r.telefono || '—' }),
            el('td', {}, celdaHijos),
            el('td', { class: 'acciones' }, el('div', { class: 'grupo' }, botones)),
        ]);
    }

    async function cargarDetalle(cedula) {
        const data = await peticion(URL_CTRL + 'detalle&cedula=' + encodeURIComponent(cedula));
        if (!esExito(data)) {
            alerta('error', data.title || 'No encontrado', data.message || 'No se pudo consultar el representante.');
            return false;
        }
        pintarDetalle(data.representante, data.estudiantes);
        return true;
    }

    async function abrirDetalle(cedula) {
        if (await cargarDetalle(cedula)) abrirModal('modalDetalle');
    }

    function pintarDetalle(r, estudiantes) {
        estado.detalle = r;

        $('detCedula').textContent    = r.cedula;
        $('detNombre').textContent    = nombreCompleto(r);
        $('detTelefono').textContent  = r.telefono || 'No especificado';
        $('detDireccion').textContent = r.direccion || 'No especificada';
        $('detTotal').textContent     = estudiantes.length;

        const hayHijos = estudiantes.length > 0;
        $('detTablaWrap').hidden = !hayHijos;
        $('detVacio').hidden = hayHijos;

        $('detEstudiantes').replaceChildren(...estudiantes.map((e) => {
            const sinSeccion = !e.seccion_nombre;
            return el('tr', {}, [
                el('td', {}, el('code', { text: e.cedula_escolar })),
                el('td', { class: 'nombre', text: (e.nombres + ' ' + e.apellidos).trim() }),
                el('td', { text: e.edad !== null && e.edad !== undefined ? e.edad + ' años' : '—' }),
                el('td', {}, el('span', { class: 'insignia-pildora ' + (sinSeccion ? 'insignia-muted' : 'insignia-primaria'), text: sinSeccion ? 'Sin asignar' : e.seccion_nombre })),
            ]);
        }));
    }

    const camposEstudianteVisibles = () => !ui.camposIni.hidden;

    function validarEstudiante(form) {
        const f = form.elements;
        const errores = {};

        const nombres = f.est_nombres.value.trim();
        const apellidos = f.est_apellidos.value.trim();
        if (!nombres) errores.est_nombres = 'Los nombres del estudiante son obligatorios.';
        else if (!REGEX_NOMBRE.test(nombres)) errores.est_nombres = 'Solo letras y espacios.';
        if (!apellidos) errores.est_apellidos = 'Los apellidos del estudiante son obligatorios.';
        else if (!REGEX_NOMBRE.test(apellidos)) errores.est_apellidos = 'Solo letras y espacios.';

        if (!f.est_fecha_nacimiento.value) errores.est_fecha_nacimiento = 'La fecha de nacimiento es obligatoria.';
        else if (new Date(f.est_fecha_nacimiento.value) > new Date()) errores.est_fecha_nacimiento = 'La fecha no puede ser futura.';

        if (!f.est_genero.value) errores.est_genero = 'Seleccione el género.';
        return errores;
    }

    function validarRepresentante() {
        const f = ui.form.elements;
        const errores = {};

        if (!/^\d{6,10}$/.test(f.cedula.value.trim())) errores.cedula = 'Entre 6 y 10 dígitos, solo números.';
        if (!/^[0-9+\-\s()]{7,20}$/.test(f.telefono.value.trim())) errores.telefono = 'Teléfono no válido (7 a 20 caracteres).';

        const nombre = f.nombre.value.trim();
        const apellido = f.apellido.value.trim();
        if (!nombre) errores.nombre = 'Los nombres son obligatorios.';
        else if (!REGEX_NOMBRE.test(nombre)) errores.nombre = 'Solo letras y espacios.';
        if (!apellido) errores.apellido = 'Los apellidos son obligatorios.';
        else if (!REGEX_NOMBRE.test(apellido)) errores.apellido = 'Solo letras y espacios.';

        return errores;
    }

    function aplicarErrores(form, errores) {
        const campos = Object.keys(errores);
        campos.forEach((c) => marcarError(form, c, errores[c]));
        if (campos.length && form.elements[campos[0]]) form.elements[campos[0]].focus();
        return campos.length > 0;
    }

    function actualizarVisibilidadEstudianteInicial() {
        ui.camposIni.hidden = !ui.chkIni.checked;
    }

    function abrirNuevo() {
        ui.form.reset();
        limpiarErrores(ui.form);
        ui.form.elements.cedula_original.value = '';
        ui.titulo.textContent = 'Registro de Representante';
        ui.bloqueIni.hidden = false;
        ui.chkIni.checked = true;
        ui.notaCedula.hidden = true;
        actualizarVisibilidadEstudianteInicial();
        abrirModal('modalRepresentante');
        ui.form.elements.cedula.focus();
    }

    function abrirEdicion(cedula) {
        const r = estado.representantes.get(String(cedula));
        if (!r) return;

        ui.form.reset();
        limpiarErrores(ui.form);
        ui.titulo.textContent = 'Editar Representante';

        const f = ui.form.elements;
        f.cedula_original.value = r.cedula;
        f.cedula.value    = r.cedula;
        f.telefono.value  = r.telefono || '';
        f.nombre.value    = r.nombre || '';
        f.apellido.value  = r.apellido || '';
        f.direccion.value = r.direccion || '';

        ui.chkIni.checked = false;
        ui.bloqueIni.hidden = true;
        ui.notaCedula.hidden = r.total_estudiantes === 0;

        abrirModal('modalRepresentante');
        f.nombre.focus();
    }

    async function enviarFormulario(ev) {
        ev.preventDefault();
        limpiarErrores(ui.form);

        const errores = validarRepresentante();
        const esNuevo = ui.form.elements.cedula_original.value === '';
        if (esNuevo && ui.chkIni.checked) Object.assign(errores, validarEstudiante(ui.form));
        if (aplicarErrores(ui.form, errores)) return;

        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';
        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: new FormData(ui.form) });
        ui.btnGuardar.disabled = false;
        ui.btnGuardar.textContent = 'Guardar';

        if (esExito(data)) {
            cerrarModal($('modalRepresentante'));
            if (esNuevo) { 
                estado.pagina = 1; 
                estado.busqueda = ''; 
                ui.busqueda.value = ''; 
                ui.btnLimpiar.hidden = true; 
            }
            await cargarLista();
            toast(data.message + (data.cedula_escolar ? ' Cédula escolar del estudiante: ' + data.cedula_escolar : ''));
            return;
        }

        if (data.errors) Object.entries(data.errors).forEach(([c, m]) => marcarError(ui.form, c, m));
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar.');
    }

    function abrirAgregar(rep) {
        if (!rep || !PUEDE_EDITAR) return;

        ui.formAdd.reset();
        limpiarErrores(ui.formAdd);
        ui.formAdd.elements.representante_cedula.value = rep.cedula;
        $('agregarContexto').textContent = 'Representante: ' + nombreCompleto(rep) + ' (C.I. ' + rep.cedula + ')';

        abrirModal('modalAgregarEstudiante');
        ui.formAdd.elements.est_nombres.focus();
    }

    async function enviarAgregarEstudiante(ev) {
        ev.preventDefault();
        limpiarErrores(ui.formAdd);

        if (aplicarErrores(ui.formAdd, validarEstudiante(ui.formAdd))) return;

        const cedulaRep = ui.formAdd.elements.representante_cedula.value;
        ui.btnGuardarEst.disabled = true;
        ui.btnGuardarEst.textContent = 'Guardando...';
        const data = await peticion(URL_CTRL + 'agregarEstudiante', { method: 'POST', body: new FormData(ui.formAdd) });
        ui.btnGuardarEst.disabled = false;
        ui.btnGuardarEst.textContent = 'Registrar estudiante';

        if (esExito(data)) {
            cerrarModal($('modalAgregarEstudiante'));
            await cargarLista();
            if (modalAbierto('modalDetalle')) await cargarDetalle(cedulaRep);
            toast(data.message + ' Cédula escolar: ' + data.cedula_escolar);
            return;
        }

        if (data.errors) Object.entries(data.errors).forEach(([c, m]) => marcarError(ui.formAdd, c, m));
        alerta('error', data.title || 'Atención', data.message || 'No se pudo registrar al estudiante.');
    }

    async function confirmarEliminacion(cedula) {
        const r = estado.representantes.get(String(cedula));
        if (!r) return;

        // Construcción dinámica del aviso según la cantidad de estudiantes asociados
        const n = r.total_estudiantes;
        const aviso = n > 0 
            ? ` También se eliminarán sus ${n} ${n === 1 ? 'estudiante' : 'estudiantes'}, con sus asistencias y calificaciones.` 
            : '';

        const respuesta = await Swal.fire({
            title: '¿Eliminar representante?',
            text: nombreCompleto(r) + ' (C.I. ' + r.cedula + ').' + aviso + ' Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
        });
        
        if (!respuesta.isConfirmed) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('cedula', r.cedula);
        const data = await peticion(URL_CTRL + 'eliminar', { method: 'POST', body: cuerpoPost });

        if (esExito(data)) {
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'Error', data.message || 'No se pudo eliminar el representante.');
        }
    }

    function init() {
        const buscar = debounce(() => {
            estado.busqueda = ui.busqueda.value.trim();
            estado.pagina = 1;
            ui.btnLimpiar.hidden = estado.busqueda === '';
            cargarLista();
        }, 300);
        
        ui.busqueda.addEventListener('input', buscar);
        ui.btnLimpiar.addEventListener('click', () => {
            ui.busqueda.value = '';
            ui.busqueda.focus();
            buscar();
        });

        ui.paginacion.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-pagina]');
            if (!btn || btn.disabled) return;
            estado.pagina = Number(btn.dataset.pagina);
            cargarLista();
        });

        ui.tbody.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn) return;
            const { accion, cedula } = btn.dataset;
            if (accion === 'ver') abrirDetalle(cedula);
            else if (accion === 'editar') abrirEdicion(cedula);
            else if (accion === 'eliminar') confirmarEliminacion(cedula);
            else if (accion === 'agregar') abrirAgregar(estado.representantes.get(String(cedula)));
        });

        if (!PUEDE_EDITAR) {
            cargarLista();
            return;
        }

        ui.btnNuevo.addEventListener('click', abrirNuevo);
        ui.form.addEventListener('submit', enviarFormulario);
        ui.chkIni.addEventListener('change', actualizarVisibilidadEstudianteInicial);
        autoLimpiarErrores(ui.form);

        const cedula = ui.form.elements.cedula;
        cedula.addEventListener('input', () => { cedula.value = cedula.value.replace(/\D/g, ''); });

        ui.formAdd.addEventListener('submit', enviarAgregarEstudiante);
        autoLimpiarErrores(ui.formAdd);
        
        [$('btnAgregarDesdeDetalle'), $('btnAgregarVacio')].forEach((b) => {
            if (b) b.addEventListener('click', () => abrirAgregar(estado.detalle));
        });

        cargarLista();
    }

    document.addEventListener('DOMContentLoaded', init);
})();