(function(){
 const getModal=(el)=>({
  show(){if(!el)return;el.classList.add('show','is-open');el.style.display='block';document.body.style.overflow='hidden';},
  hide(){if(!el)return;el.classList.remove('show','is-open');el.style.display='none';document.body.style.overflow='';},
  toggle(){if(el&&(el.classList.contains('show')||el.classList.contains('is-open')))this.hide();else this.show();}
 });
 window.UI=window.UI||{};
 window.UI.Modal={getOrCreateInstance(el){return getModal(typeof el==='string'?document.querySelector(el):el)}};
 window.UI.Tooltip={};
 document.addEventListener('click',function(e){
  const close=e.target.closest('[data-dismiss="modal"],[data-bs-dismiss="modal"],.modal .btn-close');
  if(close){const modal=close.closest('.modal');if(modal)getModal(modal).hide();}
  if(e.target.classList&&e.target.classList.contains('modal'))getModal(e.target).hide();
 });
 document.addEventListener('keydown',function(e){if(e.key==='Escape'){document.querySelectorAll('.modal.show,.modal.is-open').forEach(m=>getModal(m).hide());}});
})();