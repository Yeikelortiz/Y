(function () {
    'use strict';

    const { el, peticion, esExito, alerta, toast } = window.Comun;

    const cuerpo       = document.body;
    const BASE_URL     = cuerpo.dataset.baseUrl || '/';
    const PUEDE_EDITAR = cuerpo.dataset.puedeEditar === '1';
    const MAX_DIAS     = Number(cuerpo.dataset.maxDias || 366);
    const URL_CTRL     = BASE_URL + 'index.php?controller=asistencia&action=';
    const URL_REPORTE  = BASE_URL + 'index.php?controller=reporte&action=index&tipo=asistencias';

    const $ = (id) => document.getElementById(id);

    const ui = {
        selectMomento: $('selectMomento'),
        selectSeccion: $('selectSeccion'),
        btnConsultar:  $('btnConsultar'),
        lnkReporte:    $('lnkReporteAsistencia'),
        panel:         $('panelLista'),
        form:          $('formAsistencia'),
        cuerpoLista:   $('cuerpoLista'),
        listaVacia:    $('listaVacia'),
        estadoLista:   $('estadoLista'),
        btnGuardarTodos: $('btnGuardarTodos'),
    };

    // Copia de todas las secciones para filtrarlas según el período del momento elegido
    const SECCIONES = [...ui.selectSeccion.querySelectorAll('option[value]:not([value=""])')]
        .map((o) => ({ value: o.value, texto: o.textContent.trim(), periodo: o.dataset.periodo }));

    const estado = { datos: null, abortar: null };

    /* ---------- Filtros ---------- */

    function periodoDelMomento() {
        const opcion = ui.selectMomento.selectedOptions[0];
        return opcion && opcion.value ? opcion.dataset.periodo : '';
    }

    function cargarSecciones() {
        const periodo = periodoDelMomento();
        ui.selectSeccion.replaceChildren();

        if (!periodo) {
            ui.selectSeccion.append(el('option', { value: '', text: 'Seleccione primero el momento...' }));
            ui.selectSeccion.disabled = true;
            return;
        }

        const delPeriodo = SECCIONES.filter((s) => s.periodo === periodo);
        ui.selectSeccion.append(el('option', { value: '', text: delPeriodo.length ? 'Seleccione grado y sección...' : 'Este período no tiene secciones' }));
        ui.selectSeccion.append(...delPeriodo.map((s) => el('option', { value: s.value, text: s.texto })));
        ui.selectSeccion.disabled = delPeriodo.length === 0;
    }

    function actualizarFiltros() {
        ui.btnConsultar.disabled = !(ui.selectMomento.value !== '' && ui.selectSeccion.value !== '');
        ui.lnkReporte.href = URL_REPORTE + (ui.selectSeccion.value ? '&seccion=' + encodeURIComponent(ui.selectSeccion.value) : '');
        ui.panel.hidden = true;
        estado.datos = null;
    }

    function alCambiarMomento() {
        cargarSecciones();
        actualizarFiltros();
        // Avisa al panel de registros guardados (se oculta hasta elegir sección)
        ui.selectSeccion.dispatchEvent(new Event('change'));
    }

    /* ---------- Carga de la lista ---------- */

    async function consultar() {
        const seccionId = ui.selectSeccion.value;
        const momentoId = ui.selectMomento.value;
        if (!seccionId || !momentoId) return false;

        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        let data;
        try {
            data = await peticion(
                URL_CTRL + 'lista&seccion=' + encodeURIComponent(seccionId) + '&momento=' + encodeURIComponent(momentoId),
                { signal: estado.abortar.signal }
            );
        } catch (_) {
            return false;
        }

        if (!esExito(data)) {
            ui.panel.hidden = true;
            alerta('error', data.title || 'Error', data.message || 'No se pudo cargar la lista de asistencia.');
            return false;
        }

        estado.datos = data;
        pintarLista(data);
        return true;
    }

    function pintarLista(d) {
        const { seccion, momento, estudiantes, editable, motivoBloqueo } = d;

        $('listaTitulo').textContent = 'Asistencia — ' + seccion.etiqueta + ' · ' + momento.nombre;
        $('lisGrado').textContent    = seccion.grado + '° Grado';
        $('lisSeccion').textContent  = seccion.seccion;
        $('lisPeriodo').textContent  = seccion.periodo_nombre;
        $('lisAula').textContent     = seccion.aula || '—';
        $('lisMomento').textContent  = momento.nombre;

        const docente = $('lisDocente');
        docente.textContent = seccion.sin_docente ? '⚠ Sin docente asignado' : seccion.docente_nombre;
        docente.classList.toggle('sin-docente-aviso', !!seccion.sin_docente);

        ui.form.elements.seccion_id.value = seccion.id;
        ui.form.elements.momento_id.value = momento.id;

        if (!editable) {
            ui.estadoLista.textContent = motivoBloqueo || 'El registro es de solo lectura.';
            ui.estadoLista.className = 'estado-lista bloqueada';
        } else {
            ui.estadoLista.textContent = 'Escriba las asistencias e inasistencias de cada estudiante en este momento y pulse «Guardar». Ambos campos son obligatorios (use 0 si no hubo).';
            ui.estadoLista.className = 'estado-lista pendiente';
        }

        ui.cuerpoLista.replaceChildren(...estudiantes.map((e) => crearFila(e, editable)));
        ui.listaVacia.hidden = estudiantes.length > 0;
        ui.panel.hidden = false;

        if (ui.btnGuardarTodos) ui.btnGuardarTodos.hidden = !(editable && PUEDE_EDITAR && estudiantes.length > 0);
        actualizarContadores();
    }

    function crearFila(e, editable) {
        const nombre = (e.apellidos || '').toUpperCase() + ', ' + e.nombres;
        const bloqueado = !(editable && PUEDE_EDITAR);

        const campo = (nombreCampo, valor, etiqueta) => el('input', {
            type: 'number', min: 0, max: MAX_DIAS, step: 1, inputmode: 'numeric',
            class: 'campo campo-dias', name: 'datos[' + e.id + '][' + nombreCampo + ']',
            value: valor === null || valor === undefined ? '' : String(valor),
            placeholder: '0', required: true, disabled: bloqueado,
            'aria-label': etiqueta + ' de ' + nombre,
            dataset: { campo: nombreCampo, guardado: valor === null || valor === undefined ? '' : String(valor) },
        });

        const celdaEstado = el('td', {}, el('span', { class: 'estado-fila' }));
        const celdaAcciones = el('td', { class: 'acciones' }, bloqueado ? null :
            el('button', { type: 'button', class: 'boton boton-primario boton-sm', dataset: { guardarFila: e.id } }, document.createTextNode('Guardar')));

        const tr = el('tr', { dataset: { id: e.id, registrado: e.registrado ? '1' : '0' } }, [
            el('td', { class: 'nombre', text: nombre }),
            el('td', {}, el('code', { text: e.cedula_escolar })),
            celdaEstado,
            el('td', {}, campo('asistencias', e.asistencias, 'Asistencias')),
            el('td', {}, [campo('inasistencias', e.inasistencias, 'Inasistencias'), el('small', { class: 'msg-fila' })]),
            celdaAcciones,
        ]);
        refrescarEstadoFila(tr);
        return tr;
    }

    /* ---------- Estado de las filas ---------- */

    const inputsDe = (tr) => ({
        a: tr.querySelector('input[data-campo="asistencias"]'),
        i: tr.querySelector('input[data-campo="inasistencias"]'),
    });

    function refrescarEstadoFila(tr) {
        const { a, i } = inputsDe(tr);
        const registrado = tr.dataset.registrado === '1';
        const cambio = a.value !== a.dataset.guardado || i.value !== i.dataset.guardado;

        let clase = 'pendiente', texto = 'Pendiente';
        if (registrado && !cambio) { clase = 'registrado'; texto = 'Registrado'; }
        else if (registrado && cambio) { clase = 'modificado'; texto = 'Sin guardar'; }

        const marca = tr.querySelector('.estado-fila');
        marca.className = 'estado-fila ' + clase;
        marca.textContent = texto;

        const boton = tr.querySelector('[data-guardar-fila]');
        if (boton) boton.textContent = registrado ? 'Actualizar' : 'Guardar';
    }

    function actualizarContadores() {
        const filas = [...ui.cuerpoLista.rows];
        const registrados = filas.filter((tr) => tr.dataset.registrado === '1').length;
        $('cntRegistrados').textContent = registrados;
        $('cntPendientes').textContent  = filas.length - registrados;
        $('cntTotal').textContent       = filas.length;
    }

    function marcarFila(estudianteId, mensaje) {
        const tr = ui.cuerpoLista.querySelector('tr[data-id="' + estudianteId + '"]');
        if (!tr) return null;
        tr.classList.add('fila-invalida');
        tr.querySelector('.msg-fila').textContent = mensaje;
        return tr;
    }

    function limpiarFila(tr) {
        tr.classList.remove('fila-invalida');
        tr.querySelector('.msg-fila').textContent = '';
        tr.querySelectorAll('input').forEach((c) => c.classList.remove('invalido'));
    }

    function limpiarErrores() {
        ui.cuerpoLista.querySelectorAll('tr').forEach(limpiarFila);
    }

    // Devuelve el mensaje de error de una fila, o '' si está bien
    function validarFila(tr) {
        const { a, i } = inputsDe(tr);
        const vacio = (c) => c.value.trim() === '';
        const malo = (c) => !/^\d+$/.test(c.value.trim()) || Number(c.value) > MAX_DIAS;

        [a, i].forEach((c) => c.classList.remove('invalido'));
        if (vacio(a) || vacio(i)) {
            [a, i].filter(vacio).forEach((c) => c.classList.add('invalido'));
            return 'Indique asistencias e inasistencias (use 0 si no hubo).';
        }
        if (malo(a) || malo(i)) {
            [a, i].filter(malo).forEach((c) => c.classList.add('invalido'));
            return 'Solo números enteros entre 0 y ' + MAX_DIAS + '.';
        }
        return '';
    }

    /* ---------- Guardado ---------- */

    async function guardarFilas(filas) {
        if (!PUEDE_EDITAR || !estado.datos || !estado.datos.editable || filas.length === 0) return;

        limpiarErrores();
        let primeraInvalida = null;
        filas.forEach((tr) => {
            const msg = validarFila(tr);
            if (msg) {
                const marcada = marcarFila(tr.dataset.id, msg);
                primeraInvalida = primeraInvalida || marcada;
            }
        });
        if (primeraInvalida) {
            primeraInvalida.scrollIntoView({ block: 'center', behavior: 'smooth' });
            return;
        }

        const fd = new FormData();
        fd.append('seccion_id', ui.form.elements.seccion_id.value);
        fd.append('momento_id', ui.form.elements.momento_id.value);
        filas.forEach((tr) => {
            const { a, i } = inputsDe(tr);
            fd.append('datos[' + tr.dataset.id + '][asistencias]', a.value.trim());
            fd.append('datos[' + tr.dataset.id + '][inasistencias]', i.value.trim());
        });

        const botones = [...filas.map((tr) => tr.querySelector('[data-guardar-fila]')), ui.btnGuardarTodos].filter(Boolean);
        botones.forEach((b) => { b.disabled = true; });
        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: fd });
        botones.forEach((b) => { b.disabled = false; });

        if (esExito(data)) {
            filas.forEach((tr) => {
                const { a, i } = inputsDe(tr);
                a.dataset.guardado = a.value.trim();
                i.dataset.guardado = i.value.trim();
                a.value = a.dataset.guardado;
                i.value = i.dataset.guardado;
                tr.dataset.registrado = '1';
                refrescarEstadoFila(tr);
            });
            actualizarContadores();
            document.dispatchEvent(new CustomEvent('registros:actualizar'));
            toast(data.message);
            return;
        }

        if (data.errors) {
            const marcadas = Object.entries(data.errors).map(([clave, mensaje]) => marcarFila(clave.replace('est_', ''), mensaje));
            const primera = marcadas.find(Boolean);
            if (primera) primera.scrollIntoView({ block: 'center', behavior: 'smooth' });
        }
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar la asistencia.');
    }

    // «Guardar todos»: solo las filas con algún dato escrito o ya modificadas
    function guardarTodos() {
        const filas = [...ui.cuerpoLista.rows].filter((tr) => {
            const { a, i } = inputsDe(tr);
            const conDatos = a.value.trim() !== '' || i.value.trim() !== '';
            const cambio = a.value !== a.dataset.guardado || i.value !== i.dataset.guardado;
            return conDatos && (cambio || tr.dataset.registrado !== '1');
        });

        if (filas.length === 0) {
            alerta('info', 'Nada que guardar', 'No hay estudiantes con datos nuevos o modificados.');
            return;
        }
        guardarFilas(filas);
    }

    /* ---------- Eventos ---------- */

    function init() {
        ui.selectMomento.addEventListener('change', alCambiarMomento);
        ui.selectSeccion.addEventListener('change', actualizarFiltros);
        ui.btnConsultar.addEventListener('click', consultar);

        ui.cuerpoLista.addEventListener('input', (ev) => {
            const tr = ev.target.closest('tr');
            if (!tr) return;
            if (tr.classList.contains('fila-invalida')) limpiarFila(tr);
            ev.target.classList.remove('invalido');
            refrescarEstadoFila(tr);
        });

        ui.cuerpoLista.addEventListener('click', (ev) => {
            const boton = ev.target.closest('[data-guardar-fila]');
            if (boton) guardarFilas([boton.closest('tr')]);
        });

        // Enter en un campo guarda esa fila
        ui.cuerpoLista.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' && ev.target.matches('input')) {
                ev.preventDefault();
                guardarFilas([ev.target.closest('tr')]);
            }
        });

        if (ui.btnGuardarTodos) ui.btnGuardarTodos.addEventListener('click', guardarTodos);
        ui.form.addEventListener('submit', (ev) => ev.preventDefault());

        alCambiarMomento();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
