(function () {
    'use strict';

    const { el, debounce, peticion, esExito, alerta } = window.Comun;

    const cuerpo   = document.body;
    const BASE_URL = cuerpo.dataset.baseUrl || '/';
    const HOY      = cuerpo.dataset.hoy || '';
    const URL_CTRL = BASE_URL + 'index.php?controller=bitacora&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        q:        $('inputBusqueda'),
        modulo:   $('selectModulo'),
        accion:   $('selectAccion'),
        rol:      $('selectRol'),
        usuario:  $('selectUsuario'),
        desde:    $('inputDesde'),
        hasta:    $('inputHasta'),
        porPagina: $('selectPorPagina'),
        btnLimpiar: $('btnLimpiar'),
        lnkExcel: $('lnkExcel'),
        atajos:   $('atajos'),
        tbody:    $('cuerpoBitacora'),
        estado:   $('estadoTabla'),
        contador: $('contadorFiltrado'),
        info:     $('infoPaginacion'),
        paginador: $('paginador'),
    };

    const modalDetalle = window.Comun.modalNativo('modalDetalle');

    const estado = {
        pagina: 1,
        registros: new Map(),
        catalogos: false,
        abortar: null,
    };

    const CLASES_ACCION = {
        INICIO_SESION: 'u-f-exito-suave u-t-exito',
        CIERRE_SESION: 'u-f-secundario-suave u-t-secundario',
        BLOQUEO:       'u-f-peligro-suave u-t-peligro',
        ELIMINAR:      'u-f-peligro-suave u-t-peligro',
        CREAR:         'u-f-primario-suave u-t-primario',
        EDITAR:        'u-f-aviso-suave u-t-aviso-fuerte',
        MODIFICAR:     'u-f-aviso-suave u-t-aviso-fuerte',
        CERRAR:        'u-f-oscuro-suave u-t-oscuro',
        ABRIR:         'u-f-info-suave u-t-info-fuerte',
    };
    const CLASES_ROL = { admin: 'u-f-peligro u-t-blanco', director: 'u-f-exito u-t-blanco', secretaria: 'u-f-aviso u-t-oscuro' };

    function formatearFecha(valor) {
        if (!valor) return '—';
        const [fecha, hora = ''] = String(valor).split(' ');
        return fecha.split('-').reverse().join('/') + (hora ? ' ' + hora.slice(0, 5) : '');
    }

    const icono = (clases) => el('i', { class: 'icono ' + clases });

    function leerFiltros() {
        return {
            q: ui.q.value.trim(),
            modulo: ui.modulo.value,
            accion: ui.accion.value,
            rol: ui.rol.value,
            usuario: ui.usuario.value,
            desde: ui.desde.value,
            hasta: ui.hasta.value,
        };
    }

    function queryFiltros() {
        const q = new URLSearchParams();
        Object.entries(leerFiltros()).forEach(([clave, valor]) => { if (valor !== '') q.set(clave, valor); });
        return q;
    }

    function actualizarEnlaceExcel() {
        ui.lnkExcel.href = URL_CTRL + 'exportar&' + queryFiltros().toString();
    }

    function limpiarErrores() {
        document.querySelectorAll('[data-error-for]').forEach((s) => { s.textContent = ''; });
    }

    function validarFiltros() {
        const { desde, hasta } = leerFiltros();
        if (desde && hasta && desde > hasta) return { desde: 'La fecha "desde" no puede ser posterior a "hasta".' };
        if (hasta && HOY && hasta > HOY) return { hasta: 'La fecha "hasta" no puede ser futura.' };
        return null;
    }

    function fijarSelect(select, valor) {
        if (valor && ![...select.options].some((o) => o.value === valor)) {
            select.append(el('option', { value: valor, text: valor }));
        }
        select.value = valor || '';
    }

    function marcarAtajoActivo() {
        const { modulo, accion } = leerFiltros();
        ui.atajos.querySelectorAll('button').forEach((b) => {
            const d = b.dataset;
            const activo = d.atajo === 'todos'
                ? (!modulo && !accion)
                : ((d.modulo || '') === modulo && (d.accion || '') === accion);
            b.classList.toggle('activo', activo);
        });
    }

    // Texto sin tildes ni mayúsculas, para que "garcia" encuentre "García"
    const normalizar = (t) => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

    function filtrarFilas() {
        const palabras = normalizar(ui.q.value).trim().split(/\s+/).filter(Boolean);
        for (const fila of ui.tbody.querySelectorAll('tr[data-id]')) {
            if (!fila.dataset.buscar) fila.dataset.buscar = normalizar(fila.textContent);
            fila.style.display = palabras.every((p) => fila.dataset.buscar.includes(p)) ? '' : 'none';
        }
    }

    function alCambiarFiltro() {
        estado.pagina = 1;
        marcarAtajoActivo();
        actualizarEnlaceExcel();
        cargar();
    }

    async function cargar() {
        limpiarErrores();
        const errores = validarFiltros();
        if (errores) {
            Object.entries(errores).forEach(([campo, msg]) => {
                const aviso = document.querySelector('[data-error-for="' + campo + '"]');
                if (aviso) aviso.textContent = msg;
            });
            return;
        }

        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        const q = queryFiltros();
        q.set('pagina', estado.pagina);
        q.set('porPagina', ui.porPagina.value);
        if (!estado.catalogos) q.set('catalogos', '1');

        ui.tbody.classList.add('u-opacidad-50');
        let data;
        try {
            data = await peticion(URL_CTRL + 'listar&' + q.toString(), { signal: estado.abortar.signal });
        } catch (_) {
            return;
        }
        ui.tbody.classList.remove('u-opacidad-50');

        if (!esExito(data)) {
            ui.tbody.replaceChildren();
            ui.paginador.replaceChildren();
            ui.info.textContent = '';
            mostrarEstado(data.message || 'No se pudo cargar la bitácora.', true);
            if (data.errors) {
                Object.entries(data.errors).forEach(([campo, msg]) => {
                    const aviso = document.querySelector('[data-error-for="' + campo + '"]');
                    if (aviso) aviso.textContent = msg;
                });
            }
            return;
        }

        if (data.catalogos) llenarCatalogos(data.catalogos);
        pintarResumen(data.resumen);

        const { registros, paginacion } = data;
        estado.pagina = paginacion.pagina;
        estado.registros = new Map(registros.map((r) => [r.id, r]));

        ui.contador.textContent = paginacion.total;
        ui.tbody.replaceChildren(...registros.map(crearFila));
        mostrarEstado(registros.length ? '' : 'No hay eventos que coincidan con los filtros seleccionados.');
        pintarPaginacion(paginacion);
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('u-t-peligro', esError);
        ui.estado.classList.toggle('u-t-suave', !esError);
        ui.estado.hidden = texto === '';
    }

    function pintarResumen(r) {
        $('resTotal').textContent = r.total;
        $('resHoy').textContent = r.hoy;
        $('resInicios').textContent = r.inicios_hoy;
        $('resEliminaciones').textContent = r.eliminaciones;
    }

    function llenarCatalogos(c) {
        const llenar = (select, valores, mapa = (v) => ({ valor: v, texto: v })) => {
            const actual = select.value;
            const primera = select.options[0];
            select.replaceChildren(primera, ...valores.map((v) => {
                const { valor, texto } = mapa(v);
                return el('option', { value: valor, text: texto });
            }));
            fijarSelect(select, actual);
        };
        llenar(ui.modulo, c.modulos);
        llenar(ui.accion, c.acciones);
        llenar(ui.rol, c.roles);
        llenar(ui.usuario, c.usuarios, (u) => ({ valor: String(u.id), texto: u.nombre }));
        estado.catalogos = true;
    }

    function crearFila(r) {
        const rol = (r.rol_usuario || '').toLowerCase();

        const fila = el('tr', { tabindex: '0', title: 'Ver detalle del evento', dataset: { id: r.id } }, [
            el('td', { class: 'u-ps-4 u-negrita u-t-suave', text: '#' + r.id }),
            el('td', {}, [
                el('div', { class: 'u-negrita u-t-oscuro', text: r.nombre_usuario || 'Sistema' }),
                el('div', { class: 'u-t-suave u-mono small-etiqueta', text: 'ID: ' + (r.usuario_id ?? 'N/A') }),
            ]),
            el('td', { class: 'u-centro' }, el('span', {
                class: 'insignia u-mayusculas ' + (CLASES_ROL[rol] || 'u-f-secundario u-t-blanco'),
                text: r.rol_usuario || 'N/A',
            })),
            el('td', {}, el('span', { class: 'etiqueta-accion ' + (CLASES_ACCION[r.accion] || 'u-f-claro u-t-secundario u-borde') }, [
                icono('icono-tag-fill'), document.createTextNode(r.accion),
            ])),
            el('td', { class: 'u-t-secundario u-seminegrita', text: r.modulo }),
            el('td', { class: 'celda-descripcion' }, el('div', { class: 'recorte', text: r.descripcion })),
            el('td', { class: 'u-pe-4 u-der u-t-suave u-nowrap u-pequeno', text: formatearFecha(r.fecha_registro) }),
        ]);

        return fila;
    }

    function abrirDetalle(id) {
        const r = estado.registros.get(Number(id));
        if (!r) return;

        $('tituloDetalle').textContent = 'Evento #' + r.id;
        $('detId').textContent        = '#' + r.id;
        $('detFecha').textContent     = formatearFecha(r.fecha_registro);
        $('detUsuario').textContent   = (r.nombre_usuario || 'Sistema') + (r.usuario_id ? ' (ID ' + r.usuario_id + ')' : '');
        $('detRol').textContent       = r.rol_usuario || 'N/A';
        $('detAccion').textContent    = r.accion;
        $('detModulo').textContent    = r.modulo;
        $('detDescripcion').textContent = r.descripcion;
        modalDetalle.show();
    }

    function pintarPaginacion({ pagina, totalPaginas, total, porPagina }) {
        const desde = total === 0 ? 0 : (pagina - 1) * porPagina + 1;
        const hasta = Math.min(pagina * porPagina, total);
        ui.info.textContent = 'Mostrando ' + desde + '–' + hasta + ' de ' + total + ' evento' + (total === 1 ? '' : 's');

        ui.paginador.replaceChildren();
        if (totalPaginas <= 1) return;

        const item = (texto, destino, { activa = false, deshabilitado = false, etiqueta } = {}) =>
            el('li', { class: 'pag-item' + (activa ? ' active' : '') + (deshabilitado ? ' disabled' : '') },
                el('button', {
                    type: 'button', class: 'pag-enlace', text: texto, disabled: deshabilitado,
                    'aria-label': etiqueta, 'aria-current': activa ? 'page' : null, dataset: { pagina: destino },
                }));

        ui.paginador.appendChild(item('‹', pagina - 1, { deshabilitado: pagina === 1, etiqueta: 'Página anterior' }));

        const visibles = new Set([1, totalPaginas, pagina - 2, pagina - 1, pagina, pagina + 1, pagina + 2]);
        let previa = 0;
        [...visibles].filter((p) => p >= 1 && p <= totalPaginas).sort((a, b) => a - b).forEach((p) => {
            if (p - previa > 1) {
                ui.paginador.appendChild(el('li', { class: 'pag-item disabled' }, el('span', { class: 'pag-enlace', text: '…' })));
            }
            ui.paginador.appendChild(item(String(p), p, { activa: p === pagina, etiqueta: 'Página ' + p }));
            previa = p;
        });

        ui.paginador.appendChild(item('›', pagina + 1, { deshabilitado: pagina === totalPaginas, etiqueta: 'Página siguiente' }));
    }

    function init() {
        const consultarServidor = debounce(alCambiarFiltro, 350);
        ui.q.addEventListener('input', () => { filtrarFilas(); consultarServidor(); });
        [ui.modulo, ui.accion, ui.rol, ui.usuario, ui.desde, ui.hasta].forEach((c) => c.addEventListener('change', alCambiarFiltro));
        ui.porPagina.addEventListener('change', alCambiarFiltro);

        // Consultas rápidas (eventos importantes)
        ui.atajos.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-atajo]');
            if (!btn) return;
            fijarSelect(ui.modulo, btn.dataset.modulo || '');
            fijarSelect(ui.accion, btn.dataset.accion || '');
            alCambiarFiltro();
        });

        ui.btnLimpiar.addEventListener('click', () => {
            ui.q.value = '';
            [ui.modulo, ui.accion, ui.rol, ui.usuario].forEach((s) => { s.value = ''; });
            ui.desde.value = '';
            ui.hasta.value = '';
            alCambiarFiltro();
        });

        ui.paginador.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-pagina]');
            if (!btn || btn.disabled) return;
            estado.pagina = Number(btn.dataset.pagina);
            cargar();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        ui.tbody.addEventListener('click', (ev) => {
            const fila = ev.target.closest('tr[data-id]');
            if (fila) abrirDetalle(fila.dataset.id);
        });
        ui.tbody.addEventListener('keydown', (ev) => {
            if (ev.key !== 'Enter') return;
            const fila = ev.target.closest('tr[data-id]');
            if (fila) abrirDetalle(fila.dataset.id);
        });

        marcarAtajoActivo();
        actualizarEnlaceExcel();
        cargar();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
