// Reportes imprimibles

(function () {
    'use strict';

    document.addEventListener('click', (ev) => {
        if (ev.target.closest('[data-imprimir]')) window.print();
    });
})();
