(function (w) {
    'use strict';

    const cuerpo = document.body;
    const CSRF = cuerpo.dataset.csrf || '';

    function el(tag, opciones = {}, hijos = []) {
        const nodo = document.createElement(tag);
        for (const [clave, valor] of Object.entries(opciones)) {
            if (valor === null || valor === undefined || valor === false) continue;
            if (clave === 'text') nodo.textContent = valor;
            else if (clave === 'class') nodo.className = valor;
            else if (clave === 'dataset') Object.assign(nodo.dataset, valor);
            else nodo.setAttribute(clave, valor === true ? '' : valor);
        }
        [].concat(hijos).forEach((h) => h && nodo.appendChild(h));
        return nodo;
    }

    function debounce(fn, ms) {
        let t;
        return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
    }

    async function peticion(url, opciones = {}) {
        const config = {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json', 'X-CSRF-Token': CSRF },
            ...opciones,
        };

        let res;
        try {
            res = await fetch(url, config);
        } catch (err) {
            if (err.name === 'AbortError') throw err;
            return { status: 'error', title: 'Error de red', message: 'No se pudo conectar con el servidor.' };
        }

        let data;
        try {
            data = await res.json();
        } catch (_) {
            const pistas = {
                404: 'La acción no está registrada en la lista de rutas de public/index.php (error 404).',
                403: 'Su rol no tiene permiso para esta acción en public/index.php (error 403).',
                500: 'Error interno del servidor (500). Revise el log de errores de PHP (xampp/apache/logs/error.log).',
            };
            return {
                status: 'error',
                title: 'Respuesta inválida',
                message: pistas[res.status] || ('El servidor no devolvió una respuesta válida (código ' + res.status + ').'),
            };
        }
        data.httpStatus = res.status;
        return data;
    }

    const esExito = (d) => !!d && d.status === 'success';

    function alerta(icon, title, text) {
        return Swal.fire({ icon, title, text, confirmButtonColor: '#2563eb' });
    }

    function toast(texto) {
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: texto, showConfirmButton: false, timer: 2600, timerProgressBar: true });
    }

    const pila = [];

    function abrirModal(id) {
        const modal = document.getElementById(id);
        if (!modal || pila.includes(modal)) return;
        modal.classList.add('active');
        cuerpo.classList.add('modal-abierto');
        pila.push(modal);
    }

    function cerrarModal(modal) {
        const m = typeof modal === 'string' ? document.getElementById(modal) : (modal || pila[pila.length - 1]);
        if (!m) return;
        m.classList.remove('active');
        const i = pila.indexOf(m);
        if (i >= 0) pila.splice(i, 1);
        if (!pila.length) cuerpo.classList.remove('modal-abierto');
    }

    const modalAbierto = (id) => pila.includes(document.getElementById(id));

    function modalNativo(id) {
        const nodo = typeof id === 'string' ? document.getElementById(id) : id;
        return {
            show() { if (!nodo) return; nodo.classList.add('active'); nodo.setAttribute('aria-hidden', 'false'); document.body.classList.add('modal-abierto'); nodo.dispatchEvent(new CustomEvent('modal:shown')); },
            hide() { if (!nodo) return; nodo.classList.remove('active'); nodo.setAttribute('aria-hidden', 'true'); if (!document.querySelector('.modal.active')) document.body.classList.remove('modal-abierto'); nodo.dispatchEvent(new CustomEvent('modal:hidden')); }
        };
    }

    document.addEventListener('click', (ev) => {
        const cerrar = ev.target.closest('[data-cerrar-modal]');
        if (cerrar) {
            const modal = cerrar.closest('.modal, .modal-backdrop');
            if (modal) modalNativo(modal).hide();
            const alerta = cerrar.closest('.mensaje');
            if (alerta) alerta.remove();
        }
        const toggle = ev.target.closest('[data-menu-toggle]');
        if (toggle) { const menu = document.getElementById(toggle.dataset.menuToggle); if (menu) menu.classList.toggle('menu-visible'); }
        if (ev.target.classList.contains('modal')) modalNativo(ev.target).hide();
    });

    document.addEventListener('keydown', (ev) => {
        if (ev.key === 'Escape') document.querySelectorAll('.modal.active').forEach((m) => modalNativo(m).hide());
    });

    document.addEventListener('click', (ev) => {
        if (ev.target.closest('[data-cerrar-modal]')) {
            cerrarModal(ev.target.closest('.modal-backdrop'));
        } else if (ev.target.classList.contains('modal-backdrop')) {
            cerrarModal(ev.target);
        }
    });

    document.addEventListener('keydown', (ev) => {
        if (ev.key !== 'Escape' || !pila.length) return;
        const popup = window.Swal && Swal.isVisible() ? Swal.getPopup() : null;
        const dialogoAbierto = popup && !popup.classList.contains('swal2-toast');
        if (!dialogoAbierto) cerrarModal();
    });

    function dibujarPaginacion(contenedor, { pagina, totalPaginas }) {
        contenedor.replaceChildren();
        contenedor.hidden = totalPaginas <= 1;
        if (totalPaginas <= 1) return;

        const boton = (texto, destino, { activa = false, deshabilitado = false, etiqueta } = {}) =>
            el('button', {
                type: 'button', text: texto, class: activa ? 'activa' : '',
                disabled: deshabilitado, 'aria-label': etiqueta, 'aria-current': activa ? 'page' : null,
                dataset: { pagina: destino },
            });

        contenedor.appendChild(boton('‹', pagina - 1, { deshabilitado: pagina === 1, etiqueta: 'Página anterior' }));

        const visibles = new Set([1, totalPaginas, pagina - 1, pagina, pagina + 1]);
        let previa = 0;
        [...visibles].filter((p) => p >= 1 && p <= totalPaginas).sort((a, b) => a - b).forEach((p) => {
            if (p - previa > 1) contenedor.appendChild(el('span', { class: 'puntos', text: '…' }));
            contenedor.appendChild(boton(String(p), p, { activa: p === pagina, etiqueta: 'Página ' + p }));
            previa = p;
        });

        contenedor.appendChild(boton('›', pagina + 1, { deshabilitado: pagina === totalPaginas, etiqueta: 'Página siguiente' }));
    }

    function limpiarErrores(form) {
        form.querySelectorAll('.campo-error').forEach((s) => { s.textContent = ''; });
        form.querySelectorAll('.invalido').forEach((c) => c.classList.remove('invalido'));
    }

    function marcarError(form, campo, mensaje) {
        const input = form.elements[campo];
        const aviso = form.querySelector('[data-error-for="' + campo + '"]');
        if (input) input.classList.add('invalido');
        if (aviso) aviso.textContent = mensaje;
    }

    function autoLimpiarErrores(form) {
        form.addEventListener('input', (ev) => {
            const campo = ev.target;
            if (campo.classList && campo.classList.contains('invalido')) {
                campo.classList.remove('invalido');
                const aviso = form.querySelector('[data-error-for="' + campo.name + '"]');
                if (aviso) aviso.textContent = '';
            }
        });
    }

    const fechaValida = (f) => (f && !String(f).startsWith('0000') ? f : '');

    w.Comun = {
        el, debounce, peticion, esExito, alerta, toast,
        abrirModal, cerrarModal, modalAbierto, modalNativo,
        dibujarPaginacion, limpiarErrores, marcarError, autoLimpiarErrores, fechaValida,
    };
})(window);
