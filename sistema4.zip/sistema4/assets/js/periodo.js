(function () {
    'use strict';

    const {
        el, debounce, peticion, esExito, alerta, toast,
        abrirModal, cerrarModal, modalAbierto,
        limpiarErrores, marcarError, autoLimpiarErrores,
    } = window.Comun;

    const cuerpo          = document.body;
    const BASE_URL        = cuerpo.dataset.baseUrl || '/';
    const PUEDE_GESTIONAR = cuerpo.dataset.puedeGestionar === '1';
    const PUEDE_REABRIR   = cuerpo.dataset.puedeReabrir === '1';
    const URL_CTRL        = BASE_URL + 'index.php?controller=periodo&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        busqueda: $('inputBusqueda'),
        btnNuevo: $('btnNuevoPeriodo'),
        tbody:    $('cuerpoTabla'),
        estado:   $('estadoTabla'),
        total:    $('contadorTotal'),
        form:     $('formPeriodo'),
        titulo:   $('tituloModalPeriodo'),
        nota:     $('notaNuevoPeriodo'),
        btnGuardar: $('btnGuardarPeriodo'),
        lista:    $('listaMomentos'),
        vacio:    $('momentosVacio'),
        aviso:    $('avisoPeriodo'),
        btnCrearMomentos: $('btnCrearMomentos'),
    };

    const estado = {
        periodos: [],
        periodoId: 0,
        datosMomentos: null,
    };

    const fechaLarga = (iso) => (iso ? iso.split('-').reverse().join('/') : '');
    const plural = (n, s, p) => n + ' ' + (n === 1 ? s : p);

    function post(accion, campos) {
        const cuerpoPost = new FormData();
        Object.entries(campos).forEach(([k, v]) => cuerpoPost.append(k, v));
        return peticion(URL_CTRL + accion, { method: 'POST', body: cuerpoPost });
    }

    async function cargarLista() {
        const data = await peticion(URL_CTRL + 'listar');

        if (!esExito(data)) {
            estado.periodos = [];
            ui.tbody.replaceChildren();
            mostrarEstado(data.message || 'No se pudo cargar el listado.', true);
            return;
        }

        estado.periodos = data.periodos;
        pintarLista();
    }

    function pintarLista() {
        const texto = ui.busqueda.value.trim().toLowerCase();
        const visibles = estado.periodos.filter((p) => p.nombre.toLowerCase().includes(texto));

        ui.total.textContent = visibles.length;
        ui.tbody.replaceChildren(...visibles.map(crearFila));
        mostrarEstado(visibles.length ? '' : (texto ? 'No se encontraron períodos con esa búsqueda.' : 'No hay períodos registrados. Cree el primero con “+ Nuevo Período”.'));
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('error', esError);
    }

    function crearFila(p) {
        const activo = p.estado === 'activo';

        // Puntos de avance: uno por momento, en rojo los cerrados
        const puntos = [];
        for (let i = 0; i < p.total_momentos; i++) {
            puntos.push(el('span', { class: 'punto' + (i < p.momentos_cerrados ? ' cerrado' : '') }));
        }
        const avance = el('span', { class: 'avance', title: p.momentos_cerrados + ' de ' + p.total_momentos + ' momentos cerrados' }, [
            ...puntos,
            el('small', { text: p.total_momentos ? p.momentos_cerrados + ' de ' + p.total_momentos : 'Sin momentos' }),
        ]);

        const botones = [
            el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Ver y cerrar momentos', dataset: { accion: 'momentos', id: p.id }, text: '📅 Momentos' }),
        ];
        if (PUEDE_GESTIONAR) {
            botones.push(el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Cambiar nombre', 'aria-label': 'Renombrar ' + p.nombre, dataset: { accion: 'editar', id: p.id }, text: '✏️' }));
            if (activo) {
                botones.push(el('button', { type: 'button', class: 'boton boton-peligro boton-sm', dataset: { accion: 'cerrar-periodo', id: p.id }, text: '🔒 Cerrar período' }));
            }
        }
        if (PUEDE_REABRIR) {
            if (!activo) {
                botones.push(el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', dataset: { accion: 'abrir-periodo', id: p.id }, text: '🔓 Reabrir' }));
            }
            botones.push(el('button', { type: 'button', class: 'boton boton-peligro boton-sm', title: 'Eliminar', 'aria-label': 'Eliminar ' + p.nombre, dataset: { accion: 'eliminar', id: p.id }, text: '🗑' }));
        }

        return el('tr', {}, [
            el('td', { class: 'nombre', text: p.nombre }),
            el('td', {}, el('span', { class: 'insignia-pildora ' + (activo ? 'insignia-activo' : 'insignia-cerrado'), text: activo ? 'Activo' : 'Cerrado' })),
            el('td', { text: plural(p.total_secciones, 'sección', 'secciones') }),
            el('td', {}, avance),
            el('td', { class: 'acciones' }, el('div', { class: 'grupo' }, botones)),
        ]);
    }

    function sugerirNombre() {
        const ultimo = estado.periodos.map((p) => p.nombre).sort().pop();
        const m = ultimo && /^(\d{4})-(\d{4})$/.exec(ultimo);
        const inicio = m ? Number(m[2]) : new Date().getFullYear();
        return inicio + '-' + (inicio + 1);
    }

    function abrirNuevo() {
        ui.form.reset();
        limpiarErrores(ui.form);
        ui.form.elements.id.value = '0';
        ui.form.elements.nombre.value = sugerirNombre();
        ui.titulo.textContent = 'Nuevo Período Académico';
        ui.nota.hidden = false;
        abrirModal('modalPeriodo');
        ui.form.elements.nombre.select();
    }

    function abrirEdicion(id) {
        const p = estado.periodos.find((x) => x.id === Number(id));
        if (!p) return;

        ui.form.reset();
        limpiarErrores(ui.form);
        ui.form.elements.id.value = p.id;
        ui.form.elements.nombre.value = p.nombre;
        ui.titulo.textContent = 'Cambiar nombre del período';
        ui.nota.hidden = true;
        abrirModal('modalPeriodo');
        ui.form.elements.nombre.select();
    }

    function errorNombre(nombre) {
        if (!nombre) return 'El año escolar es obligatorio.';
        if (!/^\d{4}-\d{4}$/.test(nombre)) return 'Use el formato AAAA-AAAA, por ejemplo 2026-2027.';
        const [a, b] = nombre.split('-').map(Number);
        if (b !== a + 1) return 'El segundo año debe ser el siguiente al primero (por ejemplo 2026-2027).';
        if (a < 2000 || a > 2100) return 'El año escolar debe estar entre 2000 y 2100.';
        return null;
    }

    async function enviarFormulario(ev) {
        ev.preventDefault();
        limpiarErrores(ui.form);

        const msg = errorNombre(ui.form.elements.nombre.value.trim());
        if (msg) {
            marcarError(ui.form, 'nombre', msg);
            ui.form.elements.nombre.focus();
            return;
        }

        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';
        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: new FormData(ui.form) });
        ui.btnGuardar.disabled = false;
        ui.btnGuardar.textContent = 'Guardar';

        if (esExito(data)) {
            cerrarModal($('modalPeriodo'));
            await cargarLista();
            toast(data.message);
            return;
        }

        if (data.errors) Object.entries(data.errors).forEach(([c, m]) => marcarError(ui.form, c, m));
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar el período.');
    }

    async function cambiarEstadoPeriodo(id, nuevoEstado) {
        const p = estado.periodos.find((x) => x.id === Number(id));
        if (!p) return;
        const cerrar = nuevoEstado === 'cerrado';

        const r = await Swal.fire({
            title: cerrar ? '¿Cerrar el período ' + p.nombre + '?' : '¿Reabrir el período ' + p.nombre + '?',
            text: cerrar
                ? 'Se cerrarán el período y todos sus momentos pendientes. Quedarán bloqueadas la modificación de calificaciones y de asistencias. Solo el administrador podrá reabrirlo.'
                : 'El período volverá a estar activo. Sus momentos seguirán cerrados: reábralos uno a uno si necesita modificarlos.',
            icon: cerrar ? 'warning' : 'question',
            showCancelButton: true,
            confirmButtonColor: cerrar ? '#dc2626' : '#2563eb',
            cancelButtonColor: '#64748b',
            confirmButtonText: cerrar ? 'Sí, cerrar período' : 'Sí, reabrir',
            cancelButtonText: 'Cancelar',
        });
        if (!r.isConfirmed) return;

        const data = await post('cambiarEstado', { id: p.id, estado: nuevoEstado });
        if (esExito(data)) {
            await Promise.all([cargarLista(), recargarMomentos()]);
            toast(data.message);
        } else {
            alerta('error', data.title || 'No se pudo cambiar', data.message || 'No se pudo cambiar el estado del período.');
        }
    }

    async function eliminarPeriodo(id) {
        const p = estado.periodos.find((x) => x.id === Number(id));
        if (!p) return;

        const r = await Swal.fire({
            title: '¿Eliminar el período ' + p.nombre + '?',
            text: 'Se eliminarán también sus momentos académicos. Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
        });
        if (!r.isConfirmed) return;

        const data = await post('eliminar', { id: p.id });
        if (esExito(data)) {
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'No se puede eliminar', data.message || 'No se pudo eliminar el período.');
        }
    }

    async function abrirMomentos(id) {
        estado.periodoId = Number(id);
        if (await recargarMomentos(true)) abrirModal('modalMomentos');
    }

    async function recargarMomentos(forzar = false) {
        if (!estado.periodoId || (!forzar && !modalAbierto('modalMomentos'))) return false;

        const data = await peticion(URL_CTRL + 'momentos&periodo=' + encodeURIComponent(estado.periodoId));
        if (!esExito(data)) {
            alerta('error', data.title || 'Error', data.message || 'No se pudieron cargar los momentos.');
            return false;
        }

        estado.datosMomentos = data;
        pintarMomentos(data);
        return true;
    }

    function pintarMomentos({ periodo, momentos }) {
        const activo = periodo.estado === 'activo';

        $('tituloMomentos').textContent = 'Momentos académicos — ' + periodo.nombre;
        ui.aviso.textContent = activo
            ? 'Período activo. Los momentos se cierran en orden: 1er → 2do → 3er.'
            : 'Período cerrado: todos sus momentos están cerrados y bloqueados.';
        ui.aviso.className = 'estado-lista ' + (activo ? 'activo' : 'cerrado');

        ui.vacio.hidden = momentos.length > 0;
        ui.lista.hidden = momentos.length === 0;
        ui.lista.replaceChildren(...momentos.map((m, i) => crearMomento(m, i, momentos, activo)));
    }

    function crearMomento(m, i, momentos, periodoActivo) {
        const cerrado = m.estado === 'cerrado';

        const datos = [
            el('span', { text: cerrado ? 'Cierre: ' + (fechaLarga(m.fecha_cierre) || 'sin fecha registrada') : 'Abierto para modificaciones' }),
            el('span', { text: 'Calificaciones: ' + m.total_calificaciones }),
            el('span', { class: !cerrado && m.sin_calificar > 0 ? 'alerta' : '', text: 'Sin calificar: ' + m.sin_calificar }),
        ];

        let boton = null;
        if (periodoActivo && !cerrado && PUEDE_GESTIONAR) {
            const pendiente = momentos.slice(0, i).find((x) => x.estado !== 'cerrado');
            boton = el('button', {
                type: 'button', class: 'boton boton-peligro boton-sm', dataset: { accion: 'cerrar-momento', id: m.id },
                disabled: !!pendiente, title: pendiente ? 'Cierre primero el ' + pendiente.nombre : 'Cerrar este momento',
                text: '🔒 Cerrar momento',
            });
        } else if (periodoActivo && cerrado && PUEDE_REABRIR) {
            const posterior = momentos.slice(i + 1).find((x) => x.estado === 'cerrado');
            boton = el('button', {
                type: 'button', class: 'boton boton-contorno-secundario boton-sm', dataset: { accion: 'abrir-momento', id: m.id },
                disabled: !!posterior, title: posterior ? 'Reabra primero el ' + posterior.nombre : 'Reabrir este momento',
                text: '🔓 Reabrir',
            });
        }

        return el('li', { class: 'momento' + (cerrado ? ' cerrado' : '') }, [
            el('div', { class: 'momento-info' }, [
                el('strong', { text: m.nombre }),
                el('div', { class: 'momento-datos' }, datos),
            ]),
            el('div', { class: 'momento-acciones' }, [
                el('span', { class: 'insignia-pildora ' + (cerrado ? 'insignia-cerrado' : 'insignia-activo'), text: cerrado ? 'Cerrado' : 'Activo' }),
                boton,
            ]),
        ]);
    }

    async function cambiarEstadoMomento(id, nuevoEstado) {
        const datos = estado.datosMomentos;
        const m = datos && datos.momentos.find((x) => x.id === Number(id));
        if (!m) return;
        const cerrar = nuevoEstado === 'cerrado';

        let texto;
        if (cerrar) {
            texto = 'Se cerrará el ' + m.nombre + ' del período ' + datos.periodo.nombre + '. ';
            if (m.sin_calificar > 0) texto += 'Hay ' + plural(m.sin_calificar, 'estudiante sin calificar', 'estudiantes sin calificar') + ' y ya no podrán calificarse. ';
            texto += 'Quedarán bloqueadas la modificación de sus calificaciones y de la asistencia del momento. Solo el administrador podrá reabrirlo.';
        } else {
            texto = 'Se reabrirá el ' + m.nombre + ': sus calificaciones y asistencias podrán modificarse de nuevo.';
        }

        const r = await Swal.fire({
            title: cerrar ? '¿Cerrar el ' + m.nombre + '?' : '¿Reabrir el ' + m.nombre + '?',
            text: texto,
            icon: cerrar ? 'warning' : 'question',
            showCancelButton: true,
            confirmButtonColor: cerrar ? '#dc2626' : '#2563eb',
            cancelButtonColor: '#64748b',
            confirmButtonText: cerrar ? 'Sí, cerrar momento' : 'Sí, reabrir',
            cancelButtonText: 'Cancelar',
        });
        if (!r.isConfirmed) return;

        const data = await post('cambiarEstadoMomento', { momento_id: m.id, estado: nuevoEstado });
        if (esExito(data)) {
            await Promise.all([cargarLista(), recargarMomentos()]);
            toast(data.message);
        } else {
            alerta('error', data.title || 'No se pudo cambiar', data.message || 'No se pudo cambiar el estado del momento.');
        }
    }

    async function crearMomentos() {
        if (!estado.periodoId) return;

        ui.btnCrearMomentos.disabled = true;
        const data = await post('crearMomentos', { periodo_id: estado.periodoId });
        ui.btnCrearMomentos.disabled = false;

        if (esExito(data)) {
            await Promise.all([cargarLista(), recargarMomentos()]);
            toast(data.message);
        } else {
            alerta('error', data.title || 'Error', data.message || 'No se pudieron crear los momentos.');
        }
    }

    function init() {
        ui.busqueda.addEventListener('input', debounce(pintarLista, 200));

        ui.tbody.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn) return;
            const { accion, id } = btn.dataset;
            if (accion === 'momentos') abrirMomentos(id);
            else if (accion === 'editar') abrirEdicion(id);
            else if (accion === 'cerrar-periodo') cambiarEstadoPeriodo(id, 'cerrado');
            else if (accion === 'abrir-periodo') cambiarEstadoPeriodo(id, 'activo');
            else if (accion === 'eliminar') eliminarPeriodo(id);
        });

        ui.lista.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn || btn.disabled) return;
            if (btn.dataset.accion === 'cerrar-momento') cambiarEstadoMomento(btn.dataset.id, 'cerrado');
            else if (btn.dataset.accion === 'abrir-momento') cambiarEstadoMomento(btn.dataset.id, 'activo');
        });
        if (ui.btnCrearMomentos) ui.btnCrearMomentos.addEventListener('click', crearMomentos);

        if (PUEDE_GESTIONAR) {
            ui.btnNuevo.addEventListener('click', abrirNuevo);
            ui.form.addEventListener('submit', enviarFormulario);
            autoLimpiarErrores(ui.form);

            const nombre = ui.form.elements.nombre;
            nombre.addEventListener('input', () => { nombre.value = nombre.value.replace(/[^\d-]/g, ''); });
        }

        cargarLista();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
