// Módulo de documentos (app/Views/boletin/*)
(function () {
    'use strict';

    document.addEventListener('click', function (ev) {
        if (ev.target.closest('[data-imprimir]')) window.print();
    });

    document.addEventListener('change', function (ev) {
        var s = ev.target.closest('select[data-autosubmit]');
        if (s && s.form) s.form.submit();
    });

    document.addEventListener('DOMContentLoaded', function () {
        if (document.body.dataset.autoImprimir === '1') {
            setTimeout(function () { window.print(); }, 300);
        }
    });
})();
