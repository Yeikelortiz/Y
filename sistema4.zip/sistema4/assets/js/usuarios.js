(function () {
    'use strict';

    const { el, debounce, peticion, esExito, alerta, toast } = window.Comun;

    const cuerpo   = document.body;
    const BASE_URL = cuerpo.dataset.baseUrl || '/';
    const YO       = Number(cuerpo.dataset.yo || 0);
    const URL_CTRL = BASE_URL + 'index.php?controller=admin&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        busqueda:  $('inputBusqueda'),
        filtroRol: $('selectFiltroRol'),
        btnNuevo:  $('btnNuevoUsuario'),
        tbody:     $('cuerpoTabla'),
        estado:    $('estadoTabla'),
        total:     $('contadorTotal'),
        form:      $('formUsuario'),
        titulo:    $('tituloModalUsuario'),
        btnGuardar: $('btnGuardarUsuario'),
        btnVerPass: $('btnVerPassword'),
        iconoPass:  $('iconoPassword'),
    };

    const modal = window.Comun.modalNativo('modalUsuario');

    const estado = {
        usuarios: new Map(),
        abortar: null,
    };

    const ROLES = {
        admin:      { texto: 'Administrador', clase: 'u-f-peligro u-t-blanco' },
        director:   { texto: 'Director',      clase: 'u-f-aviso u-t-oscuro' },
        secretaria: { texto: 'Secretaria',    clase: 'u-f-info u-t-oscuro' },
    };

    const REGEX_NOMBRE = /^\p{L}[\p{L}\s'.\-]*$/u;
    const REGEX_EMAIL  = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Sin usar Date para evitar desfases de zona
    function formatearFecha(valor, conHora = false) {
        if (!valor) return '—';
        const [fecha, hora = ''] = String(valor).split(' ');
        const [a, m, d] = fecha.split('-');
        return d + '/' + m + '/' + a + (conHora && hora ? ' ' + hora.slice(0, 5) : '');
    }

    const icono = (clases) => el('i', { class: 'icono ' + clases });

    async function cargarLista() {
        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        const params = new URLSearchParams({ busqueda: ui.busqueda.value.trim(), rol: ui.filtroRol.value });

        let data;
        try {
            data = await peticion(URL_CTRL + 'usuarios&' + params, { signal: estado.abortar.signal });
        } catch (_) {
            return;
        }

        if (!esExito(data)) {
            ui.tbody.replaceChildren();
            mostrarEstado(data.message || 'No se pudo cargar la lista de usuarios.', true);
            return;
        }

        estado.usuarios = new Map(data.usuarios.map((u) => [u.id, u]));
        ui.total.textContent = data.total;
        ui.tbody.replaceChildren(...data.usuarios.map(crearFila));
        mostrarEstado(data.usuarios.length ? '' : 'No hay usuarios que coincidan con la búsqueda.');
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('u-t-peligro', esError);
        ui.estado.classList.toggle('u-t-suave', !esError);
        ui.estado.hidden = texto === '';
    }

    function crearFila(u) {
        const rol = ROLES[u.rol] || { texto: u.rol, clase: 'u-f-secundario u-t-blanco' };
        const esYo = u.id === YO;

        const celdaNombre = el('td', { class: 'u-negrita u-t-oscuro' }, [
            el('span', { text: u.nombre }),
            esYo ? el('span', { class: 'insignia u-f-exito-suave u-t-exito u-ms-2', text: 'Tú' }) : null,
        ]);

        const celdaEstado = u.bloqueado
            ? el('span', { class: 'insignia u-f-peligro-suave u-t-peligro', title: u.intentos_fallidos + ' intentos fallidos' }, [icono('icono-lock-fill u-me-1'), document.createTextNode('Bloqueado')])
            : el('span', { class: 'insignia u-f-exito-suave u-t-exito', text: 'Activo' });

        const botones = [
            el('button', { type: 'button', class: 'boton boton-sm boton-contorno-primario', title: 'Editar', 'aria-label': 'Editar a ' + u.nombre, dataset: { accion: 'editar', id: u.id } }, icono('icono-pencil')),
        ];
        if (u.bloqueado) {
            botones.push(el('button', { type: 'button', class: 'boton boton-sm boton-contorno-aviso', title: 'Desbloquear cuenta', 'aria-label': 'Desbloquear a ' + u.nombre, dataset: { accion: 'desbloquear', id: u.id } }, icono('icono-unlock')));
        }
        botones.push(el('button', {
            type: 'button', class: 'boton boton-sm boton-contorno-peligro',
            title: esYo ? 'No puedes eliminar tu propia cuenta' : 'Eliminar usuario',
            'aria-label': 'Eliminar a ' + u.nombre, disabled: esYo,
            dataset: { accion: 'eliminar', id: u.id },
        }, icono('icono-trash')));

        return el('tr', {}, [
            el('td', { class: 'u-ps-4 u-seminegrita u-t-secundario', text: '#' + u.id }),
            celdaNombre,
            el('td', { class: 'u-t-suave', text: u.email }),
            el('td', {}, el('span', { class: 'insignia u-px-2 u-py-1 ' + rol.clase, text: rol.texto })),
            el('td', {}, celdaEstado),
            el('td', { class: 'u-t-suave u-pequeno', text: formatearFecha(u.created_at) }),
            el('td', { class: 'u-t-suave u-pequeno', text: formatearFecha(u.ultima_sesion, true) }),
            el('td', { class: 'u-der u-pe-4' }, el('div', { class: 'u-inline-flex u-gap-1' }, botones)),
        ]);
    }

    function limpiarErrores() {
        ui.form.querySelectorAll('[data-error-for]').forEach((s) => { s.textContent = ''; });
        ui.form.querySelectorAll('.is-invalid').forEach((c) => c.classList.remove('is-invalid'));
    }

    function marcarError(campo, mensaje) {
        const input = ui.form.elements[campo];
        const aviso = ui.form.querySelector('[data-error-for="' + campo + '"]');
        if (input) input.classList.add('is-invalid');
        if (aviso) aviso.textContent = mensaje;
    }

    function prepararPassword(esNuevo) {
        $('marcaPasswordObligatoria').classList.toggle('u-oculto', !esNuevo);
        $('marcaPasswordOpcional').classList.toggle('u-oculto', esNuevo);
        ui.form.elements.password.placeholder = esNuevo ? '••••••••' : 'Dejar en blanco para mantener la actual';
        ui.form.elements.password.type = 'password';
        ui.iconoPass.className = 'icono icono-eye';
    }

    function bloquearRolPropio(bloquear, rolActual) {
        const select = ui.form.elements.rol;
        [...select.options].forEach((o) => { o.disabled = bloquear && o.value !== '' && o.value !== rolActual; });
        $('notaRolPropio').classList.toggle('u-oculto', !bloquear);
    }

    function abrirNuevo() {
        ui.form.reset();
        limpiarErrores();
        ui.form.elements.id.value = '0';
        ui.titulo.textContent = 'Registrar Nuevo Usuario';
        prepararPassword(true);
        bloquearRolPropio(false);
        modal.show();
    }

    function abrirEdicion(id) {
        const u = estado.usuarios.get(Number(id));
        if (!u) return;

        ui.form.reset();
        limpiarErrores();
        const f = ui.form.elements;
        f.id.value     = u.id;
        f.nombre.value = u.nombre;
        f.email.value  = u.email;
        f.rol.value    = u.rol;

        ui.titulo.textContent = 'Editar Usuario #' + u.id;
        prepararPassword(false);
        bloquearRolPropio(u.id === YO && u.rol === 'admin', u.rol);
        modal.show();
    }

    function validar() {
        const f = ui.form.elements;
        const errores = {};
        const esNuevo = f.id.value === '0';

        const nombre = f.nombre.value.trim();
        if (!nombre) errores.nombre = 'El nombre completo es obligatorio.';
        else if (nombre.length < 3 || nombre.length > 100) errores.nombre = 'Debe tener entre 3 y 100 caracteres.';
        else if (!REGEX_NOMBRE.test(nombre)) errores.nombre = 'Solo letras y espacios.';

        const email = f.email.value.trim();
        if (!email) errores.email = 'El correo electrónico es obligatorio.';
        else if (!REGEX_EMAIL.test(email)) errores.email = 'Ingrese un correo válido.';

        if (!f.rol.value) errores.rol = 'Seleccione un rol.';

        const clave = f.password.value;
        if (!clave) {
            if (esNuevo) errores.password = 'La contraseña es obligatoria.';
        } else if (!(clave.length >= 7 && /[A-Z]/.test(clave) && /[a-z]/.test(clave) && /[0-9]/.test(clave) && /[\W_]/.test(clave))) {
            errores.password = 'Mínimo 7 caracteres, con mayúscula, minúscula, número y símbolo.';
        }

        return errores;
    }

    async function enviarFormulario(ev) {
        ev.preventDefault();
        limpiarErrores();

        const errores = validar();
        const campos = Object.keys(errores);
        if (campos.length) {
            campos.forEach((c) => marcarError(c, errores[c]));
            ui.form.elements[campos[0]].focus();
            return;
        }

        const textoOriginal = ui.btnGuardar.innerHTML;
        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';

        const data = await peticion(URL_CTRL + 'guardarUsuario', { method: 'POST', body: new FormData(ui.form) });

        ui.btnGuardar.disabled = false;
        ui.btnGuardar.innerHTML = textoOriginal;

        if (esExito(data)) {
            modal.hide();
            await cargarLista();
            toast(data.message);
            return;
        }

        if (data.errors) Object.entries(data.errors).forEach(([c, m]) => marcarError(c, m));
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar el usuario.');
    }

    async function confirmarEliminacion(id) {
        const u = estado.usuarios.get(Number(id));
        if (!u) return;

        const respuesta = await Swal.fire({
            title: '¿Eliminar usuario?',
            text: u.nombre + ' (' + u.email + '). Se revocarán todos sus accesos al sistema. Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
        });
        if (!respuesta.isConfirmed) return;

        await accionSimple('eliminarUsuario', u.id, 'No se pudo eliminar el usuario.');
    }

    async function confirmarDesbloqueo(id) {
        const u = estado.usuarios.get(Number(id));
        if (!u) return;

        const respuesta = await Swal.fire({
            title: '¿Desbloquear cuenta?',
            text: u.nombre + ' podrá iniciar sesión nuevamente.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#10b981',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, desbloquear',
            cancelButtonText: 'Cancelar',
        });
        if (!respuesta.isConfirmed) return;

        await accionSimple('desbloquearUsuario', u.id, 'No se pudo desbloquear la cuenta.');
    }

    async function accionSimple(accion, id, mensajeError) {
        const cuerpoPost = new FormData();
        cuerpoPost.append('id', id);
        const data = await peticion(URL_CTRL + accion, { method: 'POST', body: cuerpoPost });

        if (esExito(data)) {
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'Error', data.message || mensajeError);
        }
    }

    function init() {
        ui.busqueda.addEventListener('input', debounce(cargarLista, 300));
        ui.filtroRol.addEventListener('change', cargarLista);

        ui.tbody.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn || btn.disabled) return;
            const { accion, id } = btn.dataset;
            if (accion === 'editar') abrirEdicion(id);
            else if (accion === 'eliminar') confirmarEliminacion(id);
            else if (accion === 'desbloquear') confirmarDesbloqueo(id);
        });

        ui.btnNuevo.addEventListener('click', abrirNuevo);
        ui.form.addEventListener('submit', enviarFormulario);
        $('modalUsuario').addEventListener('modal:shown', () => ui.form.elements.nombre.focus());

        ui.form.addEventListener('input', (ev) => {
            const campo = ev.target;
            if (campo.classList.contains('is-invalid')) {
                campo.classList.remove('is-invalid');
                const aviso = ui.form.querySelector('[data-error-for="' + campo.name + '"]');
                if (aviso) aviso.textContent = '';
            }
        });
        ui.form.elements.rol.addEventListener('change', () => ui.form.elements.rol.classList.remove('is-invalid'));

        ui.btnVerPass.addEventListener('click', () => {
            const campo = ui.form.elements.password;
            const oculta = campo.type === 'password';
            campo.type = oculta ? 'text' : 'password';
            ui.iconoPass.className = oculta ? 'icono icono-eye-slash' : 'icono icono-eye';
        });

        cargarLista();

        const params = new URLSearchParams(window.location.search);
        if (params.get('nuevo') === '1') {
            abrirNuevo();
            params.delete('nuevo');
            const resto = params.toString();
            history.replaceState(null, '', window.location.pathname + (resto ? '?' + resto : ''));
        }
    }

    document.addEventListener('DOMContentLoaded', init);
})();
