(function () {
    'use strict';

    const cuerpo      = document.body;
    const BASE_URL    = cuerpo.dataset.baseUrl || '/';
    const CSRF        = cuerpo.dataset.csrf || '';
    const PUEDE_EDITAR = cuerpo.dataset.puedeEditar === '1';
    const URL_CTRL    = BASE_URL + 'index.php?controller=estudiante&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        busqueda:   $('inputBusqueda'),
        btnLimpiar: $('btnLimpiarBusqueda'),
        btnNuevo:   $('btnNuevoEstudiante'),
        tbody:      $('cuerpoTabla'),
        estado:     $('estadoTabla'),
        total:      $('contadorTotal'),
        paginacion: $('paginacion'),
        form:       $('formEstudiante'),
        btnGuardar: $('btnGuardar'),
        titulo:     $('tituloModalEstudiante'),
        notaRep:    $('notaRepresentante'),
    };

    const estado = {
        pagina: 1,
        busqueda: '',
        estudiantes: new Map(),
        abortar: null,
    };

    function el(tag, opciones = {}, hijos = []) {
        const nodo = document.createElement(tag);
        for (const [clave, valor] of Object.entries(opciones)) {
            if (valor === null || valor === undefined || valor === false) continue;
            if (clave === 'text') nodo.textContent = valor;
            else if (clave === 'class') nodo.className = valor;
            else if (clave === 'dataset') Object.assign(nodo.dataset, valor);
            else nodo.setAttribute(clave, valor === true ? '' : valor);
        }
        [].concat(hijos).forEach((h) => h && nodo.appendChild(h));
        return nodo;
    }

    function debounce(fn, ms) {
        let t;
        return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
    }

    async function peticion(url, opciones = {}) {
        const config = {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json', 'X-CSRF-Token': CSRF },
            ...opciones,
        };
        let res;
        try {
            res = await fetch(url, config);
        } catch (err) {
            if (err.name === 'AbortError') throw err;
            return { status: 'error', title: 'Error de red', message: 'No se pudo conectar con el servidor.' };
        }

        let data;
        try {
            data = await res.json();
        } catch (_) {
            return { status: 'error', title: 'Respuesta inválida', message: 'El servidor no devolvió una respuesta válida (código ' + res.status + ').' };
        }
        if (res.status === 401) {
            data.message = data.message || 'Su sesión expiró. Inicie sesión nuevamente.';
        }
        data.httpStatus = res.status;
        return data;
    }

    const esExito = (d) => d && d.status === 'success';

    function alerta(icon, title, text) {
        if (typeof Swal !== 'undefined') {
            return Swal.fire({ icon, title, text, confirmButtonColor: '#2563eb' });
        }
        alert(title + ': ' + text);
    }

    function toast(texto) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: texto, showConfirmButton: false, timer: 2200, timerProgressBar: true });
        } else {
            alert(texto);
        }
    }

    const fechaValida = (f) => (f && !String(f).startsWith('0000') ? f : '');

    async function cargarLista() {
        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        ui.tbody.classList.add('cargando');
        const params = new URLSearchParams({ pagina: estado.pagina, busqueda: estado.busqueda });

        let data;
        try {
            data = await peticion(URL_CTRL + 'listar&' + params, { signal: estado.abortar.signal });
        } catch (_) {
            return;
        }
        ui.tbody.classList.remove('cargando');

        if (!esExito(data)) {
            ui.tbody.replaceChildren();
            ui.paginacion.hidden = true;
            mostrarEstado(data.message || 'No se pudo cargar el listado.', true);
            return;
        }

        const { estudiantes, paginacion } = data;
        estado.pagina = paginacion.pagina;
        estado.estudiantes = new Map(estudiantes.map((e) => [Number(e.id), e]));

        ui.total.textContent = paginacion.total;
        ui.tbody.replaceChildren(...estudiantes.map(crearFila));
        mostrarEstado(estudiantes.length ? '' : (estado.busqueda ? 'No se encontraron coincidencias con la búsqueda.' : 'No hay estudiantes registrados.'));
        dibujarPaginacion(paginacion);
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('error', esError);
    }

    function crearFila(e) {
        const nombre = (e.nombres + ' ' + e.apellidos).trim();
        const sinSeccion = !e.seccion_nombre;

        const celdas = [
            el('td', {}, el('code', { text: e.cedula_escolar })),
            el('td', { class: 'nombre', text: nombre }),
            el('td', { text: e.edad !== null && e.edad !== undefined ? e.edad + ' años' : '—' }),
            el('td', {}, el('span', { class: 'insignia-pildora ' + (sinSeccion ? 'insignia-muted' : 'insignia-primaria'), text: sinSeccion ? 'Sin asignar' : e.seccion_nombre })),
            el('td', {}, el('button', { type: 'button', class: 'enlace', dataset: { accion: 'ver-rep', cedula: e.representante_cedula }, text: e.representante_cedula })),
        ];

        if (PUEDE_EDITAR) {
            celdas.push(el('td', { class: 'acciones' }, el('div', { class: 'grupo' }, [
                el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Editar', 'aria-label': 'Editar ' + nombre, dataset: { accion: 'editar', id: e.id }, text: '✏️' }),
                el('button', { type: 'button', class: 'boton boton-peligro boton-sm', title: 'Eliminar', 'aria-label': 'Eliminar ' + nombre, dataset: { accion: 'eliminar', id: e.id }, text: '🗑' }),
            ])));
        }

        return el('tr', {}, celdas);
    }

    function dibujarPaginacion({ pagina, totalPaginas }) {
        ui.paginacion.replaceChildren();
        ui.paginacion.hidden = totalPaginas <= 1;
        if (totalPaginas <= 1) return;

        const boton = (texto, destino, { activa = false, deshabilitado = false, etiqueta } = {}) =>
            el('button', {
                type: 'button', text: texto, class: activa ? 'activa' : '',
                disabled: deshabilitado, 'aria-label': etiqueta, 'aria-current': activa ? 'page' : null,
                dataset: { pagina: destino },
            });

        ui.paginacion.appendChild(boton('‹', pagina - 1, { deshabilitado: pagina === 1, etiqueta: 'Página anterior' }));

        const visibles = new Set([1, totalPaginas, pagina - 1, pagina, pagina + 1]);
        let previa = 0;
        [...visibles].filter((p) => p >= 1 && p <= totalPaginas).sort((a, b) => a - b).forEach((p) => {
            if (p - previa > 1) ui.paginacion.appendChild(el('span', { class: 'puntos', text: '…' }));
            ui.paginacion.appendChild(boton(String(p), p, { activa: p === pagina, etiqueta: 'Página ' + p }));
            previa = p;
        });

        ui.paginacion.appendChild(boton('›', pagina + 1, { deshabilitado: pagina === totalPaginas, etiqueta: 'Página siguiente' }));
    }

    let modalActivo = null;

    function abrirModal(id) {
        const modal = $(id);
        if (!modal) return;
        modal.classList.add('active');
        cuerpo.classList.add('modal-abierto');
        modalActivo = modal;
    }

    function cerrarModal(modal = modalActivo) {
        if (!modal) return;
        modal.classList.remove('active');
        cuerpo.classList.remove('modal-abierto');
        modalActivo = null;
    }

    document.addEventListener('click', (ev) => {
        if (ev.target.closest('[data-cerrar-modal]')) {
            cerrarModal(ev.target.closest('.modal-backdrop'));
        } else if (ev.target.classList.contains('modal-backdrop')) {
            cerrarModal(ev.target);
        }
    });

    document.addEventListener('keydown', (ev) => {
        if (ev.key === 'Escape' && modalActivo) cerrarModal();
    });

    function limpiarErrores() {
        ui.form.querySelectorAll('.campo-error').forEach((s) => { s.textContent = ''; });
        ui.form.querySelectorAll('.invalido').forEach((c) => c.classList.remove('invalido'));
    }

    function marcarError(campo, mensaje) {
        const input = ui.form.elements[campo];
        const aviso = ui.form.querySelector('[data-error-for="' + campo + '"]');
        if (input) input.classList.add('invalido');
        if (aviso) aviso.textContent = mensaje;
    }

    function mostrarNotaRep(texto, tipo) {
        ui.notaRep.hidden = !texto;
        ui.notaRep.textContent = texto || '';
        ui.notaRep.className = 'form-nota' + (tipo ? ' nota-' + tipo : '');
    }

    function abrirNuevo() {
        ui.form.reset();
        limpiarErrores();
        mostrarNotaRep('');
        ui.form.elements.id.value = '0';
        ui.titulo.textContent = 'Registro de Inscripción';
        abrirModal('modalEstudiante');
        ui.form.elements.nombres.focus();
    }

    function abrirEdicion(id) {
        const e = estado.estudiantes.get(Number(id));
        if (!e) return;

        ui.form.reset();
        limpiarErrores();
        mostrarNotaRep('');
        ui.titulo.textContent = 'Editar Estudiante — ' + e.cedula_escolar;

        const f = ui.form.elements;
        f.id.value                   = e.id;
        f.nombres.value              = e.nombres || '';
        f.apellidos.value            = e.apellidos || '';
        f.fecha_nacimiento.value     = fechaValida(e.fecha_nacimiento);
        f.genero.value               = e.genero || '';
        f.seccion_id.value           = e.seccion_id || '';
        f.representante_cedula.value = e.representante_cedula || '';
        f.rep_nombre.value           = e.rep_nombre || '';
        f.rep_apellido.value         = e.rep_apellido || '';
        f.rep_telefono.value         = e.rep_telefono || '';
        f.rep_direccion.value        = e.rep_direccion || '';

        abrirModal('modalEstudiante');
        f.nombres.focus();
    }

    function validarCliente() {
        const f = ui.form.elements;
        const errores = {};
        const vacio = (c) => !f[c].value.trim();

        if (vacio('nombres')) errores.nombres = 'Los nombres son obligatorios.';
        if (vacio('apellidos')) errores.apellidos = 'Los apellidos son obligatorios.';

        if (!f.fecha_nacimiento.value) errores.fecha_nacimiento = 'La fecha de nacimiento es obligatoria.';
        else if (new Date(f.fecha_nacimiento.value) > new Date()) errores.fecha_nacimiento = 'La fecha no puede ser futura.';

        if (!f.genero.value) errores.genero = 'Seleccione el género.';
        if (!/^\d{6,10}$/.test(f.representante_cedula.value.trim())) errores.representante_cedula = 'Entre 6 y 10 dígitos, solo números.';
        if (vacio('rep_nombre')) errores.rep_nombre = 'Obligatorio.';
        if (vacio('rep_apellido')) errores.rep_apellido = 'Obligatorio.';
        if (!/^[0-9+\-\s()]{7,20}$/.test(f.rep_telefono.value.trim())) errores.rep_telefono = 'Teléfono no válido (7 a 20 caracteres).';
        if (vacio('rep_direccion')) errores.rep_direccion = 'Obligatoria.';

        return errores;
    }

    async function enviarFormulario(ev) {
        ev.preventDefault();
        limpiarErrores();

        const errores = validarCliente();
        const campos = Object.keys(errores);
        if (campos.length) {
            campos.forEach((c) => marcarError(c, errores[c]));
            ui.form.elements[campos[0]].focus();
            return;
        }

        const esNuevo = ui.form.elements.id.value === '0';
        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';

        const bodyData = new FormData(ui.form);
        bodyData.append('csrf_token', CSRF);

        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: bodyData });

        ui.btnGuardar.disabled = false;
        ui.btnGuardar.textContent = 'Guardar';

        if (esExito(data)) {
            cerrarModal($('modalEstudiante'));
            if (esNuevo) { estado.pagina = 1; estado.busqueda = ''; ui.busqueda.value = ''; ui.btnLimpiar.hidden = true; }
            await cargarLista();
            toast(data.message + (esNuevo && data.cedula_escolar ? ' Cédula escolar: ' + data.cedula_escolar : ''));
            return;
        }

        if (data.errors) {
            Object.entries(data.errors).forEach(([c, m]) => marcarError(c, m));
        }
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar.');
    }

    let ultimaCedulaConsultada = '';

    async function buscarRepresentanteParaFormulario() {
        const f = ui.form.elements;
        const cedula = f.representante_cedula.value.trim();
        if (!/^\d{6,10}$/.test(cedula) || cedula === ultimaCedulaConsultada) return;
        ultimaCedulaConsultada = cedula;

        const data = await peticion(URL_CTRL + 'obtenerRepresentante&cedula=' + encodeURIComponent(cedula));
        if (f.representante_cedula.value.trim() !== cedula) return;

        if (esExito(data)) {
            const r = data.representante;
            f.rep_nombre.value    = r.nombre || '';
            f.rep_apellido.value  = r.apellido || '';
            f.rep_telefono.value  = r.telefono || '';
            f.rep_direccion.value = r.direccion || '';
            const hijos = Number(r.num_hijo) || 0;
            mostrarNotaRep('Representante ya registrado (' + hijos + ' hijo' + (hijos === 1 ? '' : 's') + '). Sus datos se cargaron; si los modificas, se actualizarán.', 'ok');
        } else if (data.httpStatus === 404) {
            mostrarNotaRep('Representante nuevo: complete sus datos.', 'info');
        } else {
            mostrarNotaRep('');
        }
    }

    async function verRepresentante(cedula) {
        if (!cedula) {
            alerta('info', 'Información', 'El estudiante no tiene cédula de representante asociada.');
            return;
        }
        const data = await peticion(URL_CTRL + 'obtenerRepresentante&cedula=' + encodeURIComponent(cedula));
        if (!esExito(data)) {
            alerta('error', data.title || 'No encontrado', data.message || 'No se encontró el representante.');
            return;
        }
        const r = data.representante;
        $('verRepCedula').textContent    = r.cedula || '';
        $('verRepNombre').textContent    = ((r.nombre || '') + ' ' + (r.apellido || '')).trim();
        $('verRepTelefono').textContent  = r.telefono || 'No especificado';
        $('verRepDireccion').textContent = r.direccion || 'No especificada';
        $('verRepHijos').textContent     = r.num_hijo || 0;
        abrirModal('modalVerRepresentante');
    }

    async function confirmarEliminacion(id) {
        const e = estado.estudiantes.get(Number(id));
        if (!e) return;

        let confirmado = false;

        if (typeof Swal !== 'undefined') {
            const respuesta = await Swal.fire({
                title: '¿Eliminar estudiante?',
                text: e.nombres + ' ' + e.apellidos + ' (' + e.cedula_escolar + '). Esta acción no se puede deshacer.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc2626',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar',
            });
            confirmado = respuesta.isConfirmed;
        } else {
            confirmado = confirm('¿Eliminar a ' + e.nombres + ' ' + e.apellidos + ' (' + e.cedula_escolar + ')?');
        }

        if (!confirmado) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('id', e.id);
        cuerpoPost.append('csrf_token', CSRF);

        const data = await peticion(URL_CTRL + 'eliminar', { method: 'POST', body: cuerpoPost });

        if (esExito(data)) {
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'Error', data.message || 'No se pudo eliminar el registro.');
        }
    }

    function init() {
        const buscar = debounce(() => {
            estado.busqueda = ui.busqueda.value.trim();
            estado.pagina = 1;
            ui.btnLimpiar.hidden = estado.busqueda === '';
            cargarLista();
        }, 300);
        ui.busqueda.addEventListener('input', buscar);
        ui.btnLimpiar.addEventListener('click', () => {
            ui.busqueda.value = '';
            ui.busqueda.focus();
            buscar();
        });

        ui.paginacion.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-pagina]');
            if (!btn || btn.disabled) return;
            estado.pagina = Number(btn.dataset.pagina);
            cargarLista();
        });

        ui.tbody.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn) return;
            const { accion, id, cedula } = btn.dataset;
            if (accion === 'editar') abrirEdicion(id);
            else if (accion === 'eliminar') confirmarEliminacion(id);
            else if (accion === 'ver-rep') verRepresentante(cedula);
        });

        if (PUEDE_EDITAR && ui.form) {
            ui.btnNuevo.addEventListener('click', abrirNuevo);
            ui.form.addEventListener('submit', enviarFormulario);

            const cedulaRep = ui.form.elements.representante_cedula;
            cedulaRep.addEventListener('input', () => {
                cedulaRep.value = cedulaRep.value.replace(/\D/g, '');
                if (cedulaRep.value.trim() !== ultimaCedulaConsultada) mostrarNotaRep('');
            });
            cedulaRep.addEventListener('change', buscarRepresentanteParaFormulario);
            cedulaRep.addEventListener('blur', buscarRepresentanteParaFormulario);

            ui.form.addEventListener('input', (ev) => {
                const campo = ev.target;
                if (campo.classList && campo.classList.contains('invalido')) {
                    campo.classList.remove('invalido');
                    const aviso = ui.form.querySelector('[data-error-for="' + campo.name + '"]');
                    if (aviso) aviso.textContent = '';
                }
            });

            const reiniciarConsulta = () => { ultimaCedulaConsultada = ''; };
            ui.btnNuevo.addEventListener('click', reiniciarConsulta);
            ui.tbody.addEventListener('click', (ev) => {
                if (ev.target.closest('[data-accion="editar"]')) {
                    ultimaCedulaConsultada = ui.form.elements.representante_cedula.value.trim();
                }
            });
        }

        cargarLista();
    }

    document.addEventListener('DOMContentLoaded', init);
})();