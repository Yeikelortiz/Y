document.addEventListener('DOMContentLoaded', function () {


    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });


    const selectRol = document.getElementById('rol');
    const campoCedula = document.getElementById('campo-cedula');
    const inputCedula = document.getElementById('cedula');
    
    const campoCedulaEscolar = document.getElementById('campo-cedula-escolar');
    const inputCedulaEscolar = document.getElementById('cedula_escolar');

    function actualizarCamposRol() {
        if (!selectRol) return; 

        const valorRol = selectRol.value;

        if (campoCedula) campoCedula.style.display = 'none';
        if (inputCedula) inputCedula.removeAttribute('required');
        
        if (campoCedulaEscolar && inputCedulaEscolar) {
            campoCedulaEscolar.style.display = 'none';
            inputCedulaEscolar.removeAttribute('required');
        }

        if (valorRol === 'estudiante') {
            if (campoCedulaEscolar && inputCedulaEscolar) {
                campoCedulaEscolar.style.display = 'block';
                inputCedulaEscolar.setAttribute('required', 'required');
            }
        } else if (['secretaria', 'director', 'admin'].includes(valorRol)) {
            if (campoCedula) {
                campoCedula.style.display = 'block';
                if(inputCedula) inputCedula.setAttribute('required', 'required');
            }
        }
    }

    if (selectRol) {
        selectRol.addEventListener('change', actualizarCamposRol);
        actualizarCamposRol();
    }


    const togglePassBtn = document.getElementById('togglePass');
    const passInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');

    if (togglePassBtn && passInput && eyeIcon) {
        togglePassBtn.addEventListener('click', function () {
            const type = passInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passInput.setAttribute('type', type);
            
            eyeIcon.classList.toggle('icono-eye');
            eyeIcon.classList.toggle('icono-eye-slash');
        });
    }
    

    const inputBusqueda = document.getElementById('inputBusqueda');
    const selectFiltroRol = document.getElementById('selectFiltroRol');
    const filasUsuarios = document.querySelectorAll('.usuario-fila');

    function filtrarTabla() {
        const textoBusqueda = inputBusqueda ? inputBusqueda.value.toLowerCase().trim() : '';
        const rolSeleccionado = selectFiltroRol ? selectFiltroRol.value.toLowerCase().trim() : '';

        filasUsuarios.forEach(fila => {
            const nombre = fila.getAttribute('data-nombre') || '';
            const email = fila.getAttribute('data-email') || '';
            const rol = fila.getAttribute('data-rol') || '';

            const coincideTexto = nombre.includes(textoBusqueda) || email.includes(textoBusqueda);
            const coincideRol = (rolSeleccionado === '') || (rol === rolSeleccionado);

            if (coincideTexto && coincideRol) {
                fila.style.display = '';
            } else {
                fila.style.display = 'none';
            }
        });
    }

    if (inputBusqueda) {
        inputBusqueda.addEventListener('input', filtrarTabla);
    }
    if (selectFiltroRol) {
        selectFiltroRol.addEventListener('change', filtrarTabla);
    }

});