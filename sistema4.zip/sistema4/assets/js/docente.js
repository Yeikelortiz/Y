(function () {
    'use strict';

    const {
        el, debounce, peticion, esExito, alerta, toast,
        abrirModal, cerrarModal,
        dibujarPaginacion, limpiarErrores, marcarError, autoLimpiarErrores, fechaValida,
    } = window.Comun;

    const cuerpo         = document.body;
    const BASE_URL       = cuerpo.dataset.baseUrl || '/';
    const PUEDE_EDITAR   = cuerpo.dataset.puedeEditar === '1';
    const PUEDE_ELIMINAR = cuerpo.dataset.puedeEliminar === '1';
    const URL_CTRL       = BASE_URL + 'index.php?controller=docente&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        busqueda:   $('inputBusqueda'),
        btnLimpiar: $('btnLimpiarBusqueda'),
        btnNuevo:   $('btnNuevoDocente'),
        tbody:      $('cuerpoTabla'),
        estado:     $('estadoTabla'),
        total:      $('contadorTotal'),
        paginacion: $('paginacion'),
        form:       $('formDocente'),
        titulo:     $('tituloModalDocente'),
        btnGuardar: $('btnGuardar'),
    };

    const estado = {
        pagina: 1,
        busqueda: '',
        docentes: new Map(),
        abortar: null,
    };

    const REGEX_NOMBRE = /^\p{L}[\p{L}\s'.\-]*$/u;
    const REGEX_EMAIL  = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const plural = (n, s, p) => n + ' ' + (n === 1 ? s : p);

    async function cargarLista() {
        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        ui.tbody.classList.add('cargando');
        const params = new URLSearchParams({ pagina: estado.pagina, busqueda: estado.busqueda });

        let data;
        try {
            data = await peticion(URL_CTRL + 'listar&' + params, { signal: estado.abortar.signal });
        } catch (_) {
            return;
        }
        ui.tbody.classList.remove('cargando');

        if (!esExito(data)) {
            ui.tbody.replaceChildren();
            ui.paginacion.hidden = true;
            mostrarEstado(data.message || 'No se pudo cargar el listado.', true);
            return;
        }

        const { docentes, paginacion } = data;
        estado.pagina = paginacion.pagina;
        estado.docentes = new Map(docentes.map((d) => [d.id, d]));

        ui.total.textContent = paginacion.total;
        ui.tbody.replaceChildren(...docentes.map(crearFila));
        mostrarEstado(docentes.length ? '' : (estado.busqueda ? 'No se encontraron coincidencias con la búsqueda.' : 'No hay docentes registrados.'));
        dibujarPaginacion(ui.paginacion, paginacion);
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('error', esError);
    }

    function crearFila(d) {
        const nombre = (d.apellidos + ' ' + d.nombres).trim();
        const n = d.total_secciones;

        const celdas = [
            el('td', {}, el('code', { text: d.cedula })),
            el('td', { class: 'nombre', text: nombre }),
            el('td', {}, [
                el('div', { text: d.correo }),
                el('small', { class: 'sin-hijos', text: d.telefono || 'Sin teléfono' }),
            ]),
            el('td', {}, el('span', {
                class: 'insignia-pildora ' + (n > 0 ? 'insignia-primaria' : 'insignia-muted'),
                text: n > 0 ? plural(n, 'sección', 'secciones') : 'Sin secciones',
            })),
        ];

        if (PUEDE_EDITAR) {
            const botones = [
                el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Editar', 'aria-label': 'Editar a ' + nombre, dataset: { accion: 'editar', id: d.id }, text: '✏️' }),
            ];
            if (PUEDE_ELIMINAR) {
                botones.push(el('button', { type: 'button', class: 'boton boton-peligro boton-sm', title: 'Eliminar', 'aria-label': 'Eliminar a ' + nombre, dataset: { accion: 'eliminar', id: d.id }, text: '🗑' }));
            }
            celdas.push(el('td', { class: 'acciones' }, el('div', { class: 'grupo' }, botones)));
        }

        return el('tr', {}, celdas);
    }

    function abrirNuevo() {
        ui.form.reset();
        limpiarErrores(ui.form);
        ui.form.elements.id.value = '0';
        ui.titulo.textContent = 'Registrar Docente';
        abrirModal('modalDocente');
        ui.form.elements.cedula.focus();
    }

    function abrirEdicion(id) {
        const d = estado.docentes.get(Number(id));
        if (!d) return;

        ui.form.reset();
        limpiarErrores(ui.form);

        const f = ui.form.elements;
        f.id.value               = d.id;
        f.cedula.value           = d.cedula || '';
        f.nombres.value          = d.nombres || '';
        f.apellidos.value        = d.apellidos || '';
        f.fecha_nacimiento.value = fechaValida(d.fecha_nacimiento);
        f.genero.value           = d.genero || '';
        f.correo.value           = d.correo || '';
        f.telefono.value         = d.telefono || '';
        f.direccion.value        = d.direccion || '';

        ui.titulo.textContent = 'Editar Docente';
        abrirModal('modalDocente');
        f.nombres.focus();
    }

    function validar() {
        const f = ui.form.elements;
        const errores = {};

        if (!/^\d{5,20}$/.test(f.cedula.value.trim())) errores.cedula = 'Entre 5 y 20 dígitos, solo números.';

        const nombres = f.nombres.value.trim();
        const apellidos = f.apellidos.value.trim();
        if (!nombres) errores.nombres = 'Los nombres son obligatorios.';
        else if (!REGEX_NOMBRE.test(nombres)) errores.nombres = 'Solo letras y espacios.';
        if (!apellidos) errores.apellidos = 'Los apellidos son obligatorios.';
        else if (!REGEX_NOMBRE.test(apellidos)) errores.apellidos = 'Solo letras y espacios.';

        if (!f.fecha_nacimiento.value) {
            errores.fecha_nacimiento = 'La fecha de nacimiento es obligatoria.';
        } else {
            const limite = new Date();
            limite.setFullYear(limite.getFullYear() - 18);
            if (new Date(f.fecha_nacimiento.value) > limite) errores.fecha_nacimiento = 'Debe ser mayor de edad (18 años o más).';
        }

        if (!f.genero.value) errores.genero = 'Seleccione el género.';

        const correo = f.correo.value.trim();
        if (!correo) errores.correo = 'El correo es obligatorio.';
        else if (!REGEX_EMAIL.test(correo)) errores.correo = 'Ingrese un correo válido.';

        const telefono = f.telefono.value.trim();
        if (telefono && !/^[0-9+\-\s()]{7,20}$/.test(telefono)) errores.telefono = 'Teléfono no válido (7 a 20 caracteres).';

        return errores;
    }

    async function enviarFormulario(ev) {
        ev.preventDefault();
        limpiarErrores(ui.form);

        const errores = validar();
        const campos = Object.keys(errores);
        if (campos.length) {
            campos.forEach((c) => marcarError(ui.form, c, errores[c]));
            ui.form.elements[campos[0]].focus();
            return;
        }

        const esNuevo = ui.form.elements.id.value === '0';
        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';
        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: new FormData(ui.form) });
        ui.btnGuardar.disabled = false;
        ui.btnGuardar.textContent = 'Guardar';

        if (esExito(data)) {
            cerrarModal($('modalDocente'));
            if (esNuevo) { estado.pagina = 1; estado.busqueda = ''; ui.busqueda.value = ''; ui.btnLimpiar.hidden = true; }
            await cargarLista();
            toast(data.message);
            return;
        }

        if (data.errors) Object.entries(data.errors).forEach(([c, m]) => marcarError(ui.form, c, m));
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar el docente.');
    }

    async function confirmarEliminacion(id) {
        const d = estado.docentes.get(Number(id));
        if (!d) return;
        const nombre = (d.nombres + ' ' + d.apellidos).trim();

        if (d.total_secciones > 0) {
            alerta('info', 'No se puede eliminar',
                nombre + ' está asignado a ' + plural(d.total_secciones, 'sección', 'secciones') + '. Reasigne o quite el docente de esas secciones primero.');
            return;
        }

        const respuesta = await Swal.fire({
            title: '¿Eliminar docente?',
            text: nombre + ' (C.I. ' + d.cedula + '). Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
        });
        if (!respuesta.isConfirmed) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('id', d.id);
        const data = await peticion(URL_CTRL + 'eliminar', { method: 'POST', body: cuerpoPost });

        if (esExito(data)) {
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'No se puede eliminar', data.message || 'No se pudo eliminar el docente.');
        }
    }

    function init() {
        // Búsqueda con retardo para no consultar en cada tecla
        const buscar = debounce(() => {
            estado.busqueda = ui.busqueda.value.trim();
            estado.pagina = 1;
            ui.btnLimpiar.hidden = estado.busqueda === '';
            cargarLista();
        }, 300);
        ui.busqueda.addEventListener('input', buscar);
        ui.btnLimpiar.addEventListener('click', () => {
            ui.busqueda.value = '';
            ui.busqueda.focus();
            buscar();
        });

        ui.paginacion.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-pagina]');
            if (!btn || btn.disabled) return;
            estado.pagina = Number(btn.dataset.pagina);
            cargarLista();
        });

        ui.tbody.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn) return;
            const { accion, id } = btn.dataset;
            if (accion === 'editar') abrirEdicion(id);
            else if (accion === 'eliminar') confirmarEliminacion(id);
        });

        if (PUEDE_EDITAR && ui.form) {
            ui.btnNuevo.addEventListener('click', abrirNuevo);
            ui.form.addEventListener('submit', enviarFormulario);
            autoLimpiarErrores(ui.form);

            const cedula = ui.form.elements.cedula;
            cedula.addEventListener('input', () => { cedula.value = cedula.value.replace(/\D/g, ''); });
        }

        cargarLista();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
