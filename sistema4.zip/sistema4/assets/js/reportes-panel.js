(function () {
    'use strict';

    const { el, peticion, esExito, alerta, debounce } = window.Comun;

    const cuerpo   = document.body;
    const BASE_URL = cuerpo.dataset.baseUrl || '/';
    const HOY      = cuerpo.dataset.hoy || '';
    const URL_CTRL = BASE_URL + 'index.php?controller=reporte&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        tipo:      $('selectTipo'),
        periodo:   $('selectPeriodo'),
        seccion:   $('selectSeccion'),
        momento:   $('selectMomento'),
        grupos:    document.querySelectorAll('[data-para]'),
        btnGenerar: $('btnGenerar'),
        lnkExcel:  $('lnkExcel'),
        btnImprimir: $('btnImprimir'),
        panel:     $('panelReporte'),
        buscar:    $('buscarReporte'),
        cuerpoTabla: $('repCuerpo'),
        inicial:   $('repInicial'),
    };

    const estado = { abortar: null, hayVistaPrevia: false };

    function aplicarVisibilidad() {
        const tipo = ui.tipo.value;
        ui.grupos.forEach((g) => { g.hidden = !g.dataset.para.split(' ').includes(tipo); });
    }

    function visible(campo) {
        return !campo.closest('[data-para]').hidden;
    }

    function construirQuery() {
        const q = new URLSearchParams({ tipo: ui.tipo.value, periodo: ui.periodo.value });
        if (visible(ui.seccion) && ui.seccion.value !== '0') q.set('seccion', ui.seccion.value);
        if (visible(ui.momento) && ui.momento.value !== '0') q.set('momento', ui.momento.value);
        return q.toString();
    }

    function actualizarEnlaceExcel() {
        ui.lnkExcel.href = URL_CTRL + 'exportar&' + construirQuery();
    }

    const generarAuto = debounce(() => generar({ silencioso: true }), 250);

    function alCambiarFiltro() {
        actualizarEnlaceExcel();
        generarAuto();
    }

    async function cargarOpciones(seccionPreseleccionada = 0) {
        const periodoId = ui.periodo.value;
        ui.seccion.replaceChildren(el('option', { value: '0', text: 'Todas las secciones' }));
        ui.momento.replaceChildren(el('option', { value: '0', text: 'Todos los momentos' }));
        if (!periodoId) return;

        const data = await peticion(URL_CTRL + 'opciones&periodo=' + encodeURIComponent(periodoId));
        if (ui.periodo.value !== periodoId) return;

        if (!esExito(data)) {
            alerta('error', data.title || 'Error', data.message || 'No se pudieron cargar las secciones del período.');
            return;
        }

        ui.seccion.append(...data.secciones.map((s) => el('option', { value: s.id, text: s.etiqueta })));
        ui.momento.append(...data.momentos.map((m) => el('option', { value: m.id, text: m.nombre + (m.estado === 'activo' ? '' : ' (cerrado)') })));

        if (seccionPreseleccionada > 0 && data.secciones.some((s) => s.id === seccionPreseleccionada)) {
            ui.seccion.value = String(seccionPreseleccionada);
        }
    }

    function validarFiltros() {
        if (!ui.periodo.value) return 'Seleccione un período.';
        return null;
    }

    async function generar(opciones = {}) {
        const problema = validarFiltros();
        if (problema) {
            if (!opciones.silencioso) alerta('warning', 'Revise los filtros', problema);
            return;
        }

        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        ui.btnGenerar.disabled = true;
        const textoOriginal = ui.btnGenerar.textContent;
        ui.btnGenerar.textContent = 'Generando...';

        let data;
        try {
            data = await peticion(URL_CTRL + 'datos&' + construirQuery(), { signal: estado.abortar.signal });
        } catch (_) {
            return;
        } finally {
            ui.btnGenerar.disabled = false;
            ui.btnGenerar.textContent = textoOriginal;
        }

        if (!esExito(data)) {
            alerta('error', data.title || 'No se pudo generar', data.message || 'No se pudo generar el reporte.');
            return;
        }

        pintar(data.reporte);
    }

    function formatear(valor, tipo) {
        if (valor === null || valor === undefined || valor === '') return '—';
        if (tipo === 'porcentaje') return Number(valor).toFixed(1) + '%';
        return String(valor);
    }

    function pintar(r) {
        $('repTitulo').textContent = r.titulo;
        $('repTotal').textContent = r.filas.length;

        $('repFiltros').replaceChildren(...r.filtros.map(([etiqueta, valor]) =>
            el('li', {}, [el('strong', { text: etiqueta + ':' }), document.createTextNode(' ' + valor)])));

        $('repResumen').replaceChildren(...r.resumen.map(([etiqueta, valor]) =>
            el('div', { class: 'resumen-item' + (String(valor).length > 40 ? ' ancho' : '') }, [
                el('span', { text: etiqueta }),
                el('strong', { text: String(valor) }),
            ])));

        const centrada = (c) => c.tipo !== 'texto';
        $('repEncabezado').replaceChildren(el('tr', {}, r.columnas.map((c) =>
            el('th', { class: centrada(c) ? 'centro' : '', text: c.titulo }))));

        $('repCuerpo').replaceChildren(...r.filas.map((fila) =>
            el('tr', {}, r.columnas.map((c) => {
                const largo = c.clave === 'descripcion';
                return el('td', { class: (centrada(c) ? 'centro ' : '') + (largo ? 'largo' : ''), text: formatear(fila[c.clave], c.tipo) });
            }))));

        $('repVacio').hidden = r.filas.length > 0;
        filtrarTabla();
        $('repNotas').replaceChildren(...r.notas.map((n) => el('li', { text: n })));

        ui.panel.hidden = false;
        ui.inicial.hidden = true;
        estado.hayVistaPrevia = true;
    }

    const normalizar = (t) => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

    function filtrarTabla() {
        const palabras = normalizar(ui.buscar.value).trim().split(/\s+/).filter(Boolean);
        let visibles = 0;
        for (const fila of ui.cuerpoTabla.rows) {
            if (!fila.dataset.buscar) fila.dataset.buscar = normalizar(fila.textContent);
            const coincide = palabras.every((p) => fila.dataset.buscar.includes(p));
            fila.style.display = coincide ? '' : 'none';
            if (coincide) visibles++;
        }
        const total = ui.cuerpoTabla.rows.length;
        $('repTotal').textContent = visibles;
        $('repVacio').hidden = visibles > 0;
        $('repVacio').textContent = total === 0
            ? 'No hay registros para los filtros seleccionados.'
            : 'Ningún registro coincide con la búsqueda.';
    }

    function imprimir() {
        if (!estado.hayVistaPrevia) {
            alerta('info', 'Sin vista previa', 'Genere primero la vista previa del reporte para poder imprimirlo.');
            return;
        }
        window.print();
    }

    async function init() {
        ui.tipo.value = cuerpo.dataset.tipoInicial || ui.tipo.value;
        aplicarVisibilidad();

        await cargarOpciones(Number(cuerpo.dataset.seccionInicial || 0));
        actualizarEnlaceExcel();

        ui.tipo.addEventListener('change', () => { aplicarVisibilidad(); alCambiarFiltro(); });
        ui.periodo.addEventListener('change', async () => { await cargarOpciones(); alCambiarFiltro(); });
        [ui.seccion, ui.momento].forEach((c) => c.addEventListener('change', alCambiarFiltro));

        ui.btnGenerar.addEventListener('click', () => generar());
        ui.buscar.addEventListener('input', filtrarTabla);
        ui.btnImprimir.addEventListener('click', imprimir);

        if (ui.periodo.value) generar({ silencioso: true });
    }

    document.addEventListener('DOMContentLoaded', init);
})();
