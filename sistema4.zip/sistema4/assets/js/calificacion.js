(function () {
    'use strict';

    const { el, peticion, esExito, alerta, toast, abrirModal, cerrarModal } = window.Comun;

    const cuerpo       = document.body;
    const BASE_URL     = cuerpo.dataset.baseUrl || '/';
    const PUEDE_EDITAR = cuerpo.dataset.puedeEditar === '1';
    const URL_CTRL     = BASE_URL + 'index.php?controller=calificacion&action=';
    const MAX_DESCRIPCION = 500;
    const PUEDE_CREAR_MOMENTOS = cuerpo.dataset.puedeCrearMomentos === '1';

    const $ = (id) => document.getElementById(id);

    const ui = {
        selectSeccion: $('selectSeccion'),
        selectMomento: $('selectMomento'),
        btnCargar:     $('btnCargarPlanilla'),
        btnMomentos:   $('btnCrearMomentos'),
        aviso:         $('avisoFiltro'),
        panel:         $('panelResumen'),
        cuerpoResumen: $('cuerpoResumen'),
        resVacio:      $('resVacio'),
        form:          $('formPlanilla'),
        cuerpoPlanilla: $('cuerpoPlanilla'),
        planVacio:     $('planVacio'),
        btnGuardar:    $('btnGuardarPlanilla'),
        aplicarTodos:  $('aplicarTodos'),
        plantilla:     $('plantillaEstado'),
    };

    const estado = {
        datos: null,
        abortar: null,
    };

    const generoEdad = (e) => (e.genero || '—') + ' / ' + (e.edad !== null && e.edad !== undefined ? e.edad + ' años' : '—');

    function badgeEstado(valor) {
        if (valor === 'Aprobado') return el('span', { class: 'insignia-pildora insignia-aprobado', text: 'Aprobado' });
        if (valor === 'Reprobado') return el('span', { class: 'insignia-pildora insignia-reprobado', text: 'Reprobado' });
        return el('span', { class: 'insignia-pildora insignia-muted', text: 'Sin calificar' });
    }

    function textoDocente(seccion) {
        return seccion.sin_docente ? '⚠ Sin docente asignado' : seccion.docente_nombre;
    }

    function reiniciarFiltros(mensaje) {
        estado.datos = null;
        ui.panel.hidden = true;
        ui.selectMomento.replaceChildren(el('option', { value: '', text: 'Seleccione una sección primero' }));
        ui.selectMomento.disabled = true;
        ui.btnCargar.disabled = true;
        ui.btnMomentos.hidden = true;
        ui.aviso.textContent = mensaje;
        ui.aviso.hidden = false;
    }

    async function alCambiarSeccion() {
        const seccionId = ui.selectSeccion.value;
        if (!seccionId) {
            reiniciarFiltros('Seleccione una sección y un momento académico para ver las calificaciones.');
            return;
        }

        reiniciarFiltros('Cargando momentos académicos...');
        const data = await peticion(URL_CTRL + 'planilla&seccion=' + encodeURIComponent(seccionId));

        if (ui.selectSeccion.value !== seccionId) return;

        if (!esExito(data)) {
            ui.aviso.textContent = data.message || 'No se pudo cargar la sección.';
            alerta('error', data.title || 'Error', data.message || 'No se pudo cargar la sección.');
            return;
        }

        const momentos = data.momentos;
        if (!momentos.length) {
            ui.selectMomento.replaceChildren(el('option', { value: '', text: 'Sin momentos configurados' }));
            const periodo = data.seccion.periodo_nombre;
            if (data.seccion.periodo_estado !== 'activo') {
                ui.aviso.textContent = 'El período ' + periodo + ' está cerrado y no tiene momentos académicos.';
            } else if (PUEDE_CREAR_MOMENTOS) {
                ui.aviso.textContent = 'El período ' + periodo + ' todavía no tiene momentos académicos, por eso no se puede calificar. Puede crearlos ahora (1er, 2do y 3er Momento).';
                ui.btnMomentos.hidden = false;
            } else {
                ui.aviso.textContent = 'El período ' + periodo + ' todavía no tiene momentos académicos. Pida al administrador o al director que los cree.';
            }
            return;
        }

        ui.selectMomento.replaceChildren(...momentos.map((m) =>
            el('option', { value: m.id, text: m.nombre + (m.estado === 'activo' ? '' : ' (cerrado)') })));
        ui.selectMomento.disabled = false;

        const porDefecto = momentos.find((m) => m.estado === 'activo') || momentos[0];
        ui.selectMomento.value = porDefecto.id;

        await cargarResumen();
    }

    async function cargarResumen() {
        const seccionId = ui.selectSeccion.value;
        const momentoId = ui.selectMomento.value;
        if (!seccionId || !momentoId) return false;

        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        let data;
        try {
            data = await peticion(
                URL_CTRL + 'planilla&seccion=' + encodeURIComponent(seccionId) + '&momento=' + encodeURIComponent(momentoId),
                { signal: estado.abortar.signal }
            );
        } catch (_) {
            return false;
        }

        if (!esExito(data)) {
            ui.aviso.textContent = data.message || 'No se pudo cargar la planilla.';
            ui.aviso.hidden = false;
            ui.panel.hidden = true;
            alerta('error', data.title || 'Error', data.message || 'No se pudo cargar la planilla.');
            return false;
        }

        estado.datos = data;
        ui.btnCargar.disabled = false;
        ui.aviso.hidden = true;
        pintarResumen(data);
        return true;
    }

    function pintarResumen(d) {
        const { seccion, momento, estudiantes, resumen } = d;

        $('resTitulo').textContent  = seccion.etiqueta + ' · ' + momento.nombre;
        $('resGrado').textContent   = seccion.grado + '° Grado';
        $('resSeccion').textContent = seccion.seccion;
        $('resPeriodo').textContent = seccion.periodo_nombre + (seccion.periodo_estado === 'activo' ? '' : ' (cerrado)');
        $('resAula').textContent    = seccion.aula || '—';
        $('resMomento').textContent = momento.nombre + (momento.estado === 'activo' ? '' : ' (cerrado)');

        const docente = $('resDocente');
        docente.textContent = textoDocente(seccion);
        docente.classList.toggle('sin-docente-aviso', seccion.sin_docente);

        $('cntTotal').textContent      = resumen.total;
        $('cntAprobados').textContent  = resumen.aprobados;
        $('cntReprobados').textContent = resumen.reprobados;
        $('cntSin').textContent        = resumen.sin_calificar;

        const base = '&seccion=' + seccion.id;
        $('lnkReporte').href     = URL_CTRL + 'reporte' + base + '&momento=' + momento.id;
        $('lnkConsolidado').href = URL_CTRL + 'reporte' + base + '&momento=0';
        $('lnkCsv').href         = URL_CTRL + 'exportar' + base + '&momento=' + momento.id;

        ui.cuerpoResumen.replaceChildren(...estudiantes.map((e, i) => el('tr', {}, [
            el('td', { text: i + 1 }),
            el('td', {}, el('code', { text: e.cedula_escolar })),
            el('td', { class: 'nombre', text: (e.apellidos + ', ' + e.nombres).trim() }),
            el('td', { text: generoEdad(e) }),
            el('td', {}, badgeEstado(e.estado)),
            el('td', { class: 'descripcion', text: e.descripcion || '—' }),
        ])));
        ui.resVacio.hidden = estudiantes.length > 0;
        ui.panel.hidden = false;
    }

    function actualizarContador() {
        const selects = ui.cuerpoPlanilla.querySelectorAll('select');
        const calificados = [...selects].filter((s) => s.value !== '').length;
        $('planCalificados').textContent = calificados;
        $('planTotal').textContent = selects.length;
    }

    function limpiarErroresPlanilla() {
        ui.cuerpoPlanilla.querySelectorAll('.fila-invalida').forEach((tr) => tr.classList.remove('fila-invalida'));
        ui.cuerpoPlanilla.querySelectorAll('.msg-fila').forEach((s) => { s.textContent = ''; });
    }

    function marcarFila(estudianteId, mensaje) {
        const tr = ui.cuerpoPlanilla.querySelector('tr[data-id="' + estudianteId + '"]');
        if (!tr) return null;
        tr.classList.add('fila-invalida');
        tr.querySelector('.msg-fila').textContent = mensaje;
        return tr;
    }

    function crearFilaPlanilla(e, i) {
        const select = el('select', { class: 'campo', name: 'calificaciones[' + e.id + '][estado]', 'aria-label': 'Estado de ' + e.nombres + ' ' + e.apellidos });
        select.append(...[...ui.plantilla.options].map((o) => o.cloneNode(true)));
        select.value = e.estado || '';

        const descripcion = el('input', {
            type: 'text', class: 'campo', name: 'calificaciones[' + e.id + '][descripcion]',
            maxlength: MAX_DESCRIPCION, placeholder: 'Observaciones de progreso...',
            'aria-label': 'Descripción del desempeño de ' + e.nombres + ' ' + e.apellidos,
        });
        descripcion.value = e.descripcion || '';

        return el('tr', { dataset: { id: e.id } }, [
            el('td', { text: i + 1 }),
            el('td', {}, el('code', { text: e.cedula_escolar })),
            el('td', { class: 'nombre', text: (e.apellidos + ', ' + e.nombres).trim() }),
            el('td', { text: generoEdad(e) }),
            el('td', { class: 'celda-estado' }, select),
            el('td', {}, [descripcion, el('small', { class: 'msg-fila' })]),
        ]);
    }

    async function abrirPlanilla() {
        if (!(await cargarResumen())) return;
        const d = estado.datos;

        if (!d.editable) {
            alerta('info', 'Planilla de solo lectura', d.motivoBloqueo || 'No se puede modificar esta planilla.');
            return;
        }
        if (d.estudiantes.length === 0) {
            alerta('info', 'Sin estudiantes', 'Esta sección no tiene estudiantes inscritos. Agréguelos desde el módulo de Secciones.');
            return;
        }

        ui.form.elements.seccion_id.value = d.seccion.id;
        ui.form.elements.momento_id.value = d.momento.id;
        $('tituloPlanilla').textContent = 'Planilla — ' + d.momento.nombre;
        $('planSeccion').textContent    = d.seccion.etiqueta;
        $('planMomento').textContent    = d.momento.nombre;
        const docente = $('planDocente');
        docente.textContent = textoDocente(d.seccion);
        docente.classList.toggle('sin-docente-aviso', d.seccion.sin_docente);

        ui.cuerpoPlanilla.replaceChildren(...d.estudiantes.map(crearFilaPlanilla));
        ui.planVacio.hidden = true;
        ui.aplicarTodos.value = '';
        actualizarContador();

        abrirModal('modalPlanilla');
        const primero = ui.cuerpoPlanilla.querySelector('select');
        if (primero) primero.focus();
    }

    function validarPlanilla() {
        const errores = {};
        let conEstado = 0;

        ui.cuerpoPlanilla.querySelectorAll('tr').forEach((tr) => {
            const id = tr.dataset.id;
            const valorEstado = tr.querySelector('select').value;
            const descripcion = tr.querySelector('input').value.trim();

            if (valorEstado) conEstado++;
            if (!valorEstado && descripcion) errores[id] = 'Seleccione el estado para guardar la descripción.';
            else if (descripcion.length > MAX_DESCRIPCION) errores[id] = 'La descripción no puede superar ' + MAX_DESCRIPCION + ' caracteres.';
        });

        return { errores, conEstado };
    }

    async function enviarPlanilla(ev) {
        ev.preventDefault();
        limpiarErroresPlanilla();

        const { errores, conEstado } = validarPlanilla();
        const ids = Object.keys(errores);
        if (ids.length) {
            const filas = ids.map((id) => marcarFila(id, errores[id]));
            if (filas[0]) filas[0].scrollIntoView({ block: 'center', behavior: 'smooth' });
            return;
        }
        if (conEstado === 0) {
            alerta('warning', 'Sin calificaciones', 'Seleccione el estado de al menos un estudiante para guardar.');
            return;
        }

        const textoOriginal = ui.btnGuardar.textContent;
        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';
        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: new FormData(ui.form) });
        ui.btnGuardar.disabled = false;
        ui.btnGuardar.textContent = textoOriginal;

        if (esExito(data)) {
            cerrarModal($('modalPlanilla'));
            await cargarResumen();
            document.dispatchEvent(new CustomEvent('registros:actualizar'));
            toast(data.message);
            return;
        }

        if (data.errors) {
            const filas = Object.entries(data.errors).map(([clave, mensaje]) => marcarFila(clave.replace('est_', ''), mensaje));
            const primera = filas.find(Boolean);
            if (primera) primera.scrollIntoView({ block: 'center', behavior: 'smooth' });
        }
        alerta('error', data.title || 'Atención', data.message || 'No se pudieron guardar las calificaciones.');
    }

    async function crearMomentos() {
        const seccionId = ui.selectSeccion.value;
        if (!seccionId) return;

        const respuesta = await Swal.fire({
            title: '¿Crear los momentos académicos?',
            text: 'Se crearán el 1er, 2do y 3er Momento del período de esta sección, todos activos.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#2563eb',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, crear',
            cancelButtonText: 'Cancelar',
        });
        if (!respuesta.isConfirmed) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('seccion_id', seccionId);
        ui.btnMomentos.disabled = true;
        const data = await peticion(URL_CTRL + 'crearMomentos', { method: 'POST', body: cuerpoPost });
        ui.btnMomentos.disabled = false;

        if (esExito(data)) {
            toast(data.message);
            await alCambiarSeccion();
        } else {
            alerta('error', data.title || 'Error', data.message || 'No se pudieron crear los momentos.');
        }
    }

    function init() {
        ui.selectSeccion.addEventListener('change', alCambiarSeccion);
        ui.selectMomento.addEventListener('change', cargarResumen);
        ui.btnMomentos.addEventListener('click', crearMomentos);

        if (!PUEDE_EDITAR) {
            ui.btnCargar.hidden = true;
            return;
        }

        ui.btnCargar.addEventListener('click', abrirPlanilla);
        ui.form.addEventListener('submit', enviarPlanilla);

        ui.cuerpoPlanilla.addEventListener('change', (ev) => {
            if (ev.target.tagName === 'SELECT') actualizarContador();
        });
        ui.cuerpoPlanilla.addEventListener('input', (ev) => {
            const tr = ev.target.closest('tr');
            if (tr && tr.classList.contains('fila-invalida')) {
                tr.classList.remove('fila-invalida');
                tr.querySelector('.msg-fila').textContent = '';
            }
        });

        ui.aplicarTodos.addEventListener('change', () => {
            const valor = ui.aplicarTodos.value;
            if (!valor) return;
            ui.cuerpoPlanilla.querySelectorAll('select').forEach((s) => { s.value = valor; });
            ui.aplicarTodos.value = '';
            actualizarContador();
        });
    }

    document.addEventListener('DOMContentLoaded', init);
})();
