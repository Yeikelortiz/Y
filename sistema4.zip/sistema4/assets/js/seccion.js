(function () {
    'use strict';

    const {
        el, peticion, esExito, alerta, toast,
        abrirModal, cerrarModal,
        limpiarErrores, marcarError, autoLimpiarErrores,
    } = window.Comun;

    const cuerpo         = document.body;
    const BASE_URL       = cuerpo.dataset.baseUrl || '/';
    const PUEDE_GESTIONAR = cuerpo.dataset.puedeGestionar === '1';
    const URL_CTRL       = BASE_URL + 'index.php?controller=seccion&action=';

    const $ = (id) => document.getElementById(id);

    const ui = {
        filtroPeriodo: $('filtroPeriodo'),
        btnNueva:      $('btnNuevaSeccion'),
        tbody:         $('cuerpoTabla'),
        estado:        $('estadoTabla'),
        total:         $('contadorTotal'),
        form:          $('formSeccion'),
        titulo:        $('tituloModalSeccion'),
        btnGuardar:    $('btnGuardarSeccion'),
        formDocente:   $('formDocente'),
        btnDocente:    $('btnGuardarDocente'),
        bloqueAsignar: $('bloqueAsignar'),
        filtroDisp:    $('filtroDisponibles'),
        selectDisp:    $('selectDisponibles'),
        filaAsignar:   $('filaAsignar'),
        notaSinDisp:   $('notaSinDisponibles'),
        btnAsignar:    $('btnAsignarEstudiante'),
    };

    const estado = {
        secciones: new Map(),
        seccionActual: null,
        disponibles: [],
        abortar: null,
    };

    const plural = (n, s, p) => n + ' ' + (n === 1 ? s : p);

    async function cargarLista() {
        if (estado.abortar) estado.abortar.abort();
        estado.abortar = new AbortController();

        ui.tbody.classList.add('cargando');
        let data;
        try {
            data = await peticion(URL_CTRL + 'listar&periodo=' + encodeURIComponent(ui.filtroPeriodo.value), { signal: estado.abortar.signal });
        } catch (_) {
            return;
        }
        ui.tbody.classList.remove('cargando');

        if (!esExito(data)) {
            ui.tbody.replaceChildren();
            mostrarEstado(data.message || 'No se pudo cargar el listado.', true);
            return;
        }

        estado.secciones = new Map(data.secciones.map((s) => [Number(s.id), s]));
        ui.total.textContent = data.secciones.length;
        ui.tbody.replaceChildren(...data.secciones.map(crearFila));
        mostrarEstado(data.secciones.length ? '' : 'No hay secciones registradas para este período.');
    }

    function mostrarEstado(texto, esError = false) {
        ui.estado.textContent = texto;
        ui.estado.classList.toggle('error', esError);
    }

    function crearFila(s) {
        const activa = s.periodo_estado === 'activo';
        const puedeEditarFila = PUEDE_GESTIONAR && activa;

        let celdaDocente;
        if (s.sin_docente) {
            celdaDocente = el('div', { class: 'celda-docente' }, [
                el('span', { class: 'sin-docente', text: '⚠ Sin docente' }),
                puedeEditarFila ? el('button', {
                    type: 'button', class: 'boton boton-primario boton-sm',
                    dataset: { accion: 'docente', id: s.id }, text: '+ Asignar docente',
                }) : null,
            ]);
        } else {
            celdaDocente = el('div', { class: 'celda-docente' }, [
                el('span', { text: s.docente_nombre }),
                puedeEditarFila ? el('button', {
                    type: 'button', class: 'boton boton-contorno-secundario boton-sm',
                    title: 'Cambiar docente', 'aria-label': 'Cambiar docente de ' + s.etiqueta,
                    dataset: { accion: 'docente', id: s.id }, text: 'Cambiar',
                }) : null,
            ]);
        }

        const n = s.total_estudiantes;
        const celdaCantidad = el('button', {
            type: 'button', class: 'btn-cantidad' + (n === 0 ? ' vacia' : ''),
            title: 'Ver estudiantes', 'aria-label': 'Ver ' + plural(n, 'estudiante', 'estudiantes') + ' de ' + s.etiqueta,
            dataset: { accion: 'estudiantes', id: s.id }, text: '👥 ' + n,
        });

        const celdas = [
            el('td', { class: 'nombre', text: s.etiqueta }),
            el('td', {}, el('span', { class: 'insignia-pildora ' + (activa ? 'insignia-ok' : 'insignia-cerrado'), text: s.periodo_nombre + (activa ? '' : ' (cerrado)') })),
            el('td', {}, celdaDocente),
            el('td', { text: s.aula || '—' }),
            el('td', { text: s.horario || '—' }),
            el('td', {}, celdaCantidad),
        ];

        if (PUEDE_GESTIONAR) {
            celdas.push(el('td', { class: 'acciones' }, activa
                ? el('div', { class: 'grupo' }, [
                    el('button', { type: 'button', class: 'boton boton-contorno-secundario boton-sm', title: 'Editar', 'aria-label': 'Editar ' + s.etiqueta, dataset: { accion: 'editar', id: s.id }, text: '✏️' }),
                    el('button', { type: 'button', class: 'boton boton-peligro boton-sm', title: 'Eliminar', 'aria-label': 'Eliminar ' + s.etiqueta, dataset: { accion: 'eliminar', id: s.id }, text: '🗑' }),
                ])
                : el('span', { class: 'sin-hijos', text: 'Período cerrado' })
            ));
        }

        return el('tr', {}, celdas);
    }

    async function cargarEstudiantes(id) {
        const data = await peticion(URL_CTRL + 'estudiantes&id=' + encodeURIComponent(id));
        if (!esExito(data)) {
            alerta('error', data.title || 'Error', data.message || 'No se pudo cargar la lista de estudiantes.');
            return false;
        }
        pintarEstudiantes(data);
        return true;
    }

    async function abrirEstudiantes(id) {
        if (await cargarEstudiantes(id)) abrirModal('modalEstudiantes');
    }

    function pintarEstudiantes({ seccion, estudiantes, disponibles, puedeAsignar }) {
        estado.seccionActual = seccion.id;
        const activa = seccion.periodo_estado === 'activo';

        $('tituloEstudiantes').textContent = 'Estudiantes — ' + seccion.etiqueta;
        $('estSeccion').textContent = seccion.etiqueta;
        $('estPeriodo').textContent = seccion.periodo_nombre + (activa ? '' : ' (cerrado)');
        $('estDocente').textContent = seccion.sin_docente ? 'Sin docente asignado' : seccion.docente_nombre;
        $('estAulaHorario').textContent = [seccion.aula, seccion.horario].filter(Boolean).join(' / ') || '—';
        $('estTotal').textContent = estudiantes.length;

        const hay = estudiantes.length > 0;
        $('estTablaWrap').hidden = !hay;
        $('estVacio').hidden = hay;

        $('estLista').replaceChildren(...estudiantes.map((e) => {
            const nombre = (e.nombres + ' ' + e.apellidos).trim();
            const fila = [
                el('td', {}, el('code', { text: e.cedula_escolar })),
                el('td', { class: 'nombre', text: nombre }),
                el('td', { text: e.edad !== null && e.edad !== undefined ? e.edad + ' años' : '—' }),
                el('td', { text: e.representante_nombre ? e.representante_nombre + ' (C.I. ' + e.representante_cedula + ')' : (e.representante_cedula || '—') }),
            ];
            if (PUEDE_GESTIONAR) {
                fila.push(el('td', { class: 'acciones' }, puedeAsignar
                    ? el('button', {
                        type: 'button', class: 'boton boton-contorno-secundario boton-sm',
                        'aria-label': 'Quitar a ' + nombre + ' de la sección',
                        dataset: { accion: 'quitar-estudiante', id: e.id, nombre }, text: 'Quitar',
                    })
                    : null));
            }
            return el('tr', {}, fila);
        }));

        if (ui.bloqueAsignar) {
            ui.bloqueAsignar.hidden = !puedeAsignar;
            estado.disponibles = disponibles || [];
            ui.filtroDisp.value = '';
            llenarDisponibles();
        }
    }

    function llenarDisponibles() {
        const texto = ui.filtroDisp.value.trim().toLowerCase();
        const sinNadie = estado.disponibles.length === 0;
        ui.filaAsignar.hidden = sinNadie;
        ui.notaSinDisp.hidden = !sinNadie;
        if (sinNadie) return;

        const filtrados = estado.disponibles.filter((e) =>
            (e.nombres + ' ' + e.apellidos + ' ' + e.cedula_escolar).toLowerCase().includes(texto));

        const opciones = filtrados.length
            ? filtrados.map((e) => el('option', { value: e.id, text: e.apellidos + ' ' + e.nombres + ' — ' + e.cedula_escolar }))
            : [el('option', { value: '', text: 'Sin coincidencias', disabled: true })];

        ui.selectDisp.replaceChildren(...opciones);
        ui.btnAsignar.disabled = filtrados.length === 0;
    }

    async function asignarEstudiante() {
        const estudianteId = ui.selectDisp.value;
        if (!estudianteId || !estado.seccionActual) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('seccion_id', estado.seccionActual);
        cuerpoPost.append('estudiante_id', estudianteId);

        ui.btnAsignar.disabled = true;
        const data = await peticion(URL_CTRL + 'asignar', { method: 'POST', body: cuerpoPost });
        ui.btnAsignar.disabled = false;

        if (esExito(data)) {
            await Promise.all([cargarEstudiantes(estado.seccionActual), cargarLista()]);
            toast(data.message);
        } else {
            alerta('error', data.title || 'Error', data.message || 'No se pudo asignar al estudiante.');
        }
    }

    async function quitarEstudiante(estudianteId, nombre) {
        const respuesta = await Swal.fire({
            title: '¿Quitar de la sección?',
            text: nombre + ' quedará sin sección asignada.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, quitar',
            cancelButtonText: 'Cancelar',
        });
        if (!respuesta.isConfirmed) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('seccion_id', estado.seccionActual);
        cuerpoPost.append('estudiante_id', estudianteId);
        const data = await peticion(URL_CTRL + 'quitar', { method: 'POST', body: cuerpoPost });

        if (esExito(data)) {
            await Promise.all([cargarEstudiantes(estado.seccionActual), cargarLista()]);
            toast(data.message);
        } else {
            alerta('error', data.title || 'Error', data.message || 'No se pudo retirar al estudiante.');
        }
    }

    function abrirDocente(id) {
        const s = estado.secciones.get(Number(id));
        if (!s) return;

        limpiarErrores(ui.formDocente);
        ui.formDocente.reset();
        ui.formDocente.elements.seccion_id.value = s.id;
        ui.formDocente.elements.docente_id.value = s.docente_id || '';
        $('tituloDocente').textContent = s.sin_docente ? 'Asignar docente titular' : 'Cambiar docente titular';
        $('docenteContexto').textContent = s.etiqueta + ' — Período ' + s.periodo_nombre;
        ui.btnDocente.textContent = s.sin_docente ? 'Asignar' : 'Guardar cambio';

        abrirModal('modalDocente');
        ui.formDocente.elements.docente_id.focus();
    }

    async function enviarDocente(ev) {
        ev.preventDefault();
        limpiarErrores(ui.formDocente);

        if (!ui.formDocente.elements.docente_id.value) {
            marcarError(ui.formDocente, 'docente_id', 'Seleccione un docente.');
            ui.formDocente.elements.docente_id.focus();
            return;
        }

        ui.btnDocente.disabled = true;
        const data = await peticion(URL_CTRL + 'asignarDocente', { method: 'POST', body: new FormData(ui.formDocente) });
        ui.btnDocente.disabled = false;

        if (esExito(data)) {
            cerrarModal($('modalDocente'));
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'Atención', data.message || 'No se pudo asignar el docente.');
        }
    }

    function abrirNueva() {
        ui.form.reset();
        limpiarErrores(ui.form);
        const f = ui.form.elements;
        f.id.value = '0';
        f.periodo_id.disabled = false;

        const filtro = ui.filtroPeriodo.value;
        if (filtro !== '0' && [...f.periodo_id.options].some((o) => o.value === filtro)) f.periodo_id.value = filtro;

        ui.titulo.textContent = 'Nueva Sección';
        abrirModal('modalSeccion');
        f.grado.focus();
    }

    function abrirEdicion(id) {
        const s = estado.secciones.get(Number(id));
        if (!s) return;

        ui.form.reset();
        limpiarErrores(ui.form);
        const f = ui.form.elements;
        f.id.value         = s.id;
        f.periodo_id.value = s.periodo_id;
        f.periodo_id.disabled = true;
        f.grado.value      = s.grado;
        f.seccion.value    = s.seccion;
        f.docente_id.value = s.docente_id || '';
        f.aula.value       = s.aula || '';
        f.horario.value    = s.horario || '';

        ui.titulo.textContent = 'Editar Sección';
        abrirModal('modalSeccion');
        f.grado.focus();
    }

    function validarSeccion() {
        const f = ui.form.elements;
        const errores = {};
        if (f.id.value === '0' && !f.periodo_id.value) errores.periodo_id = 'Seleccione el período.';
        if (!f.grado.value) errores.grado = 'Seleccione el grado.';
        if (!f.seccion.value) errores.seccion = 'Seleccione la sección.';
        return errores;
    }

    async function enviarSeccion(ev) {
        ev.preventDefault();
        limpiarErrores(ui.form);

        const errores = validarSeccion();
        const campos = Object.keys(errores);
        if (campos.length) {
            campos.forEach((c) => marcarError(ui.form, c, errores[c]));
            ui.form.elements[campos[0]].focus();
            return;
        }

        ui.btnGuardar.disabled = true;
        ui.btnGuardar.textContent = 'Guardando...';
        const data = await peticion(URL_CTRL + 'guardar', { method: 'POST', body: new FormData(ui.form) });
        ui.btnGuardar.disabled = false;
        ui.btnGuardar.textContent = 'Guardar';

        if (esExito(data)) {
            cerrarModal($('modalSeccion'));
            await cargarLista();
            toast(data.message);
            return;
        }

        if (data.errors) Object.entries(data.errors).forEach(([c, m]) => marcarError(ui.form, c, m));
        alerta('error', data.title || 'Atención', data.message || 'No se pudo guardar la sección.');
    }

    async function confirmarEliminacion(id) {
        const s = estado.secciones.get(Number(id));
        if (!s) return;

        const respuesta = await Swal.fire({
            title: '¿Eliminar sección?',
            text: s.etiqueta + ' (' + s.periodo_nombre + '). Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
        });
        if (!respuesta.isConfirmed) return;

        const cuerpoPost = new FormData();
        cuerpoPost.append('id', s.id);
        const data = await peticion(URL_CTRL + 'eliminar', { method: 'POST', body: cuerpoPost });

        if (esExito(data)) {
            await cargarLista();
            toast(data.message);
        } else {
            alerta('error', data.title || 'No se puede eliminar', data.message || 'No se pudo eliminar la sección.');
        }
    }

    function init() {
        ui.filtroPeriodo.addEventListener('change', cargarLista);

        ui.tbody.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-accion]');
            if (!btn) return;
            const { accion, id } = btn.dataset;
            if (accion === 'estudiantes') abrirEstudiantes(id);
            else if (accion === 'docente') abrirDocente(id);
            else if (accion === 'editar') abrirEdicion(id);
            else if (accion === 'eliminar') confirmarEliminacion(id);
        });

        if (PUEDE_GESTIONAR) {
            ui.btnNueva.addEventListener('click', abrirNueva);
            ui.form.addEventListener('submit', enviarSeccion);
            autoLimpiarErrores(ui.form);

            ui.formDocente.addEventListener('submit', enviarDocente);
            autoLimpiarErrores(ui.formDocente);

            ui.filtroDisp.addEventListener('input', llenarDisponibles);
            ui.btnAsignar.addEventListener('click', asignarEstudiante);
            $('estLista').addEventListener('click', (ev) => {
                const btn = ev.target.closest('button[data-accion="quitar-estudiante"]');
                if (btn) quitarEstudiante(btn.dataset.id, btn.dataset.nombre);
            });
        }

        cargarLista();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
