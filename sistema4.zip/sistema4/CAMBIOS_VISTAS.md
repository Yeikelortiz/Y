# Cambios en las vistas: sin Bootstrap/Materialize

Solo HTML, CSS propio y JavaScript vanilla. La lógica (PHP de controladores/modelos, rutas, ids, `data-*`, nombres de campos y fetch) no se tocó.

## Qué se hizo
- Las vistas usaban nombres de clase de Bootstrap (`row`, `col-md-6`, `btn btn-primary`, `d-flex`, `bi bi-*`, `modal-*`…) sobre una capa de emulación (`sin-frameworks.css`), y el login usaba Materialize (CSS + JS + `M.AutoInit()`).
- Todas esas clases se renombraron a un vocabulario propio, en las vistas PHP, en el HTML que arma el JS y en los CSS del proyecto.
- Nueva hoja `assets/css/app.css` (reemplaza a `sin-frameworks.css`), ordenada por secciones: base, rejilla, componentes, iconos, utilidades y responsive.
- `auth/login.php` reescrito sin Materialize, con `assets/css/login.css` (antes vacío). El bloque PHP, el formulario, el token CSRF y el aviso de error que se oculta a los 4 s quedan igual.
- Estilos en línea (`style="..."`) movidos a clases.
- Variables `--bs-*` reemplazadas por variables propias (`--rej-x`, `--rej-y`).

## Equivalencias principales
| Antes | Ahora |
|---|---|
| `container`, `container-fluid`, `row` | `contenedor`, `contenedor-fluido`, `rejilla` |
| `col-md-6` | `rj-md-6` |
| `btn btn-primary btn-sm` | `boton boton-primario boton-sm` |
| `btn-outline-secondary` | `boton-contorno-secundario` |
| `card`, `card-body` | `tarjeta`, `tarjeta-cuerpo` |
| `badge`, `badge-pill` | `insignia`, `insignia-pildora` |
| `form-control`, `form-label`, `form-group` | `campo`, `campo-etiqueta`, `campo-grupo` |
| `table`, `table-responsive` | `tabla`, `tabla-responsive` |
| `alert alert-danger` | `mensaje mensaje-peligro` |
| `nav-link`, `navbar` | `menu-enlace`, `barra-nav` |
| `d-flex`, `mb-3`, `text-muted`, `fw-bold` | `u-flex`, `u-mb-3`, `u-t-suave`, `u-negrita` |
| `bi bi-eye` | `icono icono-eye` |

## Archivos eliminados (ya nadie los cargaba o eran del framework)
`materialize.min.css`, `materialize.min.js`, `sin-frameworks.css`, `theme.css`, `theme.js` (emulación de Bootstrap sin uso), `login.js` (dependía de Materialize y mezclaba PHP dentro del .js, así que no podía ejecutarse).

## Pendiente / a tener en cuenta
- `sweetalert2@11.js` se mantiene: es una librería JS (no Bootstrap) que usan los diálogos de confirmación de casi todos los módulos. Quitarla implica reescribir esa lógica.
- `style.css` y `material-icons.css` quedaron sin uso; se pueden borrar.
- Rutas: `registrar.php`, `editarUsuario.php` y `login.php` apuntaban a `/sistema/assets/...`; ahora apuntan a `/sistema4/assets/...` como el resto.
