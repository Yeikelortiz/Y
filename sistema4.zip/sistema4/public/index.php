<?php
// Enrutador (front controller) del sistema



ini_set('session.gc_maxlifetime', 3600);

session_set_cookie_params([
    'lifetime' => 3600,
    'path'     => '/',
    'domain'   => '',
    'secure'   => false, 
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Lista blanca: solo estas rutas se ejecutan
$rutasPermitidas = [
    'auth'          => ['login', 'authenticate', 'logout'],
    'admin'         => ['index', 'listaUsuarios', 'usuarios', 'guardarUsuario', 'eliminarUsuario', 'desbloquearUsuario', 'diagnostico', 'configuracion', 'respaldos'],
    'director'      => ['index', 'reportes'],
    'secretaria'    => ['index', 'consultas'],
    'estudiante'    => ['index', 'listar', 'guardar', 'eliminar', 'obtenerRepresentante'],
    'docente'       => ['index', 'listar', 'guardar', 'eliminar'],
    'representante' => ['index', 'listar', 'detalle', 'guardar', 'agregarEstudiante', 'eliminar'],
    'seccion'       => ['index', 'listar', 'guardar', 'asignarDocente', 'eliminar', 'estudiantes', 'asignar', 'quitar'],
    'asistencia'    => ['index', 'lista', 'registros', 'guardar', 'reporte'],
    'calificacion'  => ['index', 'planilla', 'registros', 'guardar', 'reporte', 'exportar', 'crearMomentos'],
    'boletin'       => ['index', 'generar', 'imprimir'],
    'reporte'       => ['index', 'opciones', 'datos', 'exportar'],
    'periodo'       => ['index', 'listar', 'guardar', 'cambiarEstado', 'cambiarEstadoMomento', 'momentos', 'crearMomentos', 'eliminar'],
    'bitacora'      => ['index', 'listar', 'exportar'],
    'perfil'        => ['index', 'actualizar']
];

// Acciones permitidas por rol (el administrador tiene acceso total)
$permisosPorRol = [
    'admin' => [
        '*' => ['*']
    ],

    'director' => [
        'auth'          => ['login', 'authenticate', 'logout'],
        'director'      => ['index', 'reportes'],
        'estudiante'    => ['index', 'listar', 'guardar', 'eliminar', 'obtenerRepresentante'],
        'docente'       => ['index', 'listar', 'guardar', 'eliminar'],
        'representante' => ['index', 'listar', 'detalle', 'guardar', 'agregarEstudiante', 'eliminar'],
        'seccion'       => ['index', 'listar', 'guardar', 'asignarDocente', 'eliminar', 'estudiantes', 'asignar', 'quitar'],
        'asistencia'    => ['index', 'lista', 'registros', 'guardar', 'reporte'],
        'calificacion'  => ['index', 'planilla', 'registros', 'guardar', 'reporte', 'exportar', 'crearMomentos'],
        'boletin'       => ['index', 'generar', 'imprimir'],
        'reporte'       => ['index', 'opciones', 'datos', 'exportar'],
        'periodo'       => ['index', 'listar', 'guardar', 'cambiarEstado', 'cambiarEstadoMomento', 'momentos', 'crearMomentos', 'eliminar'],
        'bitacora'      => ['index', 'listar', 'exportar'],
        'perfil'        => ['index', 'actualizar']
    ],

    'secretaria' => [
        'auth'          => ['login', 'authenticate', 'logout'],
        'secretaria'    => ['index', 'consultas'],
        'estudiante'    => ['index', 'listar', 'guardar', 'eliminar', 'obtenerRepresentante'],
        'docente'       => ['index', 'listar', 'guardar'],
        'representante' => ['index', 'listar', 'detalle', 'guardar', 'agregarEstudiante'],
        'seccion'       => ['index', 'listar', 'estudiantes'],
        'asistencia'    => ['index', 'lista', 'registros', 'guardar', 'reporte'],
        'calificacion'  => ['index', 'planilla', 'registros', 'guardar', 'reporte', 'exportar'],
        'boletin'       => ['index', 'generar', 'imprimir'],
        'reporte'       => ['index', 'opciones', 'datos', 'exportar'],
        'periodo'       => ['index', 'listar', 'momentos'],
        'perfil'        => ['index', 'actualizar']
    ]
];

$controllerR = $_GET['controller'] ?? 'auth';
$actionR     = $_GET['action'] ?? 'login';

$controller = ctype_alnum($controllerR) ? $controllerR : null;
$action     = ctype_alnum($actionR) ? $actionR : null;

// Validar sintaxis y existencia de la ruta en la lista blanca
if ($controller === null || $action === null || !isset($rutasPermitidas[$controller]) ||
    !in_array($action, $rutasPermitidas[$controller], true)
) {
    http_response_code(404);

    $pideJson = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
                (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);
    if ($pideJson) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status'  => 'error',
            'success' => false,
            'title'   => 'Ruta no encontrada',
            'message' => 'La acción "' . htmlspecialchars((string)$controllerR, ENT_QUOTES, 'UTF-8') . '/' .
                         htmlspecialchars((string)$actionR, ENT_QUOTES, 'UTF-8') . '" no está registrada en public/index.php.',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo "<h1>404 - Ruta no encontrada</h1><p>El recurso solicitado no está disponible.</p>";
    exit;
}

$rutasPublicas = [
    'auth' => ['login', 'authenticate']
];

$esRutaPublica = isset($rutasPublicas[$controller]) && in_array($action, $rutasPublicas[$controller], true);

$esJsonRequest = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
                 (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);

if (!$esRutaPublica && empty($_SESSION['usuario_id']) && empty($_SESSION['id'])) {
    if ($esJsonRequest) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode([
            'status'  => 'error',
            'success' => false,
            'message' => 'Sesión expirada o no iniciada.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    header('Location: index.php?controller=auth&action=login');
    exit;
}

if (!$esRutaPublica) {
    $rolRaw     = strtolower($_SESSION['usuario_rol'] ?? $_SESSION['rol'] ?? '');
    $rolUsuario = ($rolRaw === 'administrador') ? 'admin' : $rolRaw;

    $tienePermiso = false;

    if (isset($permisosPorRol[$rolUsuario])) {
        $permisosDelRol = $permisosPorRol[$rolUsuario];

        if (isset($permisosDelRol['*']) && in_array('*', $permisosDelRol['*'], true)) {
            $tienePermiso = true;
        }
        elseif (isset($permisosDelRol[$controller])) {
            $accionesPermitidas = $permisosDelRol[$controller];
            if (in_array('*', $accionesPermitidas, true) || in_array($action, $accionesPermitidas, true)) {
                $tienePermiso = true;
            }
        }
    }

    if (!$tienePermiso) {
        http_response_code(403);

        if ($esJsonRequest) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'status'  => 'error',
                'success' => false,
                'title'   => 'Acceso denegado',
                'message' => 'No tiene permisos suficientes para realizar esta acción.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo "<h1>403 - Acceso Denegado</h1><p>No tienes permisos suficientes para acceder a este recurso.</p>";
        exit;
    }
}

$controllerName = ucfirst($controller) . 'Controller';
$controllerFile = __DIR__ . "/../app/Controllers/{$controllerName}.php";

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    $controllerInstance = new $controllerName();

    if (method_exists($controllerInstance, $action)) {
        $controllerInstance->$action();
    } else {
        http_response_code(500);
        echo "<h1>500 - Error interno (Método no encontrado)</h1>";
        echo "<p>El controlador <strong>" . htmlspecialchars($controllerName, ENT_QUOTES, 'UTF-8') .
             "</strong> no tiene el método <strong>" . htmlspecialchars($action, ENT_QUOTES, 'UTF-8') .
             "</strong>. Probablemente falta copiar la versión nueva de ese archivo.</p>";
        exit;
    }
} else {
    http_response_code(404);
    echo "<h1>404 - Controlador no encontrado</h1>";
    echo "<p>No existe <strong>" . htmlspecialchars($controllerName, ENT_QUOTES, 'UTF-8') . ".php</strong> en app/Controllers.</p>";
    exit;
}
