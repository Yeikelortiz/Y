<?php
// Centro de documentos (Constancias y Boletines)

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Documento.php';
require_once __DIR__ . '/../Models/Seccion.php';
require_once __DIR__ . '/../Models/Calificacion.php';

class BoletinController extends BaseController
{
    private const ROLES = ['admin', 'director', 'secretaria'];

    // Tipos de documento por estudiante (lista blanca)
    private const TIPOS = ['estudio', 'inscripcion', 'boletin'];

    private const AUDITORIA = [
        'estudio'     => 'constancia de estudio',
        'inscripcion' => 'constancia de inscripción',
        'boletin'     => 'boletín de calificaciones',
    ];

    private Documento $docs;
    private Seccion $secciones;
    private Calificacion $calificaciones;

    public function __construct()
    {
        parent::__construct();
        if (!in_array($this->rolActual(), self::ROLES, true)) {
            $this->paginaError('Su rol no tiene permiso para emitir documentos.', 403);
        }

        $this->docs           = new Documento($this->pdo);
        $this->secciones      = new Seccion($this->pdo);
        $this->calificaciones = new Calificacion($this->pdo);
    }

    public function index(): void
    {
        $periodos  = $this->secciones->obtenerPeriodos();
        $periodoId = (int)($_GET['periodo'] ?? 0);

        if (!in_array($periodoId, array_map('intval', array_column($periodos, 'id')), true)) {
            $periodoId = 0;
            foreach ($periodos as $p) {
                if ($p['estado'] === 'activo') {
                    $periodoId = (int)$p['id'];
                    break;
                }
            }
            if ($periodoId === 0 && $periodos) {
                $periodoId = (int)$periodos[0]['id'];
            }
        }

        $secciones = $periodoId > 0 ? $this->secciones->obtenerTodos($periodoId) : [];
        $seccionId = (int)($_GET['seccion'] ?? 0);

        $seccion = null;
        foreach ($secciones as $s) {
            if ((int)$s['id'] === $seccionId) {
                $seccion = $s;
                break;
            }
        }

        $error = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_error']);

        $this->vista('boletin/index', [
            'periodos'      => $periodos,
            'periodoId'     => $periodoId,
            'secciones'     => $secciones,
            'seccion'       => $seccion,
            'estudiantes'   => $seccion ? $this->docs->estudiantesDeSeccion((int)$seccion['id']) : [],
            'momentos'      => $periodoId > 0 ? $this->calificaciones->momentosPorPeriodo($periodoId) : [],
            'tipos'         => self::TIPOS,
            'error'         => $error,
            'panel'         => $this->rolActual(),
            'nombreUsuario' => html_entity_decode($this->nombreUsuario(), ENT_QUOTES, 'UTF-8'),
        ]);
    }

    public function generar(): void
    {
        $this->emitir(false);
    }

    public function imprimir(): void
    {
        $this->emitir(true);
    }

    private function emitir(bool $autoImprimir): void
    {
        $tipo = (string)($_GET['tipo'] ?? '');
        $tipo = in_array($tipo, self::TIPOS, true) ? $tipo : '';
        $id   = (int)($_GET['estudiante'] ?? 0);
        $est  = ($tipo !== '' && $id > 0) ? $this->docs->estudiante($id) : null;

        if (!$est) {
            $this->volverConError('No se encontró el estudiante o el tipo de documento solicitado.');
        }
        if (empty($est['seccion_id']) || empty($est['periodo_id'])) {
            $this->volverConError('El estudiante no está inscrito en ninguna sección. Asígnelo a una sección para emitir este documento.');
        }

        $this->auditar('GENERAR', 'Documentos', 'Emitió ' . self::AUDITORIA[$tipo] . " de {$est['nombres']} {$est['apellidos']} (cédula escolar {$est['cedula_escolar']}).");

        $filas      = [];
        $asistencia = null;
        if ($tipo === 'boletin') {
            $filas      = $this->calificaciones->boletin($est['id'], (int)$est['periodo_id']);
            $asistencia = $this->docs->asistenciaResumen($est['id'], (int)$est['periodo_id']);
            $asistencia['porcentaje'] = $asistencia['total'] > 0 ? round($asistencia['asistencias'] * 100 / $asistencia['total'], 1) : null;
        }

        $this->vista('boletin/documento', [
            'tipo'         => $tipo,
            'est'          => $est,
            'filas'        => $filas,
            'asistencia'   => $asistencia,
            'emitidoPor'   => html_entity_decode($this->nombreUsuario(), ENT_QUOTES, 'UTF-8'),
            'autoImprimir' => $autoImprimir,
        ]);
    }

    private function volverConError(string $mensaje): void
    {
        $_SESSION['flash_error'] = $mensaje;
        header('Location: ' . $this->baseUrl() . 'index.php?controller=boletin&action=index');
        exit;
    }
}
