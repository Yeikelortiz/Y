<?php
// Registro de asistencia por momento académico y sección (totales de asistencias e inasistencias por estudiante)

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Asistencia.php';
require_once __DIR__ . '/../Models/Seccion.php';

class AsistenciaController extends BaseController
{
    private const ROLES_ESCRITURA = ['admin', 'director', 'secretaria'];

    private Asistencia $model;
    private Seccion $modelSeccion;

    public function __construct()
    {
        parent::__construct();
        $this->model        = new Asistencia($this->pdo);
        $this->modelSeccion = new Seccion($this->pdo);
    }

    public function index(): void
    {
        $rol = $this->rolActual();

        $todas     = $this->modelSeccion->obtenerTodos();
        $secciones = array_values(array_filter($todas, static fn(array $s): bool => $s['periodo_estado'] === 'activo'));

        $this->vista('asistencia/index', [
            'secciones'      => $secciones,
            'totalSecciones' => count($todas),
            'momentos'       => $this->model->momentosActivos(),
            'maxDias'        => Asistencia::MAX_DIAS,
            'puedeEditar'    => $this->puedeEscribir(),
            'panel'          => in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : 'admin',
            'rolVisual'      => ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaría'][$rol] ?? ucfirst($rol),
            'nombreUsuario'  => $this->nombreUsuario(),
            'csrfToken'      => $this->tokenCsrf(),
        ]);
    }

    public function reporte(): void
    {
        $seccionId = (int)($_GET['seccion'] ?? 0);
        $url = $this->baseUrl() . 'index.php?controller=reporte&action=index&tipo=asistencias'
             . ($seccionId > 0 ? '&seccion=' . $seccionId : '');

        header('Location: ' . $url);
        exit;
    }

    public function registros(): void
    {
        try {
            $seccionId = (int)($_GET['seccion'] ?? 0);
            if ($seccionId <= 0 || !$this->modelSeccion->obtenerPorId($seccionId)) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }
            $filas = array_map(static fn(array $r): array => [
                'momento'        => $r['momento'],
                'cedula_escolar' => $r['cedula_escolar'],
                'estudiante'     => $r['apellidos'] . ', ' . $r['nombres'],
                'asistencias'    => (int)$r['asistencias'],
                'inasistencias'  => (int)$r['inasistencias'],
            ], $this->model->registrosGuardados($seccionId));
            $this->ok('OK', ['filas' => $filas]);
        } catch (Throwable $e) {
            error_log('[asistencia.registros] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron cargar las asistencias guardadas.', 500);
        }
    }

    public function lista(): void
    {
        try {
            $seccionId = (int)($_GET['seccion'] ?? 0);
            $momentoId = (int)($_GET['momento'] ?? 0);

            $seccion = $seccionId > 0 ? $this->modelSeccion->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }

            $momento = $this->momentoDeSeccion($seccion, $momentoId);
            if (!$momento) {
                $msg = 'El momento académico no corresponde al período de la sección seleccionada.';
                $this->error('Momento inválido', $msg, 422, ['errors' => ['momento' => $msg]]);
            }

            [$editable, $motivo] = $this->evaluarEdicion($seccion, $momento);

            $this->ok('OK', [
                'seccion'       => $seccion,
                'momento'       => $momento,
                'estudiantes'   => $this->model->lista($seccionId, $momentoId),
                'registrados'   => $this->model->contarRegistrados($seccionId, $momentoId),
                'maxDias'       => Asistencia::MAX_DIAS,
                'editable'      => $editable,
                'motivoBloqueo' => $motivo,
            ]);
        } catch (Throwable $e) {
            error_log('[asistencia.lista] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar la lista de asistencia.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $seccionId = (int)($_POST['seccion_id'] ?? 0);
        $momentoId = (int)($_POST['momento_id'] ?? 0);
        $enviados  = $_POST['datos'] ?? [];

        try {
            $seccion = $seccionId > 0 ? $this->modelSeccion->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }

            $momento = $this->momentoDeSeccion($seccion, $momentoId);
            if (!$momento) {
                $msg = 'El momento académico no corresponde al período de la sección seleccionada.';
                $this->error('Momento inválido', $msg, 422, ['errors' => ['momento' => $msg]]);
            }

            [$editable, $motivo] = $this->evaluarEdicion($seccion, $momento);
            if (!$editable) {
                $this->error('Registro bloqueado', $motivo, 409);
            }

            if (!is_array($enviados) || !$enviados) {
                $this->error('Sin datos', 'No se enviaron asistencias para guardar.', 422);
            }

            $idsValidos = array_flip($this->model->idsEstudiantesDeSeccion($seccionId));
            $lote       = [];
            $errores    = [];

            foreach ($enviados as $estudianteId => $d) {
                $estudianteId = (int)$estudianteId;
                $clave        = 'est_' . $estudianteId;

                if (!isset($idsValidos[$estudianteId])) {
                    $errores[$clave] = 'El estudiante no pertenece a esta sección.';
                    continue;
                }

                $asistencias   = $this->entero($d['asistencias'] ?? null);
                $inasistencias = $this->entero($d['inasistencias'] ?? null);

                if ($asistencias === null || $inasistencias === null) {
                    $errores[$clave] = 'Indique las asistencias e inasistencias (número entero, 0 o más).';
                } elseif ($asistencias > Asistencia::MAX_DIAS || $inasistencias > Asistencia::MAX_DIAS) {
                    $errores[$clave] = 'Los valores no pueden superar ' . Asistencia::MAX_DIAS . ' días.';
                } else {
                    $lote[$estudianteId] = ['asistencias' => $asistencias, 'inasistencias' => $inasistencias];
                }
            }

            if ($errores) {
                $this->error('Revise los datos', reset($errores), 422, ['errors' => $errores]);
            }
            if (!$lote) {
                $this->error('Sin datos', 'No hay estudiantes válidos para registrar.', 422);
            }

            $n = $this->model->guardarLote($seccionId, $momentoId, $lote);

            $this->auditar('GUARDAR', 'Asistencia', "Registró asistencia de {$n} estudiante(s) en {$seccion['etiqueta']} (#{$seccionId}) para el {$momento['nombre']}.");
            $this->ok("Asistencia guardada ({$n} " . ($n === 1 ? 'estudiante' : 'estudiantes') . ').', ['guardados' => $n]);
        } catch (Throwable $e) {
            error_log('[asistencia.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar la asistencia.', 500);
        }
    }

    private function puedeEscribir(): bool
    {
        return in_array($this->rolActual(), self::ROLES_ESCRITURA, true);
    }

    // Solo enteros no negativos; vacío o con texto → null
    private function entero($valor): ?int
    {
        $valor = is_string($valor) ? trim($valor) : $valor;
        if (is_int($valor)) {
            return $valor >= 0 ? $valor : null;
        }
        if (!is_string($valor) || !preg_match('/^\d{1,5}$/', $valor)) {
            return null;
        }

        return (int)$valor;
    }

    // El momento debe existir y pertenecer al mismo período de la sección
    private function momentoDeSeccion(array $seccion, int $momentoId): ?array
    {
        if ($momentoId <= 0) {
            return null;
        }
        $momento = $this->model->momento($momentoId);

        return ($momento && $momento['periodo_id'] === (int)$seccion['periodo_id']) ? $momento : null;
    }

    private function evaluarEdicion(array $seccion, array $momento): array
    {
        if (!$this->puedeEscribir()) {
            return [false, 'Tu rol tiene acceso de solo lectura.'];
        }
        if ($seccion['periodo_estado'] !== 'activo') {
            return [false, 'El período académico de esta sección está cerrado: la asistencia es de solo lectura.'];
        }
        if ($momento['estado'] === 'cerrado') {
            return [false, 'El ' . $momento['nombre'] . ' está cerrado: su asistencia ya no se puede modificar.'];
        }

        return [true, null];
    }
}
