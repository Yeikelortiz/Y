<?php
// Panel del administrador

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/SecurityTrait.php';
require_once __DIR__ . '/../Models/UserModel.php';

class AdminController extends BaseController
{
    use SecurityTrait;

    private UserModel $model;

    public function __construct()
    {
        parent::__construct();

        $this->verificarSesion();
        $this->verificarRol(['admin']);

        $this->model = new UserModel($this->pdo);

        // Cuenta bloqueada mientras tenía la sesión abierta: se cierra la sesión
        $bloqueo = $this->model->verificarBloqueoUsuario((int)$_SESSION['usuario_id']);
        if ($bloqueo['bloqueado']) {
            $this->destruirSesionPorBloqueo($bloqueo['minutos_restantes']);
        }
    }

    public function index(): void
    {
        $ultimaSesion = $this->model->obtenerUltimaSesion((int)$_SESSION['usuario_id']);
        if ($ultimaSesion) {
            $ultimaSesion = (new DateTime($ultimaSesion))->format('d/m/Y H:i');
        }

        [$mensajeError, $mensajeExito] = $this->tomarMensajesFlash();

        $this->vista('admin/index', [
            'nombreMostrar' => $this->nombreParaMostrar(),
            'totalUsers'    => $this->model->contarTotal(),
            'ultimaSesion'  => $ultimaSesion ?: 'No disponible',
            'mensajeError'  => $mensajeError,
            'mensajeExito'  => $mensajeExito,
        ]);
    }

    public function listaUsuarios(): void
    {
        [$mensajeError, $mensajeExito] = $this->tomarMensajesFlash();

        $this->vista('admin/listaUsuarios', [
            'nombreMostrar' => $this->nombreParaMostrar(),
            'usuarioActual' => (int)$_SESSION['usuario_id'],
            'roles'         => UserModel::ROLES,
            'mensajeError'  => $mensajeError,
            'mensajeExito'  => $mensajeExito,
            'csrfToken'     => $this->tokenCsrf(),
        ]);
    }

    public function registrar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre   = trim($_POST['nombre'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $rol      = $_POST['rol'] ?? '';

            if (empty($nombre) || empty($email) || empty($password) || empty($rol)) {
                $_SESSION['flash_error'] = "Todos los campos obligatorios deben ser completados.";
            } else {
                if ($this->model->emailExiste($email)) {
                    $_SESSION['flash_error'] = "El correo electrónico ya está registrado.";
                } else {
                    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
                    if ($this->model->crearUsuario($nombre, $email, $passwordHash, $rol)) {
                        $_SESSION['flash_success'] = "Usuario registrado correctamente.";
                        header('Location: index.php?controller=admin&action=listaUsuarios');
                        exit;
                    } else {
                        $_SESSION['flash_error'] = "Error al intentar crear el usuario.";
                    }
                }
            }
        }

        $this->vista('admin/registrar', [
            'nombreMostrar' => $this->nombreParaMostrar(),
        ]);
    }

    public function usuarios(): void
    {
        try {
            $busqueda = mb_substr(trim((string)($_GET['busqueda'] ?? '')), 0, 100);
            $rol      = trim((string)($_GET['rol'] ?? ''));
            if ($rol !== '' && !in_array($rol, UserModel::ROLES, true)) {
                $rol = '';
            }

            $usuarios = $this->model->listar($busqueda, $rol);

            $this->ok('OK', [
                'usuarios' => $usuarios,
                'total'    => count($usuarios),
            ]);
        } catch (Throwable $e) {
            error_log('[admin.usuarios] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar la lista de usuarios.', 500);
        }
    }

    public function guardarUsuario(): void
    {
        $this->exigirPost();

        $id = (int)($_POST['id'] ?? 0);
        [$d, $errores] = $this->validarUsuario($_POST, $id === 0);

        try {
            $actual = null;
            if ($id > 0) {
                $actual = $this->model->obtenerPorId($id);
                if (!$actual) {
                    $this->error('No encontrado', 'El usuario que intenta editar no existe.', 404);
                }
            }

            if (!isset($errores['email']) && $this->model->emailExiste($d['email'], $id)) {
                $errores['email'] = 'El correo electrónico ya está registrado.';
            }

            if ($actual && !isset($errores['rol']) && $actual['rol'] === 'admin' && $d['rol'] !== 'admin') {
                if ($id === $this->usuarioActualId()) {
                    $errores['rol'] = 'No puedes quitarte a ti mismo el rol de administrador.';
                } elseif ($this->model->contarPorRol('admin') <= 1) {
                    $errores['rol'] = 'Debe existir al menos un administrador en el sistema.';
                }
            }

            if ($errores) {
                $this->error('Revise el formulario', reset($errores), 422, ['errors' => $errores]);
            }

            $hash = $d['password'] !== '' ? password_hash($d['password'], PASSWORD_BCRYPT) : null;

            if ($id === 0) {
                $nuevoId = $this->model->crearUsuario($d['nombre'], $d['email'], $hash, $d['rol']);
                $this->auditar('CREAR', 'Usuarios', "Creó la cuenta #{$nuevoId} de {$d['nombre']} ({$d['email']}) con rol {$d['rol']}.");
                $this->ok('Usuario registrado correctamente.', ['id' => $nuevoId], 201);
            }

            $this->model->actualizarUsuario($id, $d['nombre'], $d['email'], $d['rol'], $hash);

            if ($id === $this->usuarioActualId()) {
                $_SESSION['nombre'] = $this->sanitizarTexto($d['nombre']);
            }

            $this->auditar(
                'EDITAR',
                'Usuarios',
                "Editó la cuenta #{$id} de {$d['nombre']} ({$d['email']}), rol {$d['rol']}" . ($hash ? ' y cambió su contraseña.' : '.')
            );
            $this->ok('Usuario actualizado correctamente.', ['id' => $id]);
        } catch (PDOException $e) {
            if ((int)($e->errorInfo[1] ?? 0) === 1062) {
                $this->error('Correo duplicado', 'El correo electrónico ya está registrado.', 422,
                    ['errors' => ['email' => 'El correo electrónico ya está registrado.']]);
            }
            error_log('[admin.guardarUsuario] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el usuario.', 500);
        } catch (Throwable $e) {
            error_log('[admin.guardarUsuario] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el usuario.', 500);
        }
    }

    public function eliminarUsuario(): void
    {
        $this->exigirPost();

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->error('ID inválido', 'El identificador del usuario no es válido.', 422);
        }

        try {
            $usuario = $this->model->obtenerPorId($id);
            if (!$usuario) {
                $this->error('No encontrado', 'El usuario ya no existe.', 404);
            }
            if ($id === $this->usuarioActualId()) {
                $this->error('Acción no permitida', 'No puedes eliminar tu propia cuenta activa.', 409);
            }
            if ($usuario['rol'] === 'admin' && $this->model->contarPorRol('admin') <= 1) {
                $this->error('Acción no permitida', 'No se puede eliminar al único administrador del sistema.', 409);
            }

            if (!$this->model->eliminarUsuario($id)) {
                $this->error('Error', 'No se pudo eliminar el usuario.', 500);
            }

            $this->auditar('ELIMINAR', 'Usuarios', "Eliminó la cuenta #{$id} de {$usuario['nombre']} ({$usuario['email']}).");
            $this->ok('Usuario eliminado correctamente.');
        } catch (Throwable $e) {
            error_log('[admin.eliminarUsuario] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo eliminar el usuario.', 500);
        }
    }

    public function desbloquearUsuario(): void
    {
        $this->exigirPost();

        $id = (int)($_POST['id'] ?? 0);

        try {
            $usuario = $id > 0 ? $this->model->obtenerPorId($id) : null;
            if (!$usuario) {
                $this->error('No encontrado', 'El usuario no existe.', 404);
            }

            $this->model->reiniciarIntentos($id);
            $this->auditar('EDITAR', 'Usuarios', "Desbloqueó la cuenta #{$id} de {$usuario['nombre']} ({$usuario['email']}).");
            $this->ok('Cuenta desbloqueada correctamente.');
        } catch (Throwable $e) {
            error_log('[admin.desbloquearUsuario] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo desbloquear la cuenta.', 500);
        }
    }

    private function validarUsuario(array $in, bool $esNuevo): array
    {
        $d = [
            'nombre'   => preg_replace('/\s+/u', ' ', trim((string)($in['nombre'] ?? ''))),
            'email'    => strtolower(trim((string)($in['email'] ?? ''))),
            'rol'      => trim((string)($in['rol'] ?? '')),
            'password' => (string)($in['password'] ?? ''),
        ];
        $e = [];

        if ($d['nombre'] === '') {
            $e['nombre'] = 'El nombre completo es obligatorio.';
        } elseif (mb_strlen($d['nombre']) < 3 || mb_strlen($d['nombre']) > 100) {
            $e['nombre'] = 'El nombre debe tener entre 3 y 100 caracteres.';
        } elseif (!preg_match("/^\p{L}[\p{L}\s'.\-]*$/u", $d['nombre'])) {
            $e['nombre'] = 'El nombre solo puede contener letras y espacios.';
        }

        if ($d['email'] === '') {
            $e['email'] = 'El correo electrónico es obligatorio.';
        } elseif (mb_strlen($d['email']) > 100 || !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) {
            $e['email'] = 'Ingrese un correo electrónico válido (máximo 100 caracteres).';
        }

        if (!in_array($d['rol'], UserModel::ROLES, true)) {
            $e['rol'] = 'Seleccione un rol válido.';
        }

        if ($d['password'] === '') {
            if ($esNuevo) {
                $e['password'] = 'La contraseña es obligatoria.';
            }
        } elseif (strlen($d['password']) > 72) {
            $e['password'] = 'La contraseña no puede superar 72 caracteres.';
        } elseif (!$this->contrasenaSegura($d['password'])) {
            $e['password'] = 'Mínimo 7 caracteres, con mayúscula, minúscula, número y símbolo.';
        }

        return [$d, $e];
    }

    private function contrasenaSegura(string $clave): bool
    {
        return strlen($clave) >= 7
            && preg_match('/[A-Z]/', $clave)
            && preg_match('/[a-z]/', $clave)
            && preg_match('/[0-9]/', $clave)
            && preg_match('/[\W_]/', $clave);
    }

    private function usuarioActualId(): int
    {
        return (int)($_SESSION['usuario_id'] ?? 0);
    }

    private function nombreParaMostrar(): string
    {
        return html_entity_decode((string)($_SESSION['nombre'] ?? 'Administrador'), ENT_QUOTES, 'UTF-8');
    }

    private function tomarMensajesFlash(): array
    {
        $error = $_SESSION['flash_error'] ?? null;
        $exito = $_SESSION['flash_success'] ?? null;
        unset($_SESSION['flash_error'], $_SESSION['flash_success']);

        return [$error, $exito];
    }
}