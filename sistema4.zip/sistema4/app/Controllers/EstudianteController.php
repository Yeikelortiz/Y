<?php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Estudiante.php';

class EstudianteController extends BaseController
{
    private const POR_PAGINA      = 10;
    private const ROLES_ESCRITURA = ['admin', 'director','secretaria',];

    private Estudiante $model;

    public function __construct()
    {
        parent::__construct();
        $this->model = new Estudiante($this->pdo);
    }

   public function index(): void
    {
        $rol = $this->rolActual();

        // Determinamos el panel y el nombre visual de forma limpia y estricta en el Controlador
        if ($rol === 'admin') {
            $rolVisual = 'Administrador';
            $panel     = 'admin';
        } elseif ($rol === 'director') {
            $rolVisual = 'Director';
            $panel     = 'director';
        } else {
            $rolVisual = 'Secretaria';
            $panel     = 'secretaria';
        }

        $this->vista('ListaEstudiantes/index', [
            'secciones'     => $this->model->obtenerSecciones(),
            'puedeEditar'   => in_array($rol, self::ROLES_ESCRITURA, true),
            'esAdmin'       => $rol === 'admin',
            'rolVisual'     => $rolVisual,
            'panel'         => $panel,
            'nombreUsuario' => $this->nombreUsuario(),
            'csrfToken'     => $this->tokenCsrf(),
        ]);
    }

    public function listar(): void
    {
        try {
            $busqueda = mb_substr(trim((string)($_GET['busqueda'] ?? '')), 0, 100);
            $total    = $this->model->contar($busqueda);

            $totalPaginas = max(1, (int)ceil($total / self::POR_PAGINA));
            $pagina       = min(max(1, (int)($_GET['pagina'] ?? 1)), $totalPaginas);
            $offset       = ($pagina - 1) * self::POR_PAGINA;

            $this->ok('OK', [
                'estudiantes' => $this->model->listar(self::POR_PAGINA, $offset, $busqueda),
                'paginacion'  => [
                    'pagina'       => $pagina,
                    'totalPaginas' => $totalPaginas,
                    'total'        => $total,
                    'porPagina'    => self::POR_PAGINA,
                ],
            ]);
        } catch (Throwable $e) {
            error_log('[estudiante.listar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar el listado de estudiantes.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $id = (int)($_POST['id'] ?? 0);
        [$datos, $errores] = $this->validar($_POST);

        if ($errores) {
            $this->error('Revise el formulario', reset($errores), 422, ['errors' => $errores]);
        }

        try {
            $resultado = $id > 0
                ? $this->model->actualizar($id, $datos)
                : $this->model->registrar($datos);

            $this->auditar(
                $id > 0 ? 'EDITAR' : 'CREAR',
                'Estudiantes',
                ($id > 0 ? 'Editó' : 'Registró') . " al estudiante {$datos['nombres']} {$datos['apellidos']} "
                . "(cédula escolar {$resultado['cedula_escolar']})."
            );

            $this->ok(
                $id > 0 ? 'Estudiante actualizado con éxito.' : 'Estudiante registrado con éxito.',
                ['id' => $resultado['id'], 'cedula_escolar' => $resultado['cedula_escolar']]
            );
        } catch (DomainException $e) {
            $this->error('No se pudo guardar', $e->getMessage(), $e->getCode() ?: 422);
        } catch (Throwable $e) {
            error_log('[estudiante.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo procesar el registro del estudiante.', 500);
        }
    }

    public function eliminar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->error('ID inválido', 'El identificador del estudiante no es válido.');
        }

        try {
            $estudiante = $this->model->obtenerPorId($id);
            if (!$estudiante) {
                $this->error('No encontrado', 'El estudiante ya no existe.', 404);
            }

            if (!$this->model->eliminar($id)) {
                $this->error('Error', 'No se pudo eliminar el registro.', 500);
            }

            $this->auditar(
                'ELIMINAR',
                'Estudiantes',
                "Eliminó al estudiante {$estudiante['nombres']} {$estudiante['apellidos']} "
                . "(cédula escolar {$estudiante['cedula_escolar']})."
            );
            $this->ok('Estudiante eliminado correctamente.');
        } catch (Throwable $e) {
            error_log('[estudiante.eliminar] ' . $e->getMessage());
            $this->error('Error en base de datos', 'No se pudo eliminar el estudiante.', 500);
        }
    }

    public function obtenerRepresentante(): void
    {
        $cedula = trim((string)($_GET['cedula'] ?? ''));
        if ($cedula === '') {
            $this->error('Dato faltante', 'Cédula no proporcionada.');
        }

        try {
            $representante = $this->model->obtenerRepresentantePorCedula($cedula);
        } catch (Throwable $e) {
            error_log('[estudiante.obtenerRepresentante] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo consultar el representante.', 500);
        }

        if (!$representante) {
            $this->error('No encontrado', 'No se encontró el representante registrado.', 404);
        }

        $this->ok('OK', ['representante' => $representante]);
    }

    private function validar(array $in): array
    {
        $texto = static fn(string $k): string => preg_replace('/\s+/u', ' ', trim((string)($in[$k] ?? '')));

        $datos = [
            'nombres'              => $texto('nombres'),
            'apellidos'            => $texto('apellidos'),
            'fecha_nacimiento'     => trim((string)($in['fecha_nacimiento'] ?? '')),
            'genero'               => trim((string)($in['genero'] ?? '')),
            'seccion_id'           => (int)($in['seccion_id'] ?? 0) ?: null,
            'representante_cedula' => trim((string)($in['representante_cedula'] ?? '')),
            'rep_nombre'           => $texto('rep_nombre'),
            'rep_apellido'         => $texto('rep_apellido'),
            'rep_telefono'         => $texto('rep_telefono'),
            'rep_direccion'        => $texto('rep_direccion'),
        ];

        $e = [];

        foreach (['nombres' => 'Los nombres', 'apellidos' => 'Los apellidos'] as $campo => $etiqueta) {
            if ($datos[$campo] === '') {
                $e[$campo] = "$etiqueta del estudiante son obligatorios.";
            } elseif (mb_strlen($datos[$campo]) > 150) {
                $e[$campo] = "$etiqueta del estudiante no pueden superar 150 caracteres.";
            }
        }

        $fecha = DateTime::createFromFormat('!Y-m-d', $datos['fecha_nacimiento']);
        if (!$fecha || $fecha->format('Y-m-d') !== $datos['fecha_nacimiento']) {
            $e['fecha_nacimiento'] = 'La fecha de nacimiento no es válida.';
        } elseif ($fecha > new DateTime('today')) {
            $e['fecha_nacimiento'] = 'La fecha de nacimiento no puede ser futura.';
        } elseif ($fecha < new DateTime('-25 years')) {
            $e['fecha_nacimiento'] = 'La fecha de nacimiento no corresponde a un estudiante de primaria.';
        }

        if (!in_array($datos['genero'], ['M', 'F', 'Otro'], true)) {
            $e['genero'] = 'Seleccione el género.';
        }

        if (!preg_match('/^\d{6,10}$/', $datos['representante_cedula'])) {
            $e['representante_cedula'] = 'La cédula del representante debe tener entre 6 y 10 dígitos (solo números).';
        }

        foreach (['rep_nombre' => 'Los nombres', 'rep_apellido' => 'Los apellidos'] as $campo => $etiqueta) {
            if ($datos[$campo] === '') {
                $e[$campo] = "$etiqueta del representante son obligatorios.";
            } elseif (mb_strlen($datos[$campo]) > 150) {
                $e[$campo] = "$etiqueta del representante no pueden superar 150 caracteres.";
            }
        }

        if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $datos['rep_telefono'])) {
            $e['rep_telefono'] = 'El teléfono debe tener entre 7 y 20 caracteres (números, +, -, espacios).';
        }

        if ($datos['rep_direccion'] === '') {
            $e['rep_direccion'] = 'La dirección del representante es obligatoria.';
        } elseif (mb_strlen($datos['rep_direccion']) > 500) {
            $e['rep_direccion'] = 'La dirección es demasiado larga (máximo 500 caracteres).';
        }

        return [$datos, $e];
    }
}
