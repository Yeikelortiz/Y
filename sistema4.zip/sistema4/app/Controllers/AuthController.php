<?php
require_once __DIR__ . '/../Models/UserModel.php';
require_once __DIR__ . '/SecurityTrait.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Bitacora.php';

class AuthController
{
    private $model;
    use SecurityTrait;

    public function __construct()
    {
        $action = $_GET['action'] ?? 'login';

        if ($action !== 'logout' && isset($_SESSION['usuario_id'])) {
            $database = new Database();
            $pdo = $database->getConnection();
            $this->model = new UserModel($pdo);
            
            $estadoBloqueo = $this->model->verificarBloqueoUsuario($_SESSION['usuario_id']);
            
            if ($estadoBloqueo['bloqueado']) {
                $this->destruirSesionPorBloqueo($estadoBloqueo['minutos_restantes']);
            }
            
            $rol = $_SESSION['rol'] ?? '';
            
            switch ($rol) {
                case 'admin':
                    header("Location: index.php?controller=admin&action=index");
                    break;
                case 'director':
                    header("Location: index.php?controller=director&action=index");
                    break;
                case 'secretaria':
                    header("Location: index.php?controller=secretaria&action=index");
                    break;
                default:
                    // Rol no reconocido: cierra sesión por seguridad
                    $this->logout();
                    break;
            }
            exit;
        }

        if ($action !== 'logout') {
            $database = new Database();
            $pdo = $database->getConnection();
            $this->model = new UserModel($pdo);
        }
    }

    public function login()
    {
        $error = $_SESSION['flash_error'] ?? null;
        if (isset($_SESSION['flash_error'])) {
            unset($_SESSION['flash_error']);
        }
     
        require_once __DIR__ . '/../Views/auth/login.php';
    }

    public function authenticate()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: index.php?controller=auth&action=login");
            exit;
        }

        $email = $this->sanitizarEmail($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Rol elegido en el formulario: solo se aceptan los tres roles del sistema (lista blanca)
        $rol = $_POST['rol'] ?? '';
        $rol = in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : '';
        $rolSeleccionado = $rol; // para que la vista conserve la opción si hay un error

        if (!$email || empty($password) || $rol === '') {
            $error = "Por favor ingrese un correo válido, su contraseña y seleccione su rol.";
            require_once __DIR__ . '/../Views/auth/login.php';
            return;
        }

        $usuario = $this->model->obtenerPorEmail($email);
        $error = null;

        $database = new Database();
        $pdo = $database->getConnection();
        $bitacora = new Bitacora($pdo);

        if ($usuario) {
            $estadoBloqueo = $this->model->verificarBloqueoUsuario($usuario['id']);

            if ($estadoBloqueo['bloqueado']) {
                $error = "Cuenta bloqueada. Intente en {$estadoBloqueo['minutos_restantes']} minuto(s).";
            } 
            // El rol elegido debe coincidir con el de la cuenta; si no, se trata igual que una contraseña incorrecta (suma un intento fallido y
            // no revela con qué rol está registrado el correo)
            elseif (password_verify($password, $usuario['password']) && $usuario['rol'] === $rol) {
                $this->model->reiniciarIntentos($usuario['id']);
                session_regenerate_id(true);

                $recordar = !empty($_POST['recordar']);
                $this->emitirCookieDeSesion($recordar);
                $_SESSION['recordar'] = $recordar;


                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['nombre'] = $this->sanitizarTexto($usuario['nombre']);
                $_SESSION['rol'] = $usuario['rol'];
                
                $bitacora->registrar(
                    $usuario['id'], 
                    $usuario['nombre'], 
                    $usuario['rol'], 
                    'INICIO_SESION', 
                    'Autenticación', 
                    "El usuario {$usuario['nombre']} ({$usuario['rol']}) inició sesión correctamente."
                );

                switch ($usuario['rol']) {
                    case 'admin':
                        $destinoDefault = 'index.php?controller=admin&action=index';
                        break;
                    case 'director':
                        $destinoDefault = 'index.php?controller=director&action=index';
                        break;
                    case 'secretaria':
                        $destinoDefault = 'index.php?controller=secretaria&action=index';
                        break;
                    default:
                        $error = "Acceso denegado: Rol no autorizado.";
                        require_once __DIR__ . '/../Views/auth/login.php';
                        return;
                }
                
                $destino = $_SESSION['redirect_after_login'] ?? $destinoDefault;
                unset($_SESSION['redirect_after_login']);

                header("Location: " . $destino);
                exit;
            } 
            else {
                $intentos = $this->model->registrarIntentoFallido(
                    $usuario['id'], 
                    $usuario['intentos_fallidos'] ?? 0
                );

                if ($intentos >= 3) {
                    $error = "Ha superado el límite de intentos. Cuenta bloqueada por 15 minutos.";
                    
                    $bitacora->registrar(
                        $usuario['id'], 
                        $usuario['nombre'], 
                        $usuario['rol'], 
                        'BLOQUEO', 
                        'Autenticación', 
                        "La cuenta de {$usuario['nombre']} fue bloqueada temporalmente por superar los 3 intentos fallidos."
                    );
                } else {
                    $restantes = 3 - $intentos;
                    $error = "Credenciales  de accceso incorrectas. Le quedan {$restantes} intento(s).";
                }
            }
        } else {
            $error = "Credenciales de acceso incorrectas.";
        }

        require_once __DIR__ . '/../Views/auth/login.php';
    }

    // No se puede cambiar la configuración de una sesión ya iniciada, por eso se reenvía la cookie (la última Set-Cookie es la que
    // cuenta)
    private function emitirCookieDeSesion(bool $recordar): void
    {
        $vida = $recordar
            ? (defined('SESION_RECORDADA') ? SESION_RECORDADA : 2592000)
            : (defined('SESION_NORMAL') ? SESION_NORMAL : 3600);
        $p = session_get_cookie_params();
        $base = [
            'path'     => $p['path'],
            'domain'   => $p['domain'],
            'secure'   => $p['secure'],
            'httponly' => true,
            'samesite' => 'Strict',
        ];

        setcookie(session_name(), session_id(), $base + ['expires' => time() + $vida]);
        setcookie('recordar_sesion', $recordar ? '1' : '', $base + ['expires' => $recordar ? time() + $vida : time() - 3600]);
    }

    public function logout()
    {
        if (isset($_SESSION['usuario_id'])) {
            $database = new Database();
            $pdo = $database->getConnection();
            $bitacora = new Bitacora($pdo);
            
            $bitacora->registrar(
                $_SESSION['usuario_id'], 
                $_SESSION['nombre'] ?? 'Desconocido', 
                $_SESSION['rol'] ?? 'Desconocido', 
                'CIERRE_SESION', 
                'Autenticación', 
                "El usuario cerró sesión en el sistema."
            );
        }

        $_SESSION = array();

        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }

        setcookie('recordar_sesion', '', ['expires' => time() - 3600, 'path' => '/', 'httponly' => true, 'samesite' => 'Strict']);
        session_destroy();
        header("Location: index.php?controller=auth&action=login");
        exit;
    }
}