<?php
// Períodos académicos (año escolar) y cierre de sus momentos

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Periodo.php';

class PeriodoController extends BaseController
{
    private const ROLES_GESTION = ['admin', 'director'];
    private const ROLES_ADMIN   = ['admin'];

    private Periodo $model;

    public function __construct()
    {
        parent::__construct();
        $this->model = new Periodo($this->pdo);
    }

    public function index(): void
    {
        $rol = $this->rolActual();

        $this->vista('periodo/index', [
            'puedeGestionar' => $this->tieneRol(self::ROLES_GESTION),
            'puedeReabrir'   => $this->tieneRol(self::ROLES_ADMIN),
            'panel'          => in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : 'admin',
            'rolVisual'      => ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaría'][$rol] ?? ucfirst($rol),
            'nombreUsuario'  => $this->nombreUsuario(),
            'csrfToken'      => $this->tokenCsrf(),
        ]);
    }

    public function listar(): void
    {
        try {
            $this->ok('OK', ['periodos' => $this->model->obtenerTodos()]);
        } catch (Throwable $e) {
            error_log('[periodo.listar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar el listado de períodos.', 500);
        }
    }

    public function momentos(): void
    {
        try {
            $periodo = $this->buscarPeriodo((int)($_GET['periodo'] ?? 0));

            $this->ok('OK', [
                'periodo'  => $periodo,
                'momentos' => $this->model->momentos($periodo['id']),
            ]);
        } catch (Throwable $e) {
            error_log('[periodo.momentos] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron cargar los momentos del período.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        $id     = (int)($_POST['id'] ?? 0);
        $nombre = trim((string)($_POST['nombre'] ?? ''));

        try {
            if ($msg = $this->errorNombre($nombre, $id)) {
                $this->error('Revise el formulario', $msg, 422, ['errors' => ['nombre' => $msg]]);
            }

            if ($id > 0) {
                $this->buscarPeriodo($id);
                $this->model->renombrar($id, $nombre);
                $this->auditar('EDITAR', 'Períodos', "Renombró el período #{$id} a {$nombre}.");
                $this->ok('El período se actualizó correctamente.', ['id' => $id]);
            }

            $activo = $this->model->obtenerActivo();
            if ($activo) {
                $this->error('Ya hay un período activo', "Cierre primero el período {$activo['nombre']} antes de crear uno nuevo.", 409);
            }

            $nuevoId = $this->model->crear($nombre);
            $this->auditar('CREAR', 'Períodos', "Creó el período {$nombre} con sus 3 momentos académicos.");
            $this->ok('El período se creó con sus tres momentos académicos.', ['id' => $nuevoId], 201);
        } catch (PDOException $e) {
            // 1062 = nombre duplicado (otro usuario lo creó un instante antes)
            if ((int)($e->errorInfo[1] ?? 0) === 1062) {
                $this->error('Duplicado', 'Ya existe un período con ese nombre.', 422, ['errors' => ['nombre' => 'Ya existe un período con ese nombre.']]);
            }
            error_log('[periodo.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el período.', 500);
        } catch (Throwable $e) {
            error_log('[periodo.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el período.', 500);
        }
    }

    public function cambiarEstado(): void
    {
        $this->exigirPost();

        $id     = (int)($_POST['id'] ?? 0);
        $estado = (string)($_POST['estado'] ?? '');

        try {
            if (!in_array($estado, ['activo', 'cerrado'], true)) {
                $this->error('Solicitud no válida', 'El estado indicado no es válido.', 422);
            }
            $periodo = $this->buscarPeriodo($id);

            if ($periodo['estado'] === $estado) {
                $this->error('Sin cambios', "El período {$periodo['nombre']} ya está " . ($estado === 'activo' ? 'activo.' : 'cerrado.'), 409);
            }

            if ($estado === 'cerrado') {
                $this->exigirRol(self::ROLES_GESTION);
            } else {
                $this->exigirAdminParaReabrir();
                $otro = $this->model->obtenerActivo();
                if ($otro && $otro['id'] !== $id) {
                    $this->error('Ya hay un período activo', "Cierre primero el período {$otro['nombre']}.", 409);
                }
            }

            $this->model->cambiarEstado($id, $estado);

            if ($estado === 'cerrado') {
                $this->auditar('CERRAR', 'Períodos', "Cerró el período {$periodo['nombre']} y todos sus momentos académicos.");
                $this->ok('Período cerrado. Sus momentos quedaron cerrados: ya no se pueden modificar calificaciones ni asistencias.');
            }

            $this->auditar('ABRIR', 'Períodos', "Reabrió el período {$periodo['nombre']}.");
            $this->ok('Período reabierto. Reabra los momentos que necesite modificar.');
        } catch (Throwable $e) {
            $this->responderErrorBd($e, 'periodo.cambiarEstado', 'No se pudo cambiar el estado del período.');
        }
    }

    public function cambiarEstadoMomento(): void
    {
        $this->exigirPost();

        $momentoId = (int)($_POST['momento_id'] ?? 0);
        $estado    = (string)($_POST['estado'] ?? '');

        try {
            if (!in_array($estado, ['activo', 'cerrado'], true)) {
                $this->error('Solicitud no válida', 'El estado indicado no es válido.', 422);
            }

            $momento = $momentoId > 0 ? $this->model->momento($momentoId) : null;
            if (!$momento) {
                $this->error('No encontrado', 'El momento académico no existe.', 404);
            }
            $periodo = $this->buscarPeriodo($momento['periodo_id']);

            if ($momento['estado'] === $estado) {
                $this->error('Sin cambios', "El {$momento['nombre']} ya está " . ($estado === 'activo' ? 'activo.' : 'cerrado.'), 409);
            }
            if ($periodo['estado'] !== 'activo') {
                $this->error('Período cerrado', "El período {$periodo['nombre']} está cerrado. " . ($estado === 'activo' ? 'Reabra primero el período.' : ''), 409);
            }

            $hermanos = $this->model->momentos($periodo['id']);

            if ($estado === 'cerrado') {
                $this->exigirRol(self::ROLES_GESTION);

                foreach ($hermanos as $h) {
                    if ($h['id'] === $momento['id']) {
                        break;
                    }
                    if ($h['estado'] !== 'cerrado') {
                        $this->error('Orden de cierre', "Cierre primero el {$h['nombre']}.", 409);
                    }
                }
            } else {
                $this->exigirAdminParaReabrir();

                $despues = false;
                foreach ($hermanos as $h) {
                    if ($despues && $h['estado'] === 'cerrado') {
                        $this->error('Orden de reapertura', "Reabra primero el {$h['nombre']}.", 409);
                    }
                    if ($h['id'] === $momento['id']) {
                        $despues = true;
                    }
                }
            }

            $this->model->cambiarEstadoMomento($momento['id'], $estado);

            if ($estado === 'cerrado') {
                $this->auditar('CERRAR', 'Períodos', "Cerró el {$momento['nombre']} del período {$periodo['nombre']} (calificaciones y asistencias bloqueadas).");
                $this->ok("{$momento['nombre']} cerrado. Sus calificaciones y su asistencia ya no se pueden modificar.");
            }

            $this->auditar('ABRIR', 'Períodos', "Reabrió el {$momento['nombre']} del período {$periodo['nombre']}.");
            $this->ok("{$momento['nombre']} reabierto.");
        } catch (Throwable $e) {
            $this->responderErrorBd($e, 'periodo.cambiarEstadoMomento', 'No se pudo cambiar el estado del momento.');
        }
    }

    public function crearMomentos(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        try {
            $periodo = $this->buscarPeriodo((int)($_POST['periodo_id'] ?? 0));
            if ($periodo['estado'] !== 'activo') {
                $this->error('Período cerrado', 'No se pueden crear momentos en un período cerrado.', 409);
            }

            $creados = $this->model->crearMomentosPorDefecto($periodo['id']);
            if ($creados === 0) {
                $this->error('Ya existen', 'El período ya tiene momentos académicos.', 409);
            }

            $this->auditar('CREAR', 'Períodos', "Creó los {$creados} momentos académicos del período {$periodo['nombre']}.");
            $this->ok("Se crearon los {$creados} momentos académicos.", ['creados' => $creados]);
        } catch (Throwable $e) {
            error_log('[periodo.crearMomentos] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron crear los momentos académicos.', 500);
        }
    }

    public function eliminar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ADMIN);

        try {
            $periodo = $this->buscarPeriodo((int)($_POST['id'] ?? 0));

            if ($this->model->tieneSecciones($periodo['id'])) {
                $this->error('No se puede eliminar', 'El período tiene secciones asociadas. Elimínelas o reasígnelas primero.', 409);
            }
            if ($this->model->tieneCalificaciones($periodo['id'])) {
                $this->error('No se puede eliminar', 'El período tiene calificaciones registradas y se perderían.', 409);
            }

            if (!$this->model->eliminar($periodo['id'])) {
                $this->error('Error', 'No se pudo eliminar el período.', 500);
            }

            $this->auditar('ELIMINAR', 'Períodos', "Eliminó el período {$periodo['nombre']}.");
            $this->ok('Período eliminado correctamente.');
        } catch (Throwable $e) {
            error_log('[periodo.eliminar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo eliminar el período.', 500);
        }
    }

    private function tieneRol(array $roles): bool
    {
        return in_array($this->rolActual(), $roles, true);
    }

    private function buscarPeriodo(int $id): array
    {
        $periodo = $id > 0 ? $this->model->obtenerPorId($id) : null;
        if (!$periodo) {
            $this->error('No encontrado', 'El período seleccionado no existe.', 404);
        }

        return $periodo;
    }

    private function exigirAdminParaReabrir(): void
    {
        if (!$this->tieneRol(self::ROLES_ADMIN)) {
            $this->error('Acceso denegado', 'Solo el administrador puede reabrir períodos o momentos cerrados.', 403);
        }
    }

    private function errorNombre(string $nombre, int $exceptoId): ?string
    {
        if ($nombre === '') {
            return 'El año escolar es obligatorio.';
        }
        if (!preg_match('/^\d{4}-\d{4}$/', $nombre)) {
            return 'Use el formato AAAA-AAAA, por ejemplo 2026-2027.';
        }

        [$a, $b] = array_map('intval', explode('-', $nombre));
        if ($b !== $a + 1) {
            return 'El segundo año debe ser el siguiente al primero (por ejemplo 2026-2027).';
        }
        if ($a < 2000 || $a > 2100) {
            return 'El año escolar debe estar entre 2000 y 2100.';
        }
        if ($this->model->existeNombre($nombre, $exceptoId)) {
            return 'Ya existe un período con ese nombre.';
        }

        return null;
    }

    private function responderErrorBd(Throwable $e, string $contexto, string $mensaje)
    {
        error_log("[{$contexto}] " . $e->getMessage());

        if ($e instanceof PDOException && (int)($e->errorInfo[1] ?? 0) === 1054) {
            $this->error(
                'Falta actualizar la base de datos',
                'La tabla de momentos aún no tiene la columna fecha_cierre. Ejecute database/migracion_cierre_momentos.sql.',
                500
            );
        }

        $this->error('Error interno', $mensaje, 500);
    }
}
