<?php
trait SecurityTrait {

    public function sanitizarEmail(string $email): string|false
    {
        $emailLimpio = trim($email);

        if (!filter_var($emailLimpio, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        return $emailLimpio;
    }

    // Sanitiza cadenas de texto para prevenir ataques XSS
    public function sanitizarTexto(string $texto): string
    {
        $textoLimpio = trim($texto);
        return htmlspecialchars($textoLimpio, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public function verificarSesion(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['usuario_id'])) {
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            $this->redireccionar('index.php?controller=auth&action=login');
        }
    }

    public function verificarRol(array $rolesPermitidos): void
    {
        $this->verificarSesion();

        $rolActual = $_SESSION['rol'] ?? 'usuario';

        if (!in_array($rolActual, $rolesPermitidos, true)) {
            $_SESSION['flash_error'] = "Acceso denegado: No tienes los permisos necesarios.";
            $this->redireccionar('index.php?controller=dashboard&action=index');
        }
    }

    public function destruirSesionPorBloqueo(int $minutosRestantes): void
    {
        $_SESSION = [];

        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), 
                '', 
                time() - 42000,
                $params["path"], 
                $params["domain"],
                $params["secure"], 
                $params["httponly"]
            );
        }

        session_destroy();

        session_start();
        $_SESSION['flash_error'] = "Tu cuenta ha sido bloqueada. Intente en {$minutosRestantes} minuto(s).";

        $this->redireccionar('index.php?controller=auth&action=login');
    }

    private function redireccionar(string $url): void
    {
        header("Location: {$url}");
        exit;
    }
}