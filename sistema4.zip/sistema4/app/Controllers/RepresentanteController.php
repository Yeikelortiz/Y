<?php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Representante.php';
require_once __DIR__ . '/../Models/Estudiante.php';

class RepresentanteController extends BaseController
{
    private const POR_PAGINA      = 10;
    private const ROLES_ESCRITURA = ['admin', 'director','secretaria'];
    private const ROLES_ELIMINAR  = ['admin','director'];

    private Representante $model;
    private Estudiante $modelEstudiante;

    public function __construct()
    {
        parent::__construct();
        $this->model           = new Representante($this->pdo);
        $this->modelEstudiante = new Estudiante($this->pdo);
    }

    public function index(): void
    {
        $rol = $this->rolActual();

        if ($rol === 'admin') {
            $rolVisual = 'Administrador';
            $panel     = 'admin';
        } elseif ($rol === 'director') {
            $rolVisual = 'Director';
            $panel     = 'director';
        } else {
            $rolVisual = 'Secretaria';
            $panel     = 'secretaria';
        }

        $this->vista('ListaRepresentantes/index', [
            'secciones'     => $this->modelEstudiante->obtenerSecciones(),
            'puedeEditar'   => in_array($rol, self::ROLES_ESCRITURA, true),
            'puedeEliminar' => in_array($rol, self::ROLES_ELIMINAR, true),
            'esAdmin'       => $rol === 'admin',
            'rolVisual'     => $rolVisual,
            'panel'         => $panel,
            'nombreUsuario' => $this->nombreUsuario(),
            'csrfToken'     => $this->tokenCsrf(),
        ]);
    }

    public function listar(): void
    {
        try {
            $busqueda = mb_substr(trim((string)($_GET['busqueda'] ?? '')), 0, 100);
            $total    = $this->model->contar($busqueda);

            $totalPaginas = max(1, (int)ceil($total / self::POR_PAGINA));
            $pagina       = min(max(1, (int)($_GET['pagina'] ?? 1)), $totalPaginas);
            $offset       = ($pagina - 1) * self::POR_PAGINA;

            $this->ok('OK', [
                'representantes' => $this->model->listar(self::POR_PAGINA, $offset, $busqueda),
                'paginacion'     => [
                    'pagina'       => $pagina,
                    'totalPaginas' => $totalPaginas,
                    'total'        => $total,
                    'porPagina'    => self::POR_PAGINA,
                ],
            ]);
        } catch (Throwable $e) {
            error_log('[representante.listar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar el listado de representantes.', 500);
        }
    }

    public function detalle(): void
    {
        $cedula = trim((string)($_GET['cedula'] ?? ''));
        if ($cedula === '') {
            $this->error('Dato faltante', 'Cédula no proporcionada.');
        }

        try {
            $representante = $this->model->obtenerPorCedula($cedula);
            if (!$representante) {
                $this->error('No encontrado', 'No se encontró el representante.', 404);
            }

            $this->ok('OK', [
                'representante' => $representante,
                'estudiantes'   => $this->model->obtenerEstudiantes($cedula),
            ]);
        } catch (Throwable $e) {
            error_log('[representante.detalle] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo consultar el representante.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $cedulaOriginal = trim((string)($_POST['cedula_original'] ?? ''));
        $esNuevo        = $cedulaOriginal === '';

        [$rep, $errores] = $this->validarRepresentante($_POST);

        $agregarEstudiante = $esNuevo && !empty($_POST['agregar_estudiante']);
        $est = null;
        if ($agregarEstudiante) {
            [$est, $erroresEst] = $this->validarEstudiante($_POST);
            $errores += $erroresEst;
        }

        if ($errores) {
            $this->error('Revise el formulario', reset($errores), 422, ['errors' => $errores]);
        }

        try {
            $cedulaEscolar = null;

            if ($esNuevo) {
                if ($this->model->existe($rep['cedula'])) {
                    $this->error('Cédula duplicada', 'Ya existe un representante con esa cédula.', 409,
                        ['errors' => ['cedula' => 'Ya existe un representante con esa cédula.']]);
                }

                if ($agregarEstudiante) {
                    $resultado     = $this->modelEstudiante->registrar($this->datosParaEstudiante($est, $rep));
                    $cedulaEscolar = $resultado['cedula_escolar'];
                } else {
                    $this->model->crear($rep);
                }
            } else {
                if (!$this->model->existe($cedulaOriginal)) {
                    $this->error('No encontrado', 'El representante que intenta editar no existe.', 404);
                }
                if ($rep['cedula'] !== $cedulaOriginal && $this->model->existe($rep['cedula'])) {
                    $this->error('Cédula duplicada', 'La nueva cédula ya pertenece a otro representante.', 409,
                        ['errors' => ['cedula' => 'La nueva cédula ya pertenece a otro representante.']]);
                }

                $this->model->actualizar($cedulaOriginal, $rep);
            }

            $this->auditar(
                $esNuevo ? 'CREAR' : 'EDITAR',
                'Representantes',
                ($esNuevo ? 'Registró' : 'Editó') . " al representante {$rep['nombre']} {$rep['apellido']} ({$rep['cedula']})."
                . ($cedulaEscolar ? " Estudiante registrado con cédula escolar {$cedulaEscolar}." : '')
            );

            $this->ok(
                $esNuevo ? 'El representante se registró correctamente.' : 'Los cambios se guardaron correctamente.',
                ['cedula' => $rep['cedula'], 'cedula_escolar' => $cedulaEscolar]
            );
        } catch (DomainException $e) {
            $this->error('No se pudo guardar', $e->getMessage(), $e->getCode() ?: 422);
        } catch (Throwable $e) {
            error_log('[representante.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el registro del representante.', 500);
        }
    }

    public function agregarEstudiante(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $cedulaRep = trim((string)($_POST['representante_cedula'] ?? ''));
        [$est, $errores] = $this->validarEstudiante($_POST);

        if ($errores) {
            $this->error('Revise el formulario', reset($errores), 422, ['errors' => $errores]);
        }

        try {
            $rep = $this->model->obtenerPorCedula($cedulaRep);
            if (!$rep) {
                $this->error('No encontrado', 'El representante no existe.', 404);
            }

            $resultado = $this->modelEstudiante->registrar($this->datosParaEstudiante($est, $rep));

            $this->auditar(
                'CREAR',
                'Estudiantes',
                "Registró al estudiante {$est['nombres']} {$est['apellidos']} (cédula escolar {$resultado['cedula_escolar']}) "
                . "desde el representante {$rep['nombre']} {$rep['apellido']} ({$rep['cedula']})."
            );

            $this->ok('Estudiante registrado con éxito.', [
                'id'             => $resultado['id'],
                'cedula_escolar' => $resultado['cedula_escolar'],
            ]);
        } catch (DomainException $e) {
            $this->error('No se pudo guardar', $e->getMessage(), $e->getCode() ?: 422);
        } catch (Throwable $e) {
            error_log('[representante.agregarEstudiante] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo registrar al estudiante.', 500);
        }
    }

    public function eliminar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ELIMINAR);

        $cedula = trim((string)($_POST['cedula'] ?? ''));
        if ($cedula === '') {
            $this->error('Datos faltantes', 'Cédula no proporcionada para eliminar.');
        }

        try {
            $rep = $this->model->obtenerPorCedula($cedula);
            if (!$rep) {
                $this->error('No encontrado', 'El representante ya no existe.', 404);
            }

            if (!$this->model->eliminar($cedula)) {
                $this->error('Error', 'No se pudo eliminar el registro.', 500);
            }

            $this->auditar(
                'ELIMINAR',
                'Representantes',
                "Eliminó al representante {$rep['nombre']} {$rep['apellido']} ({$cedula}) "
                . "junto con {$rep['total_estudiantes']} estudiante(s) asociado(s)."
            );
            $this->ok('Representante eliminado correctamente.');
        } catch (Throwable $e) {
            error_log('[representante.eliminar] ' . $e->getMessage());
            $this->error('Error de eliminación', 'No se pudo eliminar el representante.', 500);
        }
    }

    private function datosParaEstudiante(array $est, array $rep): array
    {
        return [
            'nombres'              => $est['nombres'],
            'apellidos'            => $est['apellidos'],
            'fecha_nacimiento'     => $est['fecha_nacimiento'],
            'genero'               => $est['genero'],
            'seccion_id'           => $est['seccion_id'],
            'representante_cedula' => $rep['cedula'],
            'rep_nombre'           => $rep['nombre'],
            'rep_apellido'         => $rep['apellido'],
            'rep_telefono'         => $rep['telefono'],
            'rep_direccion'        => $rep['direccion'] ?? '',
        ];
    }

    private function limpiar(array $in, string $clave): string
    {
        return preg_replace('/\s+/u', ' ', trim((string)($in[$clave] ?? '')));
    }

    private function esNombreValido(string $texto): bool
    {
        return (bool)preg_match("/^\p{L}[\p{L}\s'.\-]*$/u", $texto);
    }

    private function validarRepresentante(array $in): array
    {
        $d = [
            'cedula'    => trim((string)($in['cedula'] ?? '')),
            'nombre'    => $this->limpiar($in, 'nombre'),
            'apellido'  => $this->limpiar($in, 'apellido'),
            'telefono'  => $this->limpiar($in, 'telefono'),
            'direccion' => $this->limpiar($in, 'direccion'),
        ];
        $e = [];

        if (!preg_match('/^\d{6,10}$/', $d['cedula'])) {
            $e['cedula'] = 'La cédula debe tener entre 6 y 10 dígitos (solo números).';
        }

        foreach (['nombre' => 'Los nombres', 'apellido' => 'Los apellidos'] as $campo => $etiqueta) {
            if ($d[$campo] === '') {
                $e[$campo] = "$etiqueta son obligatorios.";
            } elseif (mb_strlen($d[$campo]) > 150) {
                $e[$campo] = "$etiqueta no pueden superar 150 caracteres.";
            } elseif (!$this->esNombreValido($d[$campo])) {
                $e[$campo] = "$etiqueta solo pueden contener letras y espacios.";
            }
        }

        if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $d['telefono'])) {
            $e['telefono'] = 'El teléfono debe tener entre 7 y 20 caracteres (números, +, -, espacios).';
        }

        if (mb_strlen($d['direccion']) > 500) {
            $e['direccion'] = 'La dirección es demasiado larga (máximo 500 caracteres).';
        }

        return [$d, $e];
    }

    private function validarEstudiante(array $in): array
    {
        $d = [
            'nombres'          => $this->limpiar($in, 'est_nombres'),
            'apellidos'        => $this->limpiar($in, 'est_apellidos'),
            'fecha_nacimiento' => trim((string)($in['est_fecha_nacimiento'] ?? '')),
            'genero'           => trim((string)($in['est_genero'] ?? '')),
            'seccion_id'       => (int)($in['est_seccion_id'] ?? 0) ?: null,
        ];
        $e = [];

        foreach (['nombres' => 'Los nombres', 'apellidos' => 'Los apellidos'] as $campo => $etiqueta) {
            if ($d[$campo] === '') {
                $e['est_' . $campo] = "$etiqueta del estudiante son obligatorios.";
            } elseif (mb_strlen($d[$campo]) > 150) {
                $e['est_' . $campo] = "$etiqueta del estudiante no pueden superar 150 caracteres.";
            } elseif (!$this->esNombreValido($d[$campo])) {
                $e['est_' . $campo] = "$etiqueta del estudiante solo pueden contener letras y espacios.";
            }
        }

        $fecha = DateTime::createFromFormat('!Y-m-d', $d['fecha_nacimiento']);
        if (!$fecha || $fecha->format('Y-m-d') !== $d['fecha_nacimiento']) {
            $e['est_fecha_nacimiento'] = 'La fecha de nacimiento no es válida.';
        } elseif ($fecha > new DateTime('today')) {
            $e['est_fecha_nacimiento'] = 'La fecha de nacimiento no puede ser futura.';
        } elseif ($fecha < new DateTime('-25 years')) {
            $e['est_fecha_nacimiento'] = 'La fecha de nacimiento no corresponde a un estudiante de primaria.';
        }

        if (!in_array($d['genero'], ['M', 'F', 'Otro'], true)) {
            $e['est_genero'] = 'Seleccione el género.';
        }

        return [$d, $e];
    }
}
