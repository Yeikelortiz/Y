<?php
// Módulo de reportes académicos y estadísticos 

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Reporte.php';
require_once __DIR__ . '/../Helpers/XlsxWriter.php';

class ReporteController extends BaseController
{
    private const TIPOS = [
        'estudiantes' => 'Listado de estudiantes',
        'rendimiento' => 'Rendimiento por sección',
        'reprobados'  => 'Estudiantes reprobados',
        'asistencias' => 'Asistencias',
    ];

    private Reporte $model;

    public function __construct()
    {
        parent::__construct();
        $this->model = new Reporte($this->pdo);
    }

    public function index(): void
    {
        $rol     = $this->rolActual();
        $activo  = $this->model->periodoActivo();
        $tipo    = (string)($_GET['tipo'] ?? '');

        $this->vista('reporte/index', [
            'tipos'          => self::TIPOS,
            'periodos'       => $this->model->periodos(),
            'periodoInicial' => $activo ? $activo['id'] : 0,
            'tipoInicial'    => isset(self::TIPOS[$tipo]) ? $tipo : 'estudiantes',
            'seccionInicial' => (int)($_GET['seccion'] ?? 0),
            'hoy'            => date('Y-m-d'),
            'inicioMes'      => date('Y-m-01'),
            'panel'          => in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : 'admin',
            'rolVisual'      => ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaría'][$rol] ?? ucfirst($rol),
            'nombreUsuario'  => $this->nombreUsuario(),
        ]);
    }

    public function opciones(): void
    {
        try {
            $periodoId = (int)($_GET['periodo'] ?? 0);
            if (!$this->model->periodo($periodoId)) {
                $this->error('No encontrado', 'El período seleccionado no existe.', 404);
            }

            $this->ok('OK', [
                'secciones' => $this->model->seccionesDePeriodo($periodoId),
                'momentos'  => $this->model->momentosDePeriodo($periodoId),
            ]);
        } catch (Throwable $e) {
            error_log('[reporte.opciones] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron cargar las opciones del período.', 500);
        }
    }

    public function datos(): void
    {
        try {
            [$p, $errores] = $this->parametros($_GET);
            if ($errores) {
                $this->error('Revise los filtros', reset($errores), 422, ['errors' => $errores]);
            }

            $this->ok('OK', ['reporte' => $this->construir($p)]);
        } catch (Throwable $e) {
            error_log('[reporte.datos] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo generar el reporte.', 500);
        }
    }

    public function exportar(): void
    {
        try {
            [$p, $errores] = $this->parametros($_GET);
            if ($errores) {
                $this->paginaError(reset($errores), 422);
            }

            $r = $this->construir($p);

            $x = new XlsxWriter($r['titulo']);
            $x->agregarFila(['E.B. Olimpia Barrios'], 'negrita');
            $x->agregarFila([$r['titulo']], 'titulo');
            foreach ($r['filtros'] as [$etiqueta, $valor]) {
                $x->agregarFila([$etiqueta . ': ' . $valor]);
            }
            $x->agregarFila(['Emitido el ' . date('d/m/Y H:i') . ' por ' . $this->nombreUsuario()]);
            $x->agregarFilaVacia();

            $filaEncabezado = $x->agregarFila(array_column($r['columnas'], 'titulo'), 'encabezado', 18);

            foreach ($r['filas'] as $fila) {
                $celdas = [];
                foreach ($r['columnas'] as $col) {
                    $valor = $fila[$col['clave']] ?? null;
                    $celdas[] = match ($col['tipo']) {
                        'numero'     => [$valor, 'numero'],
                        'porcentaje' => [$valor === null ? null : $valor / 100, 'porcentaje'],
                        default      => [$valor === null ? '' : (string)$valor, 'dato'],
                    };
                }
                $x->agregarFila($celdas, 'dato', 60);
            }
            if (!$r['filas']) {
                $x->agregarFila(['Sin registros para los filtros seleccionados.']);
            }

            if ($r['resumen']) {
                $x->agregarFilaVacia();
                $x->agregarFila(['Resumen'], 'negrita');
                foreach ($r['resumen'] as [$etiqueta, $valor]) {
                    $x->agregarFila([$etiqueta . ': ' . $valor]);
                }
            }
            foreach ($r['notas'] as $i => $nota) {
                if ($i === 0) {
                    $x->agregarFilaVacia();
                }
                $x->agregarFila([$nota]);
            }

            $x->congelarHasta($filaEncabezado);

            $this->auditar('EXPORTAR', 'Reportes', "Exportó a Excel el reporte \"{$r['titulo']}\" (período {$p['periodo']['nombre']}).");
            $x->enviar('reporte_' . $p['tipo'] . '_' . $p['periodo']['nombre'] . '_' . date('Ymd_His') . '.xlsx');
        } catch (RuntimeException $e) {
            error_log('[reporte.exportar] ' . $e->getMessage());
            $this->paginaError($e->getMessage(), 500);
        } catch (Throwable $e) {
            error_log('[reporte.exportar] ' . $e->getMessage());
            $this->paginaError('No se pudo generar el archivo de Excel.', 500);
        }
    }

    private function parametros(array $in): array
    {
        $e = [];
        $p = ['tipo' => (string)($in['tipo'] ?? ''), 'periodo' => null, 'seccion' => null, 'momento' => null];

        if (!isset(self::TIPOS[$p['tipo']])) {
            $e['tipo'] = 'Seleccione un tipo de reporte válido.';
        }

        $periodoId = (int)($in['periodo'] ?? 0);
        if ($periodoId <= 0) {
            $activo    = $this->model->periodoActivo();
            $periodoId = $activo ? $activo['id'] : 0;
        }
        $p['periodo'] = $periodoId > 0 ? $this->model->periodo($periodoId) : null;
        if (!$p['periodo']) {
            $e['periodo'] = 'Seleccione un período válido.';

            return [$p, $e];
        }

        $seccionId = (int)($in['seccion'] ?? 0);
        if ($seccionId > 0) {
            foreach ($this->model->seccionesDePeriodo($periodoId) as $s) {
                if ($s['id'] === $seccionId) {
                    $p['seccion'] = $s;
                    break;
                }
            }
            if (!$p['seccion']) {
                $e['seccion'] = 'La sección seleccionada no pertenece al período.';
            }
        }

        $momentoId = (int)($in['momento'] ?? 0);
        if ($momentoId > 0 && in_array($p['tipo'], ['rendimiento', 'reprobados', 'asistencias'], true)) {
            foreach ($this->model->momentosDePeriodo($periodoId) as $m) {
                if ($m['id'] === $momentoId) {
                    $p['momento'] = $m;
                    break;
                }
            }
            if (!$p['momento']) {
                $e['momento'] = 'El momento académico no pertenece al período.';
            }
        }

        return [$p, $e];
    }

    private function construir(array $p): array
    {
        $filtros = [
            ['Período', $p['periodo']['nombre'] . ($p['periodo']['estado'] === 'activo' ? '' : ' (cerrado)')],
            ['Sección', $p['seccion']['etiqueta'] ?? 'Todas las secciones'],
        ];

        switch ($p['tipo']) {
            case 'rendimiento':
                array_pop($filtros);
                $filtros[] = ['Momento', $p['momento']['nombre'] ?? 'Todos los momentos'];
                $r = $this->reporteRendimiento($p);
                break;
            case 'reprobados':
                $filtros[] = ['Momento', $p['momento']['nombre'] ?? 'Todos los momentos'];
                $r = $this->reporteReprobados($p);
                break;
            case 'asistencias':
                $filtros[] = ['Momento', $p['momento']['nombre'] ?? 'Todos los momentos'];
                $r = $this->reporteAsistencias($p);
                break;
            default:
                $r = $this->reporteEstudiantes($p);
        }

        return array_merge(['tipo' => $p['tipo'], 'titulo' => self::TIPOS[$p['tipo']], 'filtros' => $filtros], $r);
    }

    private function reporteEstudiantes(array $p): array
    {
        $filas = [];
        $porGenero = [];
        $porGrado  = [];

        foreach ($this->model->listadoEstudiantes($p['periodo']['id'], $p['seccion']['id'] ?? 0) as $i => $f) {
            $filas[] = [
                'n'                    => $i + 1,
                'cedula_escolar'       => $f['cedula_escolar'],
                'apellidos'            => $f['apellidos'],
                'nombres'              => $f['nombres'],
                'genero'               => $f['genero'],
                'fecha_nacimiento'     => $this->fecha($f['fecha_nacimiento']),
                'edad'                 => $f['edad'] !== null ? (int)$f['edad'] : null,
                'grado'                => (int)$f['grado'],
                'seccion'              => $f['seccion'],
                'docente'              => $f['docente'] ?? 'Sin docente',
                'representante'        => $f['representante'] ?? '',
                'representante_cedula' => $f['representante_cedula'],
                'rep_telefono'         => $f['rep_telefono'] ?? '',
            ];
            $porGenero[$f['genero']] = ($porGenero[$f['genero']] ?? 0) + 1;
            $porGrado[(int)$f['grado']] = ($porGrado[(int)$f['grado']] ?? 0) + 1;
        }

        $resumen = [['Total de estudiantes', count($filas)]];
        foreach (['M' => 'Masculino', 'F' => 'Femenino', 'Otro' => 'Otro'] as $clave => $texto) {
            if (!empty($porGenero[$clave])) {
                $resumen[] = [$texto, $porGenero[$clave]];
            }
        }
        ksort($porGrado);
        foreach ($porGrado as $grado => $n) {
            $resumen[] = ["Matrícula {$grado}° grado", $n];
        }

        return [
            'columnas' => [
                $this->col('n', 'N°', 'numero'),
                $this->col('cedula_escolar', 'Cédula escolar'),
                $this->col('apellidos', 'Apellidos'),
                $this->col('nombres', 'Nombres'),
                $this->col('genero', 'Género'),
                $this->col('fecha_nacimiento', 'Fecha de nacimiento'),
                $this->col('edad', 'Edad', 'numero'),
                $this->col('grado', 'Grado', 'numero'),
                $this->col('seccion', 'Sección'),
                $this->col('docente', 'Docente titular'),
                $this->col('representante', 'Representante'),
                $this->col('representante_cedula', 'C.I. representante'),
                $this->col('rep_telefono', 'Teléfono representante'),
            ],
            'filas'   => $filas,
            'resumen' => $resumen,
            'notas'   => [],
        ];
    }

    private function reporteRendimiento(array $p): array
    {
        $filas = [];
        $porMomento = [];

        foreach ($this->model->rendimiento($p['periodo']['id'], $p['momento']['id'] ?? 0) as $f) {
            $matricula  = (int)$f['matricula'];
            $aprobados  = (int)$f['aprobados'];
            $reprobados = (int)$f['reprobados'];
            $sin        = max(0, $matricula - $aprobados - $reprobados);

            $filas[] = [
                'grado'          => (int)$f['grado'],
                'seccion'        => $f['seccion'],
                'docente'        => $f['docente'] ?? 'Sin docente',
                'momento'        => $f['momento'],
                'matricula'      => $matricula,
                'aprobados'      => $aprobados,
                'reprobados'     => $reprobados,
                'sin_calificar'  => $sin,
                'pct_aprobacion' => $this->porcentaje($aprobados, $aprobados + $reprobados),
            ];

            $m = &$porMomento[$f['momento']];
            $m = $m ?? ['aprobados' => 0, 'reprobados' => 0, 'sin' => 0, 'matricula' => 0, 'secciones' => 0];
            $m['aprobados'] += $aprobados;
            $m['reprobados'] += $reprobados;
            $m['sin'] += $sin;
            $m['matricula'] += $matricula;
            $m['secciones']++;
            unset($m);
        }

        $resumen = [];
        foreach ($porMomento as $momento => $m) {
            $pct = $this->porcentaje($m['aprobados'], $m['aprobados'] + $m['reprobados']);
            $resumen[] = [
                $momento,
                "{$m['secciones']} secciones · matrícula {$m['matricula']} · aprobados {$m['aprobados']} · reprobados {$m['reprobados']}"
                . " · sin calificar {$m['sin']} · aprobación " . ($pct === null ? 'sin datos' : number_format($pct, 1, '.', '') . '%'),
            ];
        }

        return [
            'columnas' => [
                $this->col('grado', 'Grado', 'numero'),
                $this->col('seccion', 'Sección'),
                $this->col('docente', 'Docente titular'),
                $this->col('momento', 'Momento'),
                $this->col('matricula', 'Matrícula', 'numero'),
                $this->col('aprobados', 'Aprobados', 'numero'),
                $this->col('reprobados', 'Reprobados', 'numero'),
                $this->col('sin_calificar', 'Sin calificar', 'numero'),
                $this->col('pct_aprobacion', '% aprobación', 'porcentaje'),
            ],
            'filas'   => $filas,
            'resumen' => $resumen,
            'notas'   => ['% de aprobación = Aprobados / (Aprobados + Reprobados). Los estudiantes sin calificar no se cuentan en el porcentaje.'],
        ];
    }

    private function reporteReprobados(array $p): array
    {
        $filas = [];
        $distintos = [];

        foreach ($this->model->reprobados($p['periodo']['id'], $p['momento']['id'] ?? 0, $p['seccion']['id'] ?? 0) as $i => $f) {
            $filas[] = [
                'n'              => $i + 1,
                'cedula_escolar' => $f['cedula_escolar'],
                'apellidos'      => $f['apellidos'],
                'nombres'        => $f['nombres'],
                'grado'          => (int)$f['grado'],
                'seccion'        => $f['seccion'],
                'docente'        => $f['docente'] ?? 'Sin docente',
                'momento'        => $f['momento'],
                'descripcion'    => $f['descripcion'] ?? '',
                'representante'  => $f['representante'] ?? '',
                'rep_telefono'   => $f['rep_telefono'] ?? '',
            ];
            $distintos[$f['cedula_escolar']] = true;
        }

        return [
            'columnas' => [
                $this->col('n', 'N°', 'numero'),
                $this->col('cedula_escolar', 'Cédula escolar'),
                $this->col('apellidos', 'Apellidos'),
                $this->col('nombres', 'Nombres'),
                $this->col('grado', 'Grado', 'numero'),
                $this->col('seccion', 'Sección'),
                $this->col('docente', 'Docente titular'),
                $this->col('momento', 'Momento'),
                $this->col('descripcion', 'Descripción del desempeño'),
                $this->col('representante', 'Representante'),
                $this->col('rep_telefono', 'Teléfono representante'),
            ],
            'filas'   => $filas,
            'resumen' => [
                ['Calificaciones reprobadas', count($filas)],
                ['Estudiantes distintos reprobados', count($distintos)],
            ],
            'notas'   => [],
        ];
    }

    private function reporteAsistencias(array $p): array
    {
        $filas = [];
        $tot = ['asistencias' => 0, 'inasistencias' => 0, 'registrados' => 0];

        foreach ($this->model->asistencias($p['periodo']['id'], $p['seccion']['id'] ?? 0, $p['momento']['id'] ?? 0) as $i => $f) {
            $asistencias   = (int)$f['asistencias'];
            $inasistencias = (int)$f['inasistencias'];
            $total         = $asistencias + $inasistencias;

            $filas[] = [
                'n'              => $i + 1,
                'cedula_escolar' => $f['cedula_escolar'],
                'apellidos'      => $f['apellidos'],
                'nombres'        => $f['nombres'],
                'grado'          => (int)$f['grado'],
                'seccion'        => $f['seccion'],
                'asistencias'    => $asistencias,
                'inasistencias'  => $inasistencias,
                'total'          => $total,
                'pct_asistencia' => $this->porcentaje($asistencias, $total),
            ];

            $tot['asistencias']   += $asistencias;
            $tot['inasistencias'] += $inasistencias;
            $tot['registrados']   += ((int)$f['momentos'] > 0) ? 1 : 0;
        }

        $pctGlobal = $this->porcentaje($tot['asistencias'], $tot['asistencias'] + $tot['inasistencias']);

        return [
            'columnas' => [
                $this->col('n', 'N°', 'numero'),
                $this->col('cedula_escolar', 'Cédula escolar'),
                $this->col('apellidos', 'Apellidos'),
                $this->col('nombres', 'Nombres'),
                $this->col('grado', 'Grado', 'numero'),
                $this->col('seccion', 'Sección'),
                $this->col('asistencias', 'Asistencias', 'numero'),
                $this->col('inasistencias', 'Inasistencias', 'numero'),
                $this->col('total', 'Total días', 'numero'),
                $this->col('pct_asistencia', '% asistencia', 'porcentaje'),
            ],
            'filas'   => $filas,
            'resumen' => [
                ['Estudiantes', count($filas)],
                ['Con asistencia registrada', $tot['registrados']],
                ['Total de asistencias', $tot['asistencias']],
                ['Total de inasistencias', $tot['inasistencias']],
                ['% de asistencia global', $pctGlobal === null ? 'sin datos' : number_format($pctGlobal, 1, '.', '') . '%'],
            ],
            'notas'   => ['% de asistencia = Asistencias / (Asistencias + Inasistencias) del momento seleccionado, o de todos los momentos del período.'],
        ];
    }

    private function col(string $clave, string $titulo, string $tipo = 'texto'): array
    {
        return ['clave' => $clave, 'titulo' => $titulo, 'tipo' => $tipo];
    }

    private function porcentaje(int $parte, int $total): ?float
    {
        return $total > 0 ? round($parte / $total * 100, 1) : null;
    }

    private function fecha(?string $iso): string
    {
        if (!$iso || str_starts_with($iso, '0000')) {
            return '';
        }
        $d = DateTime::createFromFormat('Y-m-d', $iso);

        return $d ? $d->format('d/m/Y') : '';
    }
}
