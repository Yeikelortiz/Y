<?php
require_once __DIR__ . '/SecurityTrait.php';
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/UserModel.php';

class SecretariaController 
{
    use SecurityTrait;

    public function __construct() 
    {
        $this->verificarSesion();
        $this->verificarRol(['secretaria']);
        
        $database = new Database();
        $pdo = $database->getConnection();
        $model = new UserModel($pdo);
        
        $estadoBloqueo = $model->verificarBloqueoUsuario($_SESSION['usuario_id']);
        
        if ($estadoBloqueo['bloqueado']) {
            $this->destruirSesionPorBloqueo($estadoBloqueo['minutos_restantes']);
        }
    }

    public function index() 
    {
        $nombreUsuario = $_SESSION['nombre'] ?? 'Secretaria';
        $rolUsuario    = $_SESSION['rol'] ?? 'secretaria';
        
        $mensajeError = $_SESSION['flash_error'] ?? null;
        

        if (isset($_SESSION['flash_error'])) {
            unset($_SESSION['flash_error']);
        }
        if (isset($_SESSION['flash_success'])) {
            unset($_SESSION['flash_success']);
        }

        require_once __DIR__ . '/../Views/secretaria/index.php';
    }
}