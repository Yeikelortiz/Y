<?php
// Bitácora de auditoría 

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Bitacora.php';
require_once __DIR__ . '/../Helpers/XlsxWriter.php';

class BitacoraController extends BaseController
{
    private const ROLES_CONSULTA   = ['admin', 'director'];
    private const POR_PAGINA       = [10, 25, 50, 100];
    private const MAX_EXPORTACION  = 5000;

    private Bitacora $model;

    public function __construct(?PDO $pdo = null)
    {
        parent::__construct();
        if ($pdo !== null) {
            $this->pdo = $pdo;
        }
        $this->model = new Bitacora($this->pdo);
    }

    public function registrar($usuario_id, $nombre_usuario, $rol_usuario, $accion, $modulo, $descripcion)
    {
        return $this->model->registrar(
            $usuario_id,
            $nombre_usuario,
            $rol_usuario,
            $accion,
            $modulo,
            $descripcion
        );
    }

    public function index(): void
    {
        if (!$this->puedeConsultar()) {
            $this->paginaError('Solo el administrador y el director pueden consultar la bitácora.', 403);
        }

        $rol = $this->rolActual();

        $this->vista('bitacora/index', [
            'panel'         => $rol === 'director' ? 'director' : 'admin',
            'rolVisual'     => $rol === 'director' ? 'Director' : 'Administrador',
            'nombreUsuario' => html_entity_decode($this->nombreUsuario(), ENT_QUOTES, 'UTF-8'),
            'hoy'           => date('Y-m-d'),
        ]);
    }

    public function listar(): void
    {
        $this->exigirRol(self::ROLES_CONSULTA);

        try {
            [$f, $errores] = $this->parametros($_GET);
            if ($errores) {
                $this->error('Revise los filtros', reset($errores), 422, ['errors' => $errores]);
            }

            $porPagina = (int)($_GET['porPagina'] ?? 25);
            if (!in_array($porPagina, self::POR_PAGINA, true)) {
                $porPagina = 25;
            }

            $total        = $this->model->contar($f);
            $totalPaginas = max(1, (int)ceil($total / $porPagina));
            $pagina       = min(max(1, (int)($_GET['pagina'] ?? 1)), $totalPaginas);
            $datos = [
                'registros'  => $this->model->listar($f, $porPagina, ($pagina - 1) * $porPagina),
                'paginacion' => ['pagina' => $pagina, 'totalPaginas' => $totalPaginas, 'total' => $total, 'porPagina' => $porPagina],
                'resumen'    => $this->model->resumen(),
            ];

            if (!empty($_GET['catalogos'])) {
                $datos['catalogos'] = $this->model->catalogos();
            }

            $this->ok('OK', $datos);
        } catch (Throwable $e) {
            error_log('[bitacora.listar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar la bitácora.', 500);
        }
    }

    public function exportar(): void
    {
        if (!$this->puedeConsultar()) {
            $this->paginaError('Solo el administrador y el director pueden exportar la bitácora.', 403);
        }

        try {
            [$f, $errores] = $this->parametros($_GET);
            if ($errores) {
                $this->paginaError(reset($errores), 422);
            }

            $total     = $this->model->contar($f);
            $registros = $this->model->listar($f, self::MAX_EXPORTACION, 0);

            $x = new XlsxWriter('Bitácora');
            $x->agregarFila(['E.B. Olimpia Barrios'], 'negrita');
            $x->agregarFila(['Bitácora de auditoría del sistema'], 'titulo');
            foreach ($this->describirFiltros($f) as $linea) {
                $x->agregarFila([$linea]);
            }
            $x->agregarFila(['Emitido el ' . date('d/m/Y H:i') . ' por ' . html_entity_decode($this->nombreUsuario(), ENT_QUOTES, 'UTF-8')]);
            $x->agregarFilaVacia();

            $fila = $x->agregarFila(['ID', 'Fecha y hora', 'Usuario', 'Rol', 'Acción', 'Módulo', 'Descripción'], 'encabezado', 18);
            foreach ($registros as $r) {
                $x->agregarFila([
                    [$r['id'], 'numero'],
                    $r['fecha_registro'],
                    $r['nombre_usuario'],
                    $r['rol_usuario'],
                    $r['accion'],
                    $r['modulo'],
                    $r['descripcion'],
                ], 'dato', 40);
            }
            if (!$registros) {
                $x->agregarFila(['Sin eventos para los filtros seleccionados.']);
            } elseif ($total > count($registros)) {
                $x->agregarFilaVacia();
                $x->agregarFila(['Se exportaron los ' . count($registros) . ' eventos más recientes de ' . $total . ' que coinciden con los filtros.']);
            }
            $x->congelarHasta($fila);

            $this->auditar('EXPORTAR', 'Bitácora', 'Exportó a Excel ' . count($registros) . ' evento(s) de la bitácora.');
            $x->enviar('bitacora_' . date('Ymd_His') . '.xlsx');
        } catch (RuntimeException $e) {
            error_log('[bitacora.exportar] ' . $e->getMessage());
            $this->paginaError($e->getMessage(), 500);
        } catch (Throwable $e) {
            error_log('[bitacora.exportar] ' . $e->getMessage());
            $this->paginaError('No se pudo generar el archivo de Excel.', 500);
        }
    }

    private function puedeConsultar(): bool
    {
        return in_array($this->rolActual(), self::ROLES_CONSULTA, true);
    }

    private function parametros(array $in): array
    {
        $e = [];
        $f = [
            'q'       => mb_substr(trim((string)($in['q'] ?? '')), 0, 100),
            'modulo'  => trim((string)($in['modulo'] ?? '')),
            'accion'  => trim((string)($in['accion'] ?? '')),
            'rol'     => trim((string)($in['rol'] ?? '')),
            'usuario' => (int)($in['usuario'] ?? 0),
            'desde'   => trim((string)($in['desde'] ?? '')),
            'hasta'   => trim((string)($in['hasta'] ?? '')),
        ];

        foreach (['modulo', 'accion', 'rol'] as $campo) {
            if (mb_strlen($f[$campo]) > 50) {
                $e[$campo] = 'El valor del filtro es demasiado largo.';
            }
        }

        $d = $f['desde'] !== '' ? DateTime::createFromFormat('!Y-m-d', $f['desde']) : null;
        $h = $f['hasta'] !== '' ? DateTime::createFromFormat('!Y-m-d', $f['hasta']) : null;

        if ($f['desde'] !== '' && (!$d || $d->format('Y-m-d') !== $f['desde'])) {
            $e['desde'] = 'La fecha "desde" no es válida.';
        }
        if ($f['hasta'] !== '' && (!$h || $h->format('Y-m-d') !== $f['hasta'])) {
            $e['hasta'] = 'La fecha "hasta" no es válida.';
        }
        if (!isset($e['desde']) && !isset($e['hasta'])) {
            if ($d && $h && $d > $h) {
                $e['desde'] = 'La fecha "desde" no puede ser posterior a "hasta".';
            } elseif ($h && $f['hasta'] > date('Y-m-d')) {
                $e['hasta'] = 'La fecha "hasta" no puede ser futura.';
            }
        }

        return [$f, $e];
    }

    private function describirFiltros(array $f): array
    {
        $lineas = [];
        $mapa = ['q' => 'Texto', 'modulo' => 'Módulo', 'accion' => 'Acción', 'rol' => 'Rol'];
        foreach ($mapa as $clave => $etiqueta) {
            if ($f[$clave] !== '') {
                $lineas[] = "{$etiqueta}: {$f[$clave]}";
            }
        }
        if ($f['usuario'] > 0) {
            $lineas[] = 'Usuario (id): ' . $f['usuario'];
        }
        if ($f['desde'] !== '' || $f['hasta'] !== '') {
            $lineas[] = 'Rango de fechas: ' . ($f['desde'] ?: 'inicio') . ' al ' . ($f['hasta'] ?: 'hoy');
        }

        return $lineas ?: ['Sin filtros: todos los eventos'];
    }
}