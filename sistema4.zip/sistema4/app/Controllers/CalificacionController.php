<?php
// Panel de calificaciones por sección y momento académico

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Calificacion.php';
require_once __DIR__ . '/../Models/Seccion.php';

class CalificacionController extends BaseController
{
    private const ROLES_ESCRITURA   = ['admin', 'director', 'secretaria'];
    private const ROLES_MOMENTOS    = ['admin', 'director'];
    private const MAX_DESCRIPCION   = 500;

    private Calificacion $model;
    private Seccion $modelSeccion;

    public function __construct()
    {
        parent::__construct();
        $this->model        = new Calificacion($this->pdo);
        $this->modelSeccion = new Seccion($this->pdo);
    }

    public function index(): void
    {
        $rol = $this->rolActual();

        $this->vista('calificacion/index', [
            'secciones'     => $this->modelSeccion->obtenerTodos(),
            'estados'       => Calificacion::ESTADOS,
            'puedeEditar'   => $this->puedeEscribir(),
            'puedeCrearMomentos' => in_array($rol, self::ROLES_MOMENTOS, true),
            'panel'         => in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : 'admin',
            'rolVisual'     => ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaría'][$rol] ?? ucfirst($rol),
            'nombreUsuario' => $this->nombreUsuario(),
            'csrfToken'     => $this->tokenCsrf(),
        ]);
    }

    public function reporte(): void
    {
        $reporte = $this->datosReporte();

        $this->vista('calificacion/reporte', [
            'reporte'    => $reporte,
            'emitidoPor' => $this->nombreUsuario(),
            'emitidoEn'  => date('d/m/Y H:i'),
        ]);
    }

    // CSV (separado por ; y con BOM para que Excel abra bien los acentos)
    public function exportar(): void
    {
        $r = $this->datosReporte();
        $s = $r['seccion'];

        $docente = $s['sin_docente'] ? 'Sin docente asignado' : $s['docente_nombre'];
        $filas   = [
            ['Sección', $s['etiqueta']],
            ['Docente titular', $docente],
            ['Período', $s['periodo_nombre']],
            ['Aula', $s['aula'] ?: '—'],
            [],
        ];

        if ($r['consolidado']) {
            $filas[] = array_merge(['N°', 'Cédula escolar', 'Apellidos', 'Nombres'], array_column($r['momentos'], 'nombre'));
            foreach ($r['estudiantes'] as $i => $e) {
                $fila = [$i + 1, $e['cedula_escolar'], $e['apellidos'], $e['nombres']];
                foreach ($r['momentos'] as $m) {
                    $fila[] = $e['notas'][$m['id']] ?? 'Sin calificar';
                }
                $filas[] = $fila;
            }
            $sufijo = 'consolidado';
        } else {
            array_splice($filas, 3, 0, [['Momento', $r['momento']['nombre']]]);
            $filas[] = ['N°', 'Cédula escolar', 'Apellidos', 'Nombres', 'Género', 'Edad', 'Estado', 'Descripción del desempeño'];
            foreach ($r['estudiantes'] as $i => $e) {
                $filas[] = [
                    $i + 1, $e['cedula_escolar'], $e['apellidos'], $e['nombres'], $e['genero'],
                    $e['edad'] ?? '', $e['estado'] ?? 'Sin calificar', $e['descripcion'] ?? '',
                ];
            }
            $sufijo = 'momento_' . $r['momento']['id'];
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="calificaciones_seccion_' . (int)$s['id'] . '_' . $sufijo . '.csv"');

        $salida = fopen('php://output', 'w');
        fwrite($salida, "\xEF\xBB\xBF");
        foreach ($filas as $fila) {
            fputcsv($salida, array_map([$this, 'celdaSegura'], $fila), ';', '"', '');
        }
        fclose($salida);
        exit;
    }

    public function registros(): void
    {
        try {
            $seccionId = (int)($_GET['seccion'] ?? 0);
            if ($seccionId <= 0 || !$this->modelSeccion->obtenerPorId($seccionId)) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }
            $filas = array_map(static fn(array $r): array => [
                'momento'        => $r['momento'],
                'cedula_escolar' => $r['cedula_escolar'],
                'estudiante'     => $r['apellidos'] . ', ' . $r['nombres'],
                'estado'         => $r['estado'],
                'descripcion'    => (string)$r['descripcion'],
                'actualizado'    => (string)$r['actualizado'],
            ], $this->model->registrosGuardados($seccionId));
            $this->ok('OK', ['filas' => $filas]);
        } catch (Throwable $e) {
            error_log('[calificacion.registros] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron cargar las calificaciones guardadas.', 500);
        }
    }

    public function planilla(): void
    {
        try {
            $seccionId = (int)($_GET['seccion'] ?? 0);
            $momentoId = (int)($_GET['momento'] ?? 0);

            $seccion = $seccionId > 0 ? $this->modelSeccion->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }

            $momentos    = $this->model->momentosPorPeriodo($seccion['periodo_id']);
            $momento     = null;
            $estudiantes = [];

            if ($momentoId > 0) {
                $momento = $this->model->momento($momentoId);
                if (!$momento || $momento['periodo_id'] !== $seccion['periodo_id']) {
                    $this->error('Momento inválido', 'El momento académico no pertenece al período de la sección.', 422);
                }
                $estudiantes = $this->model->porSeccionMomento($seccionId, $momentoId);
            }

            [$editable, $motivo] = $this->evaluarEdicion($seccion, $momento);

            $this->ok('OK', [
                'seccion'       => $seccion,
                'momentos'      => $momentos,
                'momento'       => $momento,
                'estudiantes'   => $estudiantes,
                'resumen'       => $this->resumir($estudiantes),
                'editable'      => $editable,
                'motivoBloqueo' => $motivo,
            ]);
        } catch (Throwable $e) {
            error_log('[calificacion.planilla] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar la planilla de calificaciones.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $seccionId = (int)($_POST['seccion_id'] ?? 0);
        $momentoId = (int)($_POST['momento_id'] ?? 0);
        $notas     = $_POST['calificaciones'] ?? [];

        try {
            $seccion = $seccionId > 0 ? $this->modelSeccion->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }

            $momento = $momentoId > 0 ? $this->model->momento($momentoId) : null;
            if (!$momento || $momento['periodo_id'] !== $seccion['periodo_id']) {
                $this->error('Momento inválido', 'El momento académico no pertenece al período de la sección.', 422);
            }

            [$editable, $motivo] = $this->evaluarEdicion($seccion, $momento);
            if (!$editable) {
                $this->error('Planilla bloqueada', $motivo, 409);
            }

            if (!is_array($notas) || !$notas) {
                $this->error('Datos incompletos', 'No se enviaron calificaciones para guardar.', 422);
            }

            $idsValidos = array_flip($this->model->idsEstudiantesDeSeccion($seccionId));
            $filas      = [];
            $errores    = [];

            foreach ($notas as $estudianteId => $dato) {
                $estudianteId = (int)$estudianteId;
                $clave        = 'est_' . $estudianteId;

                if (!isset($idsValidos[$estudianteId])) {
                    $errores[$clave] = 'El estudiante no pertenece a esta sección.';
                    continue;
                }
                if (!is_array($dato)) {
                    $errores[$clave] = 'Datos de calificación no válidos.';
                    continue;
                }

                $estado      = trim((string)($dato['estado'] ?? ''));
                $descripcion = preg_replace('/\s+/u', ' ', trim((string)($dato['descripcion'] ?? '')));

                if ($estado === '') {
                    if ($descripcion !== '') {
                        $errores[$clave] = 'Seleccione el estado para guardar la descripción.';
                    }
                    continue;
                }
                if (!in_array($estado, Calificacion::ESTADOS, true)) {
                    $errores[$clave] = 'Estado no válido.';
                    continue;
                }
                if (mb_strlen($descripcion) > self::MAX_DESCRIPCION) {
                    $errores[$clave] = 'La descripción no puede superar ' . self::MAX_DESCRIPCION . ' caracteres.';
                    continue;
                }

                $filas[] = [$estudianteId, $estado, $descripcion];
            }

            if ($errores) {
                $this->error('Revise la planilla', reset($errores), 422, ['errors' => $errores]);
            }
            if (!$filas) {
                $this->error('Sin calificaciones', 'Seleccione el estado de al menos un estudiante para guardar.', 422);
            }

            $antes = [];
            foreach ($this->model->porSeccionMomento($seccionId, $momentoId) as $previo) {
                $antes[$previo['id']] = $previo;
            }

            $guardadas = $this->model->guardarLote($momentoId, $filas);

            $this->auditarCambios($filas, $antes, $seccion, $momento, $guardadas);
            $this->ok("Se guardaron {$guardadas} calificaciones correctamente.", ['guardadas' => $guardadas]);
        } catch (Throwable $e) {
            error_log('[calificacion.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron guardar las calificaciones.', 500);
        }
    }

    public function crearMomentos(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_MOMENTOS);

        $seccionId = (int)($_POST['seccion_id'] ?? 0);

        try {
            $seccion = $seccionId > 0 ? $this->modelSeccion->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección seleccionada no existe.', 404);
            }
            if ($seccion['periodo_estado'] !== 'activo') {
                $this->error('Período cerrado', 'No se pueden crear momentos en un período cerrado.', 409);
            }

            $creados = $this->model->crearMomentosPorDefecto($seccion['periodo_id']);
            if ($creados === 0) {
                $this->error('Ya existen', 'El período ya tiene momentos académicos configurados.', 409);
            }

            $this->auditar('CREAR', 'Calificaciones', "Creó los {$creados} momentos académicos del período {$seccion['periodo_nombre']} (#{$seccion['periodo_id']}).");
            $this->ok("Se crearon los {$creados} momentos académicos del período {$seccion['periodo_nombre']}.", ['creados' => $creados]);
        } catch (Throwable $e) {
            error_log('[calificacion.crearMomentos] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudieron crear los momentos académicos.', 500);
        }
    }

    // Los detalles se insertan primero para que el resumen quede arriba en el historial
    private function auditarCambios(array $filas, array $antes, array $seccion, array $momento, int $guardadas): void
    {
        $limpiar = static fn($texto): string => preg_replace('/\s+/u', ' ', trim((string)$texto));
        $nuevas = 0;
        $sinCambios = 0;
        $cambios = [];

        foreach ($filas as [$estudianteId, $estado, $descripcion]) {
            $previo = $antes[$estudianteId] ?? null;
            if (!$previo || $previo['estado'] === null) {
                $nuevas++;
                continue;
            }

            $cambioEstado = $previo['estado'] !== $estado;
            $cambioDesc   = $limpiar($previo['descripcion']) !== $descripcion;
            if (!$cambioEstado && !$cambioDesc) {
                $sinCambios++;
                continue;
            }
            $cambios[] = [$previo, $estado, $descripcion, $cambioEstado, $cambioDesc];
        }

        $contexto = "{$seccion['etiqueta']} · {$momento['nombre']}";
        foreach (array_slice($cambios, 0, 100) as [$previo, $estado, $descripcion, $cambioEstado, $cambioDesc]) {
            $detalle = $cambioEstado ? "{$previo['estado']} → {$estado}" : "estado sin cambio ({$estado})";
            if ($cambioDesc) {
                $detalle .= '; descripción: "' . mb_substr($limpiar($previo['descripcion']), 0, 120) . '" → "' . mb_substr($descripcion, 0, 120) . '"';
            }
            $this->auditar(
                'MODIFICAR',
                'Calificaciones',
                "Modificó la calificación de {$previo['apellidos']}, {$previo['nombres']} (C.E. {$previo['cedula_escolar']}) en {$contexto}: {$detalle}."
            );
        }
        if (count($cambios) > 100) {
            $this->auditar('MODIFICAR', 'Calificaciones', 'Otras ' . (count($cambios) - 100) . " modificaciones en {$contexto} (detalle no listado).");
        }

        $this->auditar(
            'GUARDAR',
            'Calificaciones',
            "Cargó {$guardadas} calificación(es) de {$contexto} (sección #{$seccion['id']}, momento #{$momento['id']}): "
            . "{$nuevas} nueva(s), " . count($cambios) . " modificada(s), {$sinCambios} sin cambios."
        );
    }

    private function puedeEscribir(): bool
    {
        return in_array($this->rolActual(), self::ROLES_ESCRITURA, true);
    }

    private function evaluarEdicion(array $seccion, ?array $momento): array
    {
        if (!$this->puedeEscribir()) {
            return [false, 'Tu rol tiene acceso de solo lectura.'];
        }
        if ($seccion['periodo_estado'] !== 'activo') {
            return [false, 'El período académico de esta sección está cerrado: las calificaciones son de solo lectura.'];
        }
        if ($momento === null) {
            return [false, 'Seleccione un momento académico.'];
        }
        if ($momento['estado'] !== 'activo') {
            return [false, "El {$momento['nombre']} está cerrado: las calificaciones son de solo lectura."];
        }

        return [true, null];
    }

    private function resumir(array $estudiantes): array
    {
        $r = ['total' => count($estudiantes), 'aprobados' => 0, 'reprobados' => 0, 'sin_calificar' => 0];
        foreach ($estudiantes as $e) {
            match ($e['estado'] ?? null) {
                'Aprobado'  => $r['aprobados']++,
                'Reprobado' => $r['reprobados']++,
                default     => $r['sin_calificar']++,
            };
        }

        return $r;
    }

    // Valida sección y momento; ante un error responde con una página simple en lugar de JSON porque se abre en otra pestaña
    private function datosReporte(): array
    {
        try {
            $seccionId = (int)($_GET['seccion'] ?? 0);
            $momentoId = (int)($_GET['momento'] ?? 0);

            $seccion = $seccionId > 0 ? $this->modelSeccion->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->paginaError('La sección seleccionada no existe.', 404);
            }

            if ($momentoId > 0) {
                $momento = $this->model->momento($momentoId);
                if (!$momento || $momento['periodo_id'] !== $seccion['periodo_id']) {
                    $this->paginaError('El momento académico no pertenece al período de la sección.', 422);
                }
                $estudiantes = $this->model->porSeccionMomento($seccionId, $momentoId);

                return [
                    'consolidado' => false,
                    'seccion'     => $seccion,
                    'momento'     => $momento,
                    'estudiantes' => $estudiantes,
                    'resumen'     => $this->resumir($estudiantes),
                ];
            }

            $consolidado = $this->model->consolidadoSeccion($seccionId, $seccion['periodo_id']);

            $resumen = [];
            foreach ($consolidado['momentos'] as $m) {
                $resumen[$m['id']] = ['aprobados' => 0, 'reprobados' => 0, 'sin_calificar' => 0];
                foreach ($consolidado['estudiantes'] as $e) {
                    $estado = $e['notas'][$m['id']] ?? null;
                    $clave  = $estado === 'Aprobado' ? 'aprobados' : ($estado === 'Reprobado' ? 'reprobados' : 'sin_calificar');
                    $resumen[$m['id']][$clave]++;
                }
            }

            return [
                'consolidado' => true,
                'seccion'     => $seccion,
                'momentos'    => $consolidado['momentos'],
                'estudiantes' => $consolidado['estudiantes'],
                'resumen'     => $resumen,
            ];
        } catch (Throwable $e) {
            error_log('[calificacion.reporte] ' . $e->getMessage());
            $this->paginaError('No se pudo generar el reporte.', 500);
        }
    }

    // Evita "inyección de fórmulas" en Excel: celdas de texto que empiecen por = + - @ se escapan
    private function celdaSegura($valor): string
    {
        $texto = (string)$valor;

        return ($texto !== '' && strpbrk($texto[0], "=+-@\t\r") !== false && !is_numeric($texto)) ? "'" . $texto : $texto;
    }
}
