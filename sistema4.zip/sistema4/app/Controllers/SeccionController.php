<?php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Seccion.php';
require_once __DIR__ . '/../Models/Estudiante.php';

class SeccionController extends BaseController
{
    private const ROLES_GESTION = ['admin', 'director'];

    private Seccion $model;
    private Estudiante $modelEstudiante;

    public function __construct()
    {
        parent::__construct();
        $this->model           = new Seccion($this->pdo);
        $this->modelEstudiante = new Estudiante($this->pdo);
    }

    public function index(): void
    {
        $periodos  = $this->model->obtenerPeriodos();
        $periodoId = isset($_GET['periodo']) ? (int)$_GET['periodo'] : 0;

        if ($periodoId === 0) {
            foreach ($periodos as $p) {
                if ($p['estado'] === 'activo') {
                    $periodoId = (int)$p['id'];
                    break;
                }
            }
        }

        $this->vista('seccion/index', [
            'periodos'         => $periodos,
            'docentes'         => $this->model->obtenerDocentes(),
            'periodoInicial'   => $periodoId,
            'puedeGestionar'   => $this->puedeGestionar(),
            'nombreUsuario'    => $this->nombreUsuario(),
            'rolVisual'        => ucfirst($this->rolActual()),
            'panel'            => $this->panelDelRol(),
            'csrfToken'        => $this->tokenCsrf(),
        ]);
    }

    public function listar(): void
    {
        try {
            $periodoId = (int)($_GET['periodo'] ?? 0);

            $this->ok('OK', [
                'secciones' => $this->model->obtenerTodos($periodoId > 0 ? $periodoId : null),
            ]);
        } catch (Throwable $e) {
            error_log('[seccion.listar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar el listado de secciones.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        $id = (int)($_POST['id'] ?? 0);

        try {
            $actual = null;
            if ($id > 0) {
                $actual = $this->model->obtenerPorId($id);
                if (!$actual) {
                    $this->error('No encontrada', 'La sección que intenta editar no existe.', 404);
                }
                if ($actual['periodo_estado'] !== 'activo') {
                    $this->error('Período cerrado', 'No se pueden editar secciones de un período cerrado.', 409);
                }
            }

            $d = [
                'periodo_id' => $actual ? $actual['periodo_id'] : (int)($_POST['periodo_id'] ?? 0),
                'grado'      => (int)($_POST['grado'] ?? 0),
                'seccion'    => strtoupper(trim((string)($_POST['seccion'] ?? ''))),
                'docente_id' => (int)($_POST['docente_id'] ?? 0) ?: null,
                'aula'       => trim((string)($_POST['aula'] ?? '')),
                'horario'    => trim((string)($_POST['horario'] ?? '')),
            ];

            $errores = [];

            $periodo = $this->model->obtenerPeriodo($d['periodo_id']);
            if (!$periodo) {
                $errores['periodo_id'] = 'Seleccione un período válido.';
            } elseif ($periodo['estado'] !== 'activo') {
                $errores['periodo_id'] = 'No se pueden crear secciones en un período cerrado.';
            }

            if ($d['grado'] < 1 || $d['grado'] > 6) {
                $errores['grado'] = 'El grado debe estar entre 1 y 6.';
            }
            if (!in_array($d['seccion'], ['A', 'B'], true)) {
                $errores['seccion'] = 'La sección debe ser A o B.';
            }
            if ($d['docente_id'] !== null && !$this->model->existeDocente($d['docente_id'])) {
                $errores['docente_id'] = 'El docente seleccionado no existe.';
            }
            if (mb_strlen($d['aula']) > 30) {
                $errores['aula'] = 'El aula no puede superar 30 caracteres.';
            }
            if (mb_strlen($d['horario']) > 100) {
                $errores['horario'] = 'El horario no puede superar 100 caracteres.';
            }
            if (!$errores && $this->model->existeCombinacion($d['periodo_id'], $d['grado'], $d['seccion'], $id)) {
                $errores['seccion'] = 'Ya existe esa sección en el período.';
            }

            if ($errores) {
                $this->error('Revise el formulario', reset($errores), 422, ['errors' => $errores]);
            }

            $sid = $this->model->guardar($id, $d);
            $this->auditar(
                $id ? 'EDITAR' : 'CREAR',
                'Secciones',
                ($id ? 'Editó' : 'Creó') . " la sección #{$sid} ({$d['grado']}° {$d['seccion']}, período {$periodo['nombre']})."
            );
            $this->ok('La sección se guardó correctamente.', ['id' => $sid]);
        } catch (Throwable $e) {
            $this->responderErrorBd($e, 'seccion.guardar', 'No se pudo guardar la sección.');
        }
    }

    public function asignarDocente(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        $seccionId = (int)($_POST['seccion_id'] ?? 0);
        $docenteId = (int)($_POST['docente_id'] ?? 0) ?: null;

        try {
            $seccion = $seccionId > 0 ? $this->model->obtenerPorId($seccionId) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección no existe.', 404);
            }
            if ($seccion['periodo_estado'] !== 'activo') {
                $this->error('Período cerrado', 'No se puede cambiar el docente de una sección de un período cerrado.', 409);
            }
            if ($docenteId !== null && !$this->model->existeDocente($docenteId)) {
                $this->error('Docente inválido', 'El docente seleccionado no existe.', 422);
            }

            $this->model->asignarDocente($seccionId, $docenteId);

            $this->auditar(
                'EDITAR',
                'Secciones',
                $docenteId === null
                    ? "Retiró el docente titular de {$seccion['etiqueta']} (#{$seccionId})."
                    : "Asignó el docente #{$docenteId} como titular de {$seccion['etiqueta']} (#{$seccionId})."
            );
            $this->ok($docenteId === null ? 'Se retiró el docente de la sección.' : 'Docente asignado correctamente.');
        } catch (Throwable $e) {
            $this->responderErrorBd($e, 'seccion.asignarDocente', 'No se pudo actualizar el docente de la sección.');
        }
    }

    public function eliminar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        $id = (int)($_POST['id'] ?? 0);

        try {
            $seccion = $id > 0 ? $this->model->obtenerPorId($id) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección no existe.', 404);
            }
            if ($seccion['total_estudiantes'] > 0) {
                $this->error('No se puede eliminar', 'La sección tiene estudiantes. Quítelos o reasígnelos primero.', 409);
            }
            if ($this->model->contarAsistencias($id) > 0) {
                $this->error('No se puede eliminar', 'La sección tiene asistencias registradas y se perderían. Conserve la sección.', 409);
            }

            if (!$this->model->eliminar($id)) {
                $this->error('Error', 'No se pudo eliminar la sección.', 500);
            }

            $this->auditar('ELIMINAR', 'Secciones', "Eliminó la sección #{$id} ({$seccion['etiqueta']}).");
            $this->ok('Sección eliminada correctamente.');
        } catch (Throwable $e) {
            $this->responderErrorBd($e, 'seccion.eliminar', 'No se pudo eliminar la sección (tiene registros asociados).');
        }
    }

    public function estudiantes(): void
    {
        $id = (int)($_GET['id'] ?? 0);

        try {
            $seccion = $id > 0 ? $this->model->obtenerPorId($id) : null;
            if (!$seccion) {
                $this->error('No encontrada', 'La sección no existe.', 404);
            }

            $puedeAsignar = $this->puedeGestionar() && $seccion['periodo_estado'] === 'activo';

            $this->ok('OK', [
                'seccion'      => $seccion,
                'estudiantes'  => $this->modelEstudiante->porSeccion($id),
                'disponibles'  => $puedeAsignar ? $this->modelEstudiante->sinSeccion() : [],
                'puedeAsignar' => $puedeAsignar,
            ]);
        } catch (Throwable $e) {
            error_log('[seccion.estudiantes] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar la lista de estudiantes.', 500);
        }
    }

    public function asignar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        $seccionId    = (int)($_POST['seccion_id'] ?? 0);
        $estudianteId = (int)($_POST['estudiante_id'] ?? 0);

        try {
            $seccion = $seccionId > 0 ? $this->model->obtenerPorId($seccionId) : null;
            if (!$seccion || $estudianteId <= 0) {
                $this->error('Datos no válidos', 'La sección o el estudiante no son válidos.', 422);
            }
            if ($seccion['periodo_estado'] !== 'activo') {
                $this->error('Período cerrado', 'No se pueden asignar estudiantes a un período cerrado.', 409);
            }

            $estudiante = $this->modelEstudiante->obtenerPorId($estudianteId);
            if (!$estudiante) {
                $this->error('No encontrado', 'El estudiante no existe.', 404);
            }
            if (!empty($estudiante['seccion_id'])) {
                $this->error('Ya asignado', 'El estudiante ya pertenece a una sección. Retírelo de ella primero.', 409);
            }

            $this->modelEstudiante->asignarSeccion($estudianteId, $seccionId);

            $this->auditar(
                'ASIGNAR',
                'Secciones',
                "Asignó al estudiante {$estudiante['nombres']} {$estudiante['apellidos']} (#{$estudianteId}) a {$seccion['etiqueta']}."
            );
            $this->ok('Estudiante asignado a la sección.');
        } catch (Throwable $e) {
            error_log('[seccion.asignar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo asignar al estudiante.', 500);
        }
    }

    public function quitar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_GESTION);

        $seccionId    = (int)($_POST['seccion_id'] ?? 0);
        $estudianteId = (int)($_POST['estudiante_id'] ?? 0);

        try {
            $seccion    = $seccionId > 0 ? $this->model->obtenerPorId($seccionId) : null;
            $estudiante = $estudianteId > 0 ? $this->modelEstudiante->obtenerPorId($estudianteId) : null;

            if (!$seccion || !$estudiante || (int)$estudiante['seccion_id'] !== $seccionId) {
                $this->error('Datos no válidos', 'El estudiante no pertenece a esa sección.', 422);
            }
            if ($seccion['periodo_estado'] !== 'activo') {
                $this->error('Período cerrado', 'No se pueden retirar estudiantes de un período cerrado.', 409);
            }

            $this->modelEstudiante->quitarSeccion($estudianteId);

            $this->auditar(
                'QUITAR',
                'Secciones',
                "Retiró al estudiante {$estudiante['nombres']} {$estudiante['apellidos']} (#{$estudianteId}) de {$seccion['etiqueta']}."
            );
            $this->ok('Estudiante retirado de la sección.');
        } catch (Throwable $e) {
            error_log('[seccion.quitar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo retirar al estudiante.', 500);
        }
    }

    private function puedeGestionar(): bool
    {
        return in_array($this->rolActual(), self::ROLES_GESTION, true);
    }

    private function panelDelRol(): string
    {
        $rol = $this->rolActual();
        return in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : 'admin';
    }

    private function responderErrorBd(Throwable $e, string $contexto, string $mensaje)
    {
        error_log("[{$contexto}] " . $e->getMessage());

        if ($e instanceof PDOException && (int)($e->errorInfo[1] ?? 0) === 1048) {
            $this->error(
                'Falta actualizar la base de datos',
                'La columna secciones.docente_id aún no acepta valores vacíos. Ejecute database/migracion_secciones_docente_nullable.sql.',
                500
            );
        }

        $this->error('Error interno', $mensaje, 500);
    }
}
