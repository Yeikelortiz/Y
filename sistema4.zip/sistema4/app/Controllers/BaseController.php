<?php
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Bitacora.php';

abstract class BaseController
{
    protected PDO $pdo;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->pdo = (new Database())->getConnection();
    }

    protected function rolActual(): string
    {
        $rol = strtolower((string)($_SESSION['usuario_rol'] ?? $_SESSION['rol'] ?? ''));
        return $rol === 'administrador' ? 'admin' : $rol;
    }

    protected function usuarioId(): ?int
    {
        $id = $_SESSION['usuario_id'] ?? $_SESSION['id'] ?? null;
        return $id !== null ? (int)$id : null;
    }

    protected function nombreUsuario(): string
    {
        return (string)($_SESSION['nombre'] ?? $_SESSION['usuario_nombre'] ?? 'Usuario');
    }

    protected function exigirRol(array $rolesPermitidos): void
    {
        if (!in_array($this->rolActual(), $rolesPermitidos, true)) {
            $this->error('Acceso denegado', 'No tiene permisos suficientes para realizar esta acción.', 403);
        }
    }

    protected function tokenCsrf(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    
    protected function exigirPost(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            $this->error('Método no permitido', 'La solicitud debe realizarse por POST.', 405);
        }

        $enviado = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
        if (!is_string($enviado) || !hash_equals($this->tokenCsrf(), $enviado)) {
            $this->error('Sesión no válida', 'El token de seguridad expiró. Recargue la página e intente de nuevo.', 419);
        }
    }

    protected function baseUrl(): string
    {
        return rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';
    }

    protected function assetsUrl(): string
    {
        return rtrim(dirname(rtrim($this->baseUrl(), '/')), '/\\') . '/assets/';
    }

    protected function vista(string $vista, array $datos = []): void
    {
        $archivo = __DIR__ . '/../Views/' . $vista . '.php';
        if (!is_file($archivo)) {
            http_response_code(500);
            echo '<h1>500 - Vista no encontrada</h1>';
            exit;
        }

        $baseUrl   = $this->baseUrl();
        $assetsUrl = $this->assetsUrl();
        extract($datos, EXTR_SKIP);
        require $archivo;
    }

    protected function json(array $payload, int $codigo = 200)
    {
        if (ob_get_length()) {
            ob_clean();
        }
        http_response_code($codigo);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    protected function ok(string $mensaje, array $extra = [], int $codigo = 200)
    {
        $this->json(array_merge([
            'status'  => 'success',
            'success' => true,
            'message' => $mensaje,
        ], $extra), $codigo);
    }

    protected function error(string $titulo, string $mensaje, int $codigo = 400, array $extra = [])
    {
        $this->json(array_merge([
            'status'  => 'error',
            'success' => false,
            'title'   => $titulo,
            'message' => $mensaje,
        ], $extra), $codigo);
    }

    protected function paginaError(string $mensaje, int $codigo = 400): void
    {
        http_response_code($codigo);
        $m = htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8');
        $u = htmlspecialchars($this->baseUrl() . 'index.php?controller=' . ($this->rolActual() ?: 'auth') . '&action=index', ENT_QUOTES, 'UTF-8');
        echo '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Aviso</title></head>'
           . '<body style="font-family:sans-serif;max-width:560px;margin:15vh auto;padding:0 16px;color:#1f2937">'
           . '<h2>No se pudo completar la acción</h2><p>' . $m . '</p><p><a href="' . $u . '">Volver al panel</a></p></body></html>';
        exit;
    }

    protected function auditar(string $accion, string $modulo, string $descripcion): void
    {
        try {
            (new Bitacora($this->pdo))->registrar(
                $this->usuarioId(),
                $this->nombreUsuario(),
                $this->rolActual(),
                $accion,
                $modulo,
                $descripcion,
                $_SERVER['REMOTE_ADDR'] ?? null
            );
        } catch (Throwable $e) {
            // La auditoría nunca debe romper la operación principal
            error_log('[auditoria] ' . $e->getMessage());
        }
    }
}
