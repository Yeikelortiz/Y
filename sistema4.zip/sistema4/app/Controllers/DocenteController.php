<?php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Docente.php';

class DocenteController extends BaseController
{
    private const POR_PAGINA      = 10;
    private const ROLES_ESCRITURA = ['admin', 'director'];
    private const ROLES_ELIMINAR  = ['admin', 'director'];

    private Docente $model;

    public function __construct()
    {
        parent::__construct();
        $this->model = new Docente($this->pdo);
    }

    public function index(): void
    {
        $rol = $this->rolActual();

        $this->vista('ListaDocentes/index', [
            'puedeEditar'   => in_array($rol, self::ROLES_ESCRITURA, true),
            'puedeEliminar' => in_array($rol, self::ROLES_ELIMINAR, true),
            'panel'         => in_array($rol, ['admin', 'director', 'secretaria'], true) ? $rol : 'admin',
            'rolVisual'     => ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaría'][$rol] ?? ucfirst($rol),
            'nombreUsuario' => $this->nombreUsuario(),
            'csrfToken'     => $this->tokenCsrf(),
        ]);
    }

    public function listar(): void
    {
        try {
            $busqueda = mb_substr(trim((string)($_GET['busqueda'] ?? '')), 0, 100);
            $total    = $this->model->contar($busqueda);

            $totalPaginas = max(1, (int)ceil($total / self::POR_PAGINA));
            $pagina       = min(max(1, (int)($_GET['pagina'] ?? 1)), $totalPaginas);
            $offset       = ($pagina - 1) * self::POR_PAGINA;

            $this->ok('OK', [
                'docentes'   => $this->model->paginados(self::POR_PAGINA, $offset, $busqueda),
                'paginacion' => [
                    'pagina'       => $pagina,
                    'totalPaginas' => $totalPaginas,
                    'total'        => $total,
                    'porPagina'    => self::POR_PAGINA,
                ],
            ]);
        } catch (Throwable $e) {
            error_log('[docente.listar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo cargar el listado de docentes.', 500);
        }
    }

    public function guardar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ESCRITURA);

        $id = (int)($_POST['id'] ?? 0);
        [$d, $errores] = $this->validar($_POST);

        try {
            if ($id > 0 && !$this->model->obtenerPorId($id)) {
                $this->error('No encontrado', 'El docente que intenta editar no existe.', 404);
            }

            if (!isset($errores['cedula']) && $this->model->existeCampo('cedula', $d['cedula'], $id)) {
                $errores['cedula'] = 'Ya existe un docente con esa cédula.';
            }
            if (!isset($errores['correo']) && $this->model->existeCampo('correo', $d['correo'], $id)) {
                $errores['correo'] = 'Ya existe un docente con ese correo.';
            }

            if ($errores) {
                $this->error('Revise el formulario', reset($errores), 422, ['errors' => $errores]);
            }

            $docenteId = $this->model->guardar($id, $d);

            $this->auditar(
                $id > 0 ? 'EDITAR' : 'CREAR',
                'Docentes',
                ($id > 0 ? 'Editó' : 'Registró') . " al docente #{$docenteId} {$d['nombres']} {$d['apellidos']} (C.I. {$d['cedula']})."
            );
            $this->ok(
                $id > 0 ? 'Los cambios se guardaron correctamente.' : 'El docente se registró correctamente.',
                ['id' => $docenteId]
            );
        } catch (PDOException $e) {
            // 1062 = valor duplicado (otro usuario guardó lo mismo un instante antes)
            if ((int)($e->errorInfo[1] ?? 0) === 1062) {
                $this->error('Dato duplicado', 'Ya existe un docente con esa cédula o correo.', 422);
            }
            error_log('[docente.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el docente.', 500);
        } catch (Throwable $e) {
            error_log('[docente.guardar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo guardar el docente.', 500);
        }
    }

    public function eliminar(): void
    {
        $this->exigirPost();
        $this->exigirRol(self::ROLES_ELIMINAR);

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->error('ID inválido', 'El identificador del docente no es válido.', 422);
        }

        try {
            $docente = $this->model->obtenerPorId($id);
            if (!$docente) {
                $this->error('No encontrado', 'El docente ya no existe.', 404);
            }

            if ($docente['total_secciones'] > 0) {
                $n = $docente['total_secciones'];
                $this->error(
                    'No se puede eliminar',
                    "El docente está asignado a {$n} " . ($n === 1 ? 'sección' : 'secciones') . '. Reasigne o quite el docente de esas secciones primero.',
                    409
                );
            }

            if (!$this->model->eliminar($id)) {
                $this->error('Error', 'No se pudo eliminar el docente.', 500);
            }

            $this->auditar('ELIMINAR', 'Docentes', "Eliminó al docente #{$id} {$docente['nombres']} {$docente['apellidos']} (C.I. {$docente['cedula']}).");
            $this->ok('Docente eliminado correctamente.');
        } catch (Throwable $e) {
            error_log('[docente.eliminar] ' . $e->getMessage());
            $this->error('Error interno', 'No se pudo eliminar el docente.', 500);
        }
    }

    private function validar(array $in): array
    {
        $texto = static fn(string $k): string => preg_replace('/\s+/u', ' ', trim((string)($in[$k] ?? '')));

        $d = [
            'cedula'           => trim((string)($in['cedula'] ?? '')),
            'nombres'          => $texto('nombres'),
            'apellidos'        => $texto('apellidos'),
            'fecha_nacimiento' => trim((string)($in['fecha_nacimiento'] ?? '')),
            'genero'           => trim((string)($in['genero'] ?? '')),
            'correo'           => strtolower(trim((string)($in['correo'] ?? ''))),
            'telefono'         => $texto('telefono'),
            'direccion'        => $texto('direccion'),
        ];
        $e = [];

        if ($d['cedula'] === '') {
            $e['cedula'] = 'La cédula es obligatoria.';
        } elseif (!preg_match('/^\d{5,20}$/', $d['cedula'])) {
            $e['cedula'] = 'La cédula debe tener entre 5 y 20 dígitos (solo números).';
        }

        foreach (['nombres' => 'Los nombres', 'apellidos' => 'Los apellidos'] as $campo => $etiqueta) {
            if ($d[$campo] === '') {
                $e[$campo] = "$etiqueta son obligatorios.";
            } elseif (mb_strlen($d[$campo]) > 100) {
                $e[$campo] = "$etiqueta no pueden superar 100 caracteres.";
            } elseif (!preg_match("/^\p{L}[\p{L}\s'.\-]*$/u", $d[$campo])) {
                $e[$campo] = "$etiqueta solo pueden contener letras y espacios.";
            }
        }

        $fecha = DateTime::createFromFormat('!Y-m-d', $d['fecha_nacimiento']);
        if ($d['fecha_nacimiento'] === '') {
            $e['fecha_nacimiento'] = 'La fecha de nacimiento es obligatoria.';
        } elseif (!$fecha || $fecha->format('Y-m-d') !== $d['fecha_nacimiento']) {
            $e['fecha_nacimiento'] = 'La fecha de nacimiento no es válida.';
        } elseif ($fecha > new DateTime('-18 years')) {
            $e['fecha_nacimiento'] = 'El docente debe ser mayor de edad (18 años o más).';
        } elseif ($fecha < new DateTime('-100 years')) {
            $e['fecha_nacimiento'] = 'La fecha de nacimiento no es razonable.';
        }

        if (!in_array($d['genero'], ['M', 'F', 'Otro'], true)) {
            $e['genero'] = 'Seleccione el género.';
        }

        if ($d['correo'] === '') {
            $e['correo'] = 'El correo es obligatorio.';
        } elseif (mb_strlen($d['correo']) > 150 || !filter_var($d['correo'], FILTER_VALIDATE_EMAIL)) {
            $e['correo'] = 'Ingrese un correo válido (máximo 150 caracteres).';
        }

        if ($d['telefono'] !== '' && !preg_match('/^[0-9+\-\s()]{7,20}$/', $d['telefono'])) {
            $e['telefono'] = 'El teléfono debe tener entre 7 y 20 caracteres (números, +, -, espacios).';
        }

        if (mb_strlen($d['direccion']) > 200) {
            $e['direccion'] = 'La dirección no puede superar 200 caracteres.';
        }

        return [$d, $e];
    }
}
