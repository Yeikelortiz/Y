<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control de Asistencia | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/representantes.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/calificaciones.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/asistencia.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-editar="<?= $puedeEditar ? '1' : '0' ?>"
    data-max-dias="<?= (int)$maxDias ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!$puedeEditar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura: puedes consultar la asistencia ya registrada.</div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Control de Asistencia</h1>
                <p class="page-subtitle">Registro de asistencias e inasistencias por momento académico</p>
            </div>
            <div class="acciones-reporte">
                <a class="boton boton-contorno-secundario" data-volver href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">← Volver</a>
                <a class="boton boton-contorno-secundario" id="lnkReporteAsistencia"
                   href="<?= $e($baseUrl) ?>index.php?controller=reporte&amp;action=index&amp;tipo=asistencias">📊 Reporte de asistencia</a>
            </div>
        </div>

        <section class="tarjeta filtro-card">
            <div class="grid-3">
                <div class="campo-grupo">
                    <label class="campo-etiqueta" for="selectMomento">Momento académico</label>
                    <select id="selectMomento" class="campo">
                        <option value="">Seleccione un momento...</option>
                        <?php foreach ($momentos as $m): ?>
                            <option value="<?= (int)$m['id'] ?>" data-periodo="<?= (int)$m['periodo_id'] ?>">
                                <?= $e($m['nombre']) ?> — <?= $e($m['periodo_nombre']) ?><?= $m['estado'] === 'cerrado' ? ' (cerrado)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo-grupo">
                    <label class="campo-etiqueta" for="selectSeccion">Grado y sección</label>
                    <select id="selectSeccion" class="campo" disabled>
                        <option value="">Seleccione primero el momento...</option>
                        <?php foreach ($secciones as $s): ?>
                            <option value="<?= (int)$s['id'] ?>" data-periodo="<?= (int)$s['periodo_id'] ?>">
                                <?= $e($s['etiqueta']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filtro-accion">
                    <button type="button" class="boton boton-primario" id="btnConsultar" disabled>🔍 Consultar</button>
                </div>
            </div>
            <?php if (!$secciones && $totalSecciones === 0): ?>
                <p class="form-nota estado-lista bloqueada">
                    Todavía no hay secciones registradas, por eso no se puede registrar asistencia.
                    <a href="<?= $e($baseUrl) ?>index.php?controller=seccion&amp;action=index">Cree una sección y agregue estudiantes desde Secciones</a>.
                </p>
            <?php elseif (!$secciones): ?>
                <p class="form-nota estado-lista bloqueada">
                    Hay <?= (int)$totalSecciones ?> sección(es), pero ninguna pertenece a un período activo, por eso no se puede registrar asistencia.
                    Active un período o cree secciones en un período activo desde
                    <a href="<?= $e($baseUrl) ?>index.php?controller=periodo&amp;action=index">Períodos</a> y
                    <a href="<?= $e($baseUrl) ?>index.php?controller=seccion&amp;action=index">Secciones</a>.
                </p>
            <?php elseif (!$momentos): ?>
                <p class="form-nota estado-lista bloqueada">
                    El período activo todavía no tiene momentos académicos. Créelos desde
                    <a href="<?= $e($baseUrl) ?>index.php?controller=periodo&amp;action=index">Períodos</a>.
                </p>
            <?php else: ?>
                <p class="form-nota" id="avisoFiltro">Seleccione el momento académico, el grado y sección, y pulse «Consultar».</p>
            <?php endif; ?>
        </section>

        <form id="formAsistencia" novalidate>
            <input type="hidden" name="seccion_id" id="listaSeccionId" value="">
            <input type="hidden" name="momento_id" id="listaMomentoId" value="">

            <section class="tarjeta" id="panelLista" hidden>
                <div class="tarjeta-cabecera">
                    <strong id="listaTitulo">Asistencia por momento</strong>
                    <?php if ($puedeEditar): ?>
                        <button type="button" class="boton boton-primario boton-sm" id="btnGuardarTodos">💾 Guardar todos</button>
                    <?php endif; ?>
                </div>

                <div class="panel-pad">
                    <div class="info-grid cols-3">
                        <div><span class="info-etiqueta">Grado</span><span id="lisGrado"></span></div>
                        <div><span class="info-etiqueta">Sección</span><span id="lisSeccion"></span></div>
                        <div><span class="info-etiqueta">Docente titular</span><span id="lisDocente"></span></div>
                        <div><span class="info-etiqueta">Período</span><span id="lisPeriodo"></span></div>
                        <div><span class="info-etiqueta">Aula</span><span id="lisAula"></span></div>
                        <div><span class="info-etiqueta">Momento académico</span><span id="lisMomento"></span></div>
                    </div>

                    <p class="estado-lista" id="estadoLista" role="status"></p>

                    <div class="contadores">
                        <span class="insignia-pildora insignia-aprobado">Registrados: <span id="cntRegistrados">0</span></span>
                        <span class="insignia-pildora insignia-aviso">Pendientes: <span id="cntPendientes">0</span></span>
                        <span class="insignia-pildora insignia-primaria">Estudiantes: <span id="cntTotal">0</span></span>
                    </div>
                </div>

                <div class="tabla-responsive">
                    <table id="tablaAsistencia">
                        <thead>
                            <tr>
                                <th>Estudiante</th>
                                <th>Cédula escolar</th>
                                <th>Estado</th>
                                <th>Asistencias <span class="req">*</span></th>
                                <th>Inasistencias <span class="req">*</span></th>
                                <th class="text-right">Acción</th>
                            </tr>
                        </thead>
                        <tbody id="cuerpoLista"></tbody>
                    </table>
                </div>
                <div id="listaVacia" class="estado-tabla" hidden>Esta sección no tiene estudiantes inscritos. <a href="<?= $e($baseUrl) ?>index.php?controller=seccion&amp;action=index">Agregue estudiantes desde Secciones</a>.</div>
            </section>
        </form>

        <section class="tarjeta" id="panelGuardados" hidden
                 data-url="index.php?controller=asistencia&action=registros"
                 data-columnas="<?= $e(json_encode([
                     ['campo' => 'momento', 'titulo' => 'Momento'],
                     ['campo' => 'cedula_escolar', 'titulo' => 'Cédula escolar'],
                     ['campo' => 'estudiante', 'titulo' => 'Estudiante'],
                     ['campo' => 'asistencias', 'titulo' => 'Asistencias'],
                     ['campo' => 'inasistencias', 'titulo' => 'Inasistencias'],
                 ], JSON_UNESCAPED_UNICODE)) ?>">
            <div class="tarjeta-cabecera">
                <strong>Asistencias guardadas</strong>
                <span class="insignia-pildora insignia-primaria">Filas: <span id="cntGuardados">0</span></span>
            </div>
            <div class="panel-pad">
                <input type="search" id="buscarGuardados" class="campo" autocomplete="off"
                       placeholder="Buscar por momento, estudiante o cédula...">
            </div>
            <div class="tabla-responsive tabla-guardados">
                <table>
                    <thead id="cabGuardados"></thead>
                    <tbody id="cuerpoGuardados"></tbody>
                </table>
            </div>
            <div id="vacioGuardados" class="estado-tabla" hidden>No hay registros guardados para esta sección.</div>
        </section>
    </main>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/asistencia.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/registros.js"></script>

<script>

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
