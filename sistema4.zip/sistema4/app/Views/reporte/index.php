<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes Académicos y Estadísticos | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/representantes.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/calificaciones.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/reportes-panel.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-tipo-inicial="<?= $e($tipoInicial) ?>"
    data-seccion-inicial="<?= (int)$seccionInicial ?>"
    data-hoy="<?= $e($hoy) ?>">

    <nav class="barra-nav no-imprimir barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <div class="row-header no-imprimir">
            <div>
                <h1 class="page-title">Reportes Académicos y Estadísticos</h1>
                <p class="page-subtitle">Listados, rendimiento, reprobados y asistencias, con exportación a Excel para el Ministerio de Educación</p>
            </div>
        </div>

        <section class="tarjeta filtro-card no-imprimir">
            <div class="grid-3">
                <div class="campo-grupo">
                    <label class="campo-etiqueta" for="selectTipo">Tipo de reporte</label>
                    <select id="selectTipo" class="campo">
                        <?php foreach ($tipos as $clave => $texto): ?>
                            <option value="<?= $e($clave) ?>" <?= $clave === $tipoInicial ? 'selected' : '' ?>><?= $e($texto) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo-grupo">
                    <label class="campo-etiqueta" for="selectPeriodo">Período</label>
                    <select id="selectPeriodo" class="campo">
                        <?php foreach ($periodos as $p): ?>
                            <option value="<?= (int)$p['id'] ?>" <?= (int)$p['id'] === (int)$periodoInicial ? 'selected' : '' ?>>
                                <?= $e($p['nombre']) ?><?= $p['estado'] === 'activo' ? '' : ' (cerrado)' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo-grupo" data-para="estudiantes reprobados asistencias">
                    <label class="campo-etiqueta" for="selectSeccion">Sección</label>
                    <select id="selectSeccion" class="campo">
                        <option value="0">Todas las secciones</option>
                    </select>
                </div>

                <div class="campo-grupo" data-para="rendimiento reprobados asistencias">
                    <label class="campo-etiqueta" for="selectMomento">Momento académico</label>
                    <select id="selectMomento" class="campo">
                        <option value="0">Todos los momentos</option>
                    </select>
                </div>
            </div>

            <?php if (!$periodos): ?>
                <p class="form-nota">No hay períodos académicos registrados. Cree uno desde el módulo de Períodos.</p>
            <?php endif; ?>

            <div class="acciones-filtro">
                <button type="button" class="boton boton-primario" id="btnGenerar" <?= $periodos ? '' : 'disabled' ?> title="La vista previa se actualiza sola al cambiar los filtros">🔄 Actualizar vista previa</button>
                <a class="boton btn-excel" id="lnkExcel" href="#" <?= $periodos ? '' : 'hidden' ?>>⬇ Exportar a Excel</a>
                <button type="button" class="boton boton-contorno-secundario" id="btnImprimir">🖨 Imprimir / PDF</button>
            </div>
        </section>

        <section class="tarjeta" id="panelReporte" hidden>
            <div class="tarjeta-cabecera">
                <strong id="repTitulo"></strong>
                <span class="insignia-pildora insignia-primaria">Filas: <span id="repTotal">0</span></span>
            </div>

            <div class="panel-pad">
                <ul class="chips-filtros" id="repFiltros"></ul>
                <div class="resumen-grid" id="repResumen"></div>
            </div>

            <div class="panel-pad no-imprimir">
                <input type="search" id="buscarReporte" class="campo" autocomplete="off"
                       placeholder="Buscar en el reporte: nombre, cédula, estado, sección... (filtra al escribir)">
            </div>

            <div class="tabla-responsive">
                <table class="tabla-reporte" id="tablaReporte">
                    <thead id="repEncabezado"></thead>
                    <tbody id="repCuerpo"></tbody>
                </table>
            </div>
            <div id="repVacio" class="estado-tabla" hidden>No hay registros para los filtros seleccionados.</div>
            <ul class="notas-reporte" id="repNotas"></ul>
        </section>

        <p class="estado-tabla no-imprimir" id="repInicial">Elija el tipo de reporte y los filtros: la vista previa aparece sola.</p>
    </main>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/reportes-panel.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
