<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$urlPanel = $e($baseUrl) . 'index.php?controller=' . $e($panel) . '&amp;action=index';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auditoría y Bitácora del Sistema | E.B. Olimpia Barrios</title>

    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/bitacora.css?v=20261028-6">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>" data-base-url="<?= $e($baseUrl) ?>" data-hoy="<?= $e($hoy) ?>">

<nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?> bitacora-navbar">
    <a class="barra-marca" href="<?= $urlPanel ?>">🏫 E.B. Olimpia Barrios</a>
    <div class="barra-menu">
        <span class="barra-usuario"><?= $e($nombreUsuario) ?> <span class="insignia-rol"><?= $e($rolVisual) ?></span></span>
        <a href="<?= $urlPanel ?>" class="boton boton-contorno-claro boton-sm">Panel</a>
        <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
    </div>
</nav>

<main class="contenedor-fluido animate-fade-in bitacora-page">

    <section class="bitacora-encabezado rejilla u-alinea-centro">
        <div class="rj-md-8">
            <h2 class="u-extranegrita u-t-oscuro u-mb-1 u-flex u-alinea-centro">
                <div class="bitacora-title-icon u-redondeado-3 u-p-2 u-me-3 u-sombra-sm u-inline-flex u-alinea-centro u-centrado">
                    <i class="icono icono-fingerprint u-fs-4"></i>
                </div>
                Auditoría y Bitácora del Sistema
            </h2>
            <p class="u-t-suave u-mb-0 u-ms-1">Consulta organizada de accesos, cambios, eliminaciones y otros eventos importantes del sistema.</p>
        </div>
    </section>

    <section class="bitacora-resumen rejilla rejilla-g3 u-mb-4" aria-label="Resumen de actividad">
        <div class="rj-xl-3 rj-md-6">
            <div class="tarjeta u-sin-borde u-sombra-sm u-redondeado-4 u-f-blanco u-borde-i u-borde-exito u-borde-4 u-alto-100">
                <div class="tarjeta-cuerpo u-p-3 u-flex u-alinea-centro u-entre">
                    <div>
                        <span class="u-mayusculas u-negrita u-t-exito u-espaciado-amplio small-etiqueta">Eventos registrados</span>
                        <h3 class="u-negrita u-t-oscuro u-mb-0 u-mt-1" id="resTotal">0</h3>
                    </div>
                    <div class="u-redondeado-3 u-f-exito u-f-op-10 u-p-3 u-t-exito"><i class="icono icono-clipboard-data u-fs-4"></i></div>
                </div>
            </div>
        </div>
        <div class="rj-xl-3 rj-md-6">
            <div class="tarjeta u-sin-borde u-sombra-sm u-redondeado-4 u-f-blanco u-borde-i u-borde-primario u-borde-4 u-alto-100">
                <div class="tarjeta-cuerpo u-p-3 u-flex u-alinea-centro u-entre">
                    <div>
                        <span class="u-mayusculas u-negrita u-t-primario u-espaciado-amplio small-etiqueta">Eventos de hoy</span>
                        <h3 class="u-negrita u-t-oscuro u-mb-0 u-mt-1" id="resHoy">0</h3>
                    </div>
                    <div class="u-redondeado-3 u-f-primario u-f-op-10 u-p-3 u-t-primario"><i class="icono icono-calendar-day u-fs-4"></i></div>
                </div>
            </div>
        </div>
        <div class="rj-xl-3 rj-md-6">
            <div class="tarjeta u-sin-borde u-sombra-sm u-redondeado-4 u-f-blanco u-borde-i u-borde-info u-borde-4 u-alto-100">
                <div class="tarjeta-cuerpo u-p-3 u-flex u-alinea-centro u-entre">
                    <div>
                        <span class="u-mayusculas u-negrita u-t-info u-espaciado-amplio small-etiqueta">Inicios de sesión hoy</span>
                        <h3 class="u-negrita u-t-oscuro u-mb-0 u-mt-1" id="resInicios">0</h3>
                    </div>
                    <div class="u-redondeado-3 u-f-info u-f-op-10 u-p-3 u-t-info"><i class="icono icono-box-arrow-in-right u-fs-4"></i></div>
                </div>
            </div>
        </div>
        <div class="rj-xl-3 rj-md-6">
            <div class="tarjeta u-sin-borde u-sombra-sm u-redondeado-4 u-f-blanco u-borde-i u-borde-peligro u-borde-4 u-alto-100">
                <div class="tarjeta-cuerpo u-p-3 u-flex u-alinea-centro u-entre">
                    <div>
                        <span class="u-mayusculas u-negrita u-t-peligro u-espaciado-amplio small-etiqueta">Eliminaciones</span>
                        <h3 class="u-negrita u-t-oscuro u-mb-0 u-mt-1" id="resEliminaciones">0</h3>
                    </div>
                    <div class="u-redondeado-3 u-f-peligro u-f-op-10 u-p-3 u-t-peligro"><i class="icono icono-trash3 u-fs-4"></i></div>
                </div>
            </div>
        </div>
    </section>

    <section class="tarjeta bitacora-filtros u-mb-4">
        <div class="tarjeta-cuerpo u-p-3 u-p-md-4">

            <div class="u-flex u-envolver u-gap-2 u-mb-3" id="atajos" role="group" aria-label="Consultas rápidas">
                <button type="button" class="boton boton-sm boton-contorno-secundario" data-atajo="todos"><i class="icono icono-list-ul u-me-1"></i>Todos</button>
                <button type="button" class="boton boton-sm boton-contorno-secundario" data-atajo="sesiones" data-modulo="Autenticación"><i class="icono icono-box-arrow-in-right u-me-1"></i>Sesiones</button>
                <button type="button" class="boton boton-sm boton-contorno-secundario" data-atajo="calificaciones" data-modulo="Calificaciones"><i class="icono icono-journal-check u-me-1"></i>Calificaciones</button>
                <button type="button" class="boton boton-sm boton-contorno-secundario" data-atajo="eliminaciones" data-accion="ELIMINAR"><i class="icono icono-trash3 u-me-1"></i>Eliminaciones</button>
                <button type="button" class="boton boton-sm boton-contorno-secundario" data-atajo="cierres" data-accion="CERRAR"><i class="icono icono-lock u-me-1"></i>Cierres de período</button>
            </div>

            <div class="rejilla rejilla-g3">
                <div class="rj-12 rj-lg-4">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="inputBusqueda">Buscar</label>
                    <div class="grupo-input grupo-input-sm u-sombra-sm">
                        <span class="grupo-input-texto u-f-claro u-sin-borde-d u-t-suave"><i class="icono icono-search"></i></span>
                        <input type="search" id="inputBusqueda" class="campo u-sin-borde-i u-f-claro" maxlength="100"
                               placeholder="Descripción o usuario..." autocomplete="off">
                    </div>
                    <small class="u-t-peligro" data-error-for="q"></small>
                </div>
                <div class="rj-6 rj-lg-2">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="selectModulo">Módulo</label>
                    <select id="selectModulo" class="campo campo-sm u-f-claro"><option value="">Todos</option></select>
                </div>
                <div class="rj-6 rj-lg-2">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="selectAccion">Acción</label>
                    <select id="selectAccion" class="campo campo-sm u-f-claro"><option value="">Todas</option></select>
                </div>
                <div class="rj-6 rj-lg-2">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="selectRol">Rol</label>
                    <select id="selectRol" class="campo campo-sm u-f-claro"><option value="">Todos</option></select>
                </div>
                <div class="rj-6 rj-lg-2">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="selectUsuario">Usuario</label>
                    <select id="selectUsuario" class="campo campo-sm u-f-claro"><option value="">Todos</option></select>
                </div>
                <div class="rj-6 rj-lg-2">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="inputDesde">Desde</label>
                    <input type="date" id="inputDesde" class="campo campo-sm u-f-claro" max="<?= $e($hoy) ?>">
                    <small class="u-t-peligro" data-error-for="desde"></small>
                </div>
                <div class="rj-6 rj-lg-2">
                    <label class="campo-etiqueta u-pequeno u-seminegrita u-t-secundario" for="inputHasta">Hasta</label>
                    <input type="date" id="inputHasta" class="campo campo-sm u-f-claro" max="<?= $e($hoy) ?>">
                    <small class="u-t-peligro" data-error-for="hasta"></small>
                </div>
                <div class="rj-12 rj-lg-8 u-flex u-alinea-fin u-lg-fin u-gap-2 u-envolver">
                    <button type="button" class="boton boton-sm boton-claro u-borde" id="btnLimpiar"><i class="icono icono-x-circle u-me-1"></i>Limpiar filtros</button>
                    <a class="boton boton-sm boton-exito" id="lnkExcel" href="#"><i class="icono icono-file-earmark-excel u-me-1"></i>Exportar a Excel</a>
                </div>
            </div>
        </div>
    </section>

    <section class="tarjeta bitacora-historial u-mb-4">
        <div class="tarjeta-cabecera u-py-3 u-px-4 u-flex u-columna u-md-fila u-entre u-alinea-centro u-gap-3">
            <h5 class="u-m-0 u-negrita u-t-oscuro u-flex u-alinea-centro">
                <i class="icono icono-clock-history u-me-2"></i> Historial de Actividad
                <span class="insignia u-ms-2 bitacora-contador" id="contadorFiltrado">0</span>
            </h5>
            <div class="u-flex u-alinea-centro u-gap-2">
                <label class="u-pequeno u-t-suave u-mb-0" for="selectPorPagina">Mostrar</label>
                <select id="selectPorPagina" class="campo campo-sm u-sombra-sm u-f-claro ancho-80">
                    <option value="10">10</option>
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
        </div>

        <div class="tarjeta-cuerpo u-p-0">
            <div class="tabla-responsive">
                <table class="tabla tabla-hover u-valign-medio u-mb-0" id="tablaBitacora">
                    <thead class="u-f-claro u-mayusculas u-negrita u-t-secundario u-espaciado-amplio small-etiqueta">
                        <tr>
                            <th class="u-py-3 u-ps-4 ancho-col-8"># ID</th>
                            <th class="u-py-3 ancho-col-18">Usuario</th>
                            <th class="u-py-3 u-centro ancho-col-12">Rol</th>
                            <th class="u-py-3 ancho-col-15">Acción</th>
                            <th class="u-py-3 ancho-col-15">Módulo</th>
                            <th class="u-py-3 ancho-col-17">Descripción</th>
                            <th class="u-py-3 u-pe-4 u-der ancho-col-15">Fecha y hora</th>
                        </tr>
                    </thead>
                    <tbody id="cuerpoBitacora" class="fila-detalle"></tbody>
                </table>
            </div>
            <div id="estadoTabla" class="u-centro u-t-suave u-py-5" role="status">Cargando bitácora...</div>
        </div>

        <div class="tarjeta-pie u-py-3 u-px-4 u-flex u-columna u-md-fila u-entre u-alinea-centro u-gap-2">
            <span class="u-t-suave u-pequeno" id="infoPaginacion">Mostrando registros</span>
            <nav aria-label="Paginación de la bitácora"><ul class="pag-lista pag-sm u-mb-0 u-sombra-sm" id="paginador"></ul></nav>
        </div>
    </section>
</main>

<div class="modal" id="modalDetalle" tabindex="-1" aria-labelledby="tituloDetalle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content u-sin-borde u-sombra">
            <div class="modal-header">
                <h5 class="modal-title u-negrita" id="tituloDetalle">Detalle del evento</h5>
                <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <dl class="rejilla u-mb-0">
                    <dt class="rj-sm-3 u-t-secundario">Evento</dt><dd class="rj-sm-9" id="detId"></dd>
                    <dt class="rj-sm-3 u-t-secundario">Fecha y hora</dt><dd class="rj-sm-9" id="detFecha"></dd>
                    <dt class="rj-sm-3 u-t-secundario">Usuario</dt><dd class="rj-sm-9" id="detUsuario"></dd>
                    <dt class="rj-sm-3 u-t-secundario">Rol</dt><dd class="rj-sm-9" id="detRol"></dd>
                    <dt class="rj-sm-3 u-t-secundario">Acción</dt><dd class="rj-sm-9" id="detAccion"></dd>
                    <dt class="rj-sm-3 u-t-secundario">Módulo</dt><dd class="rj-sm-9" id="detModulo"></dd>
                    <dt class="rj-sm-3 u-t-secundario">Descripción</dt><dd class="rj-sm-9 descripcion-completa" id="detDescripcion"></dd>
                </dl>
            </div>
            <div class="modal-footer">
                <button type="button" class="boton boton-claro u-borde" data-cerrar-modal="">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
<script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
<script src="<?= $e($assetsUrl) ?>js/bitacora.js"></script>
</body>
</html>