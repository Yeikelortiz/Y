<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calificaciones | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/representantes.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/calificaciones.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-editar="<?= $puedeEditar ? '1' : '0' ?>"
    data-puede-crear-momentos="<?= $puedeCrearMomentos ? '1' : '0' ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!$puedeEditar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura: puedes consultar calificaciones y generar reportes.</div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Evaluaciones y Calificaciones</h1>
                <p class="page-subtitle">Carga de desempeño por momentos académicos</p>
            </div>
        </div>

        <section class="tarjeta filtro-card">
            <div class="grid-3">
                <div class="campo-grupo">
                    <label class="campo-etiqueta" for="selectSeccion">Sección</label>
                    <select id="selectSeccion" class="campo">
                        <option value="">Seleccione una sección...</option>
                        <?php foreach ($secciones as $s): ?>
                            <option value="<?= (int)$s['id'] ?>">
                                <?= $e($s['etiqueta']) ?> — <?= $e($s['periodo_nombre']) ?><?= $s['periodo_estado'] === 'activo' ? '' : ' (cerrado)' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="campo-grupo">
                    <label class="campo-etiqueta" for="selectMomento">Momento académico</label>
                    <select id="selectMomento" class="campo" disabled>
                        <option value="">Seleccione una sección primero</option>
                    </select>
                </div>
                <div class="filtro-accion">
                    <button type="button" class="boton boton-primario" id="btnCargarPlanilla" disabled>📝 Cargar planilla</button>
                </div>
            </div>
            <p class="form-nota" id="avisoFiltro">Seleccione una sección y un momento académico para ver las calificaciones.</p>
            <button type="button" class="boton boton-primario boton-sm" id="btnCrearMomentos" hidden>➕ Crear los 3 momentos del período</button>
        </section>

        <section class="tarjeta" id="panelResumen" hidden>
            <div class="tarjeta-cabecera">
                <strong>Calificaciones guardadas — <span id="resTitulo"></span></strong>
                <div class="acciones-reporte">
                    <a class="boton boton-contorno-secundario boton-sm" id="lnkReporte" target="_blank" rel="noopener">🖨 Reporte del momento</a>
                    <a class="boton boton-contorno-secundario boton-sm" id="lnkConsolidado" target="_blank" rel="noopener">📊 Reporte consolidado</a>
                    <a class="boton boton-contorno-secundario boton-sm" id="lnkCsv">⬇ Descargar CSV</a>
                </div>
            </div>

            <div class="panel-pad">
                <div class="info-grid cols-3">
                    <div><span class="info-etiqueta">Grado</span><span id="resGrado"></span></div>
                    <div><span class="info-etiqueta">Sección</span><span id="resSeccion"></span></div>
                    <div><span class="info-etiqueta">Docente titular</span><span id="resDocente"></span></div>
                    <div><span class="info-etiqueta">Período</span><span id="resPeriodo"></span></div>
                    <div><span class="info-etiqueta">Aula</span><span id="resAula"></span></div>
                    <div><span class="info-etiqueta">Momento</span><span id="resMomento"></span></div>
                </div>

                <div class="contadores">
                    <span class="insignia-pildora insignia-primaria">Estudiantes: <span id="cntTotal">0</span></span>
                    <span class="insignia-pildora insignia-aprobado">Aprobados: <span id="cntAprobados">0</span></span>
                    <span class="insignia-pildora insignia-reprobado">Reprobados: <span id="cntReprobados">0</span></span>
                    <span class="insignia-pildora insignia-muted">Sin calificar: <span id="cntSin">0</span></span>
                </div>
            </div>

            <div class="tabla-responsive">
                <table id="tablaResumen">
                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Cédula Escolar</th>
                            <th>Estudiante</th>
                            <th>Género / Edad</th>
                            <th>Estado</th>
                            <th>Descripción del desempeño</th>
                        </tr>
                    </thead>
                    <tbody id="cuerpoResumen"></tbody>
                </table>
            </div>
            <div id="resVacio" class="estado-tabla" hidden>Esta sección no tiene estudiantes inscritos. <a href="<?= $e($baseUrl) ?>index.php?controller=seccion&amp;action=index">Agregue estudiantes desde Secciones</a>.</div>
        </section>

        <section class="tarjeta" id="panelGuardados" hidden
                 data-url="index.php?controller=calificacion&action=registros"
                 data-columnas="<?= $e(json_encode([
                     ['campo' => 'momento', 'titulo' => 'Momento'],
                     ['campo' => 'cedula_escolar', 'titulo' => 'Cédula escolar'],
                     ['campo' => 'estudiante', 'titulo' => 'Estudiante'],
                     ['campo' => 'estado', 'titulo' => 'Calificación', 'tipo' => 'estado'],
                     ['campo' => 'descripcion', 'titulo' => 'Descripción del desempeño'],
                     ['campo' => 'actualizado', 'titulo' => 'Actualizado', 'tipo' => 'fechahora'],
                 ], JSON_UNESCAPED_UNICODE)) ?>">
            <div class="tarjeta-cabecera">
                <strong>Calificaciones guardadas</strong>
                <span class="insignia-pildora insignia-primaria">Filas: <span id="cntGuardados">0</span></span>
            </div>
            <div class="panel-pad">
                <input type="search" id="buscarGuardados" class="campo" autocomplete="off"
                       placeholder="Buscar por momento, estudiante, cédula, estado o descripción...">
            </div>
            <div class="tabla-responsive tabla-guardados">
                <table>
                    <thead id="cabGuardados"></thead>
                    <tbody id="cuerpoGuardados"></tbody>
                </table>
            </div>
            <div id="vacioGuardados" class="estado-tabla" hidden>No hay registros guardados para esta sección.</div>
        </section>
    </main>

    <?php if ($puedeEditar): ?>
    <select id="plantillaEstado" hidden>
        <option value="">Seleccione...</option>
        <?php foreach ($estados as $est): ?>
            <option value="<?= $e($est) ?>"><?= $e($est) ?></option>
        <?php endforeach; ?>
    </select>

    <div class="modal-backdrop" id="modalPlanilla" role="dialog" aria-modal="true" aria-labelledby="tituloPlanilla">
        <div class="modal-content modal-xl">
            <div class="modal-header">
                <strong id="tituloPlanilla">Planilla de calificaciones</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formPlanilla" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="seccion_id" id="planSeccionId" value="">
                    <input type="hidden" name="momento_id" id="planMomentoId" value="">

                    <div class="info-grid cols-3">
                        <div><span class="info-etiqueta">Sección / Grado</span><span id="planSeccion"></span></div>
                        <div><span class="info-etiqueta">Docente titular</span><span id="planDocente"></span></div>
                        <div><span class="info-etiqueta">Momento</span><span id="planMomento"></span></div>
                    </div>

                    <div class="planilla-herramientas">
                        <label class="campo-etiqueta herramienta-aplicar" for="aplicarTodos">
                            Aplicar a todos:
                            <select id="aplicarTodos" class="campo">
                                <option value="">Elegir estado...</option>
                                <?php foreach ($estados as $est): ?>
                                    <option value="<?= $e($est) ?>"><?= $e($est) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <span class="insignia-pildora insignia-primaria">Calificados: <span id="planCalificados">0</span> / <span id="planTotal">0</span></span>
                    </div>

                    <div class="tabla-responsive">
                        <table id="tablaPlanilla">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Cédula Escolar</th>
                                    <th>Estudiante</th>
                                    <th>Género / Edad</th>
                                    <th class="celda-estado">Estado</th>
                                    <th>Descripción del desempeño</th>
                                </tr>
                            </thead>
                            <tbody id="cuerpoPlanilla"></tbody>
                        </table>
                    </div>
                    <div id="planVacio" class="estado-tabla" hidden>Esta sección no tiene estudiantes inscritos.</div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardarPlanilla">💾 Guardar calificaciones</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/calificacion.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/registros.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
