<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

$s           = $reporte['seccion'];
$consolidado = $reporte['consolidado'];
$titulo      = $consolidado ? 'Reporte consolidado de calificaciones' : 'Reporte de calificaciones — ' . $reporte['momento']['nombre'];
$urlBase     = $baseUrl . 'index.php?controller=calificacion';
$momentoId   = $consolidado ? 0 : (int)$reporte['momento']['id'];

$claseEstado = static fn(?string $est): string => $est === 'Aprobado' ? 'est-aprobado' : ($est === 'Reprobado' ? 'est-reprobado' : 'est-sin');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $e($titulo) ?> | <?= $e($s['etiqueta']) ?></title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/reporte.css">
    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
</head>
<body>

    <div class="barra-acciones no-imprimir">
        <button type="button" class="boton-doc boton-doc-primario" data-imprimir>🖨 Imprimir / Guardar PDF</button>
        <a class="boton-doc" href="<?= $e($urlBase) ?>&amp;action=exportar&amp;seccion=<?= (int)$s['id'] ?>&amp;momento=<?= $momentoId ?>">⬇ Descargar CSV</a>
        <?php if ($consolidado): ?>
            <span class="barra-nota">Vista consolidada de todos los momentos del período.</span>
        <?php else: ?>
            <a class="boton-doc" href="<?= $e($urlBase) ?>&amp;action=reporte&amp;seccion=<?= (int)$s['id'] ?>&amp;momento=0">📊 Ver consolidado</a>
        <?php endif; ?>
    </div>

    <main class="hoja">
        <header class="encabezado">
            <div>
                <p class="institucion">E.B. Olimpia Barrios</p>
                <h1><?= $e($titulo) ?></h1>
            </div>
            <p class="emision">Emitido el <?= $e($emitidoEn) ?><br>por <?= $e($emitidoPor) ?></p>
        </header>

        <section class="datos-seccion">
            <div><span>Grado</span><strong><?= (int)$s['grado'] ?>°</strong></div>
            <div><span>Sección</span><strong><?= $e($s['seccion']) ?></strong></div>
            <div><span>Docente titular</span><strong><?= $s['sin_docente'] ? 'Sin docente asignado' : $e($s['docente_nombre']) ?></strong></div>
            <div><span>Período</span><strong><?= $e($s['periodo_nombre']) ?><?= $s['periodo_estado'] === 'activo' ? '' : ' (cerrado)' ?></strong></div>
            <div><span>Aula</span><strong><?= $e($s['aula'] ?: '—') ?></strong></div>
            <div>
                <span><?= $consolidado ? 'Momentos' : 'Momento' ?></span>
                <strong><?= $consolidado ? count($reporte['momentos']) . ' del período' : $e($reporte['momento']['nombre']) ?></strong>
            </div>
        </section>

        <?php if (!$reporte['estudiantes']): ?>
            <p class="vacio">Esta sección no tiene estudiantes inscritos.</p>
        <?php elseif ($consolidado): ?>

            <table>
                <thead>
                    <tr>
                        <th>N°</th><th>Cédula escolar</th><th>Estudiante</th>
                        <?php foreach ($reporte['momentos'] as $m): ?>
                            <th class="centro"><?= $e($m['nombre']) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reporte['estudiantes'] as $i => $est): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= $e($est['cedula_escolar']) ?></td>
                            <td><?= $e($est['apellidos'] . ', ' . $est['nombres']) ?></td>
                            <?php foreach ($reporte['momentos'] as $m): ?>
                                <?php $nota = $est['notas'][$m['id']] ?? null; ?>
                                <td class="centro <?= $claseEstado($nota) ?>"><?= $e($nota ?? 'Sin calificar') ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <?php foreach (['aprobados' => 'Aprobados', 'reprobados' => 'Reprobados', 'sin_calificar' => 'Sin calificar'] as $clave => $texto): ?>
                        <tr>
                            <td colspan="3" class="derecha"><?= $e($texto) ?></td>
                            <?php foreach ($reporte['momentos'] as $m): ?>
                                <td class="centro"><?= (int)$reporte['resumen'][$m['id']][$clave] ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tfoot>
            </table>

        <?php else: ?>

            <table>
                <thead>
                    <tr>
                        <th>N°</th><th>Cédula escolar</th><th>Estudiante</th><th>Género</th><th>Edad</th>
                        <th class="centro">Estado</th><th>Descripción del desempeño</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reporte['estudiantes'] as $i => $est): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= $e($est['cedula_escolar']) ?></td>
                            <td><?= $e($est['apellidos'] . ', ' . $est['nombres']) ?></td>
                            <td><?= $e($est['genero']) ?></td>
                            <td><?= $est['edad'] !== null ? (int)$est['edad'] : '—' ?></td>
                            <td class="centro <?= $claseEstado($est['estado']) ?>"><?= $e($est['estado'] ?? 'Sin calificar') ?></td>
                            <td><?= $e($est['descripcion'] ?: '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <p class="resumen-final">
                Total: <strong><?= (int)$reporte['resumen']['total'] ?></strong> ·
                Aprobados: <strong><?= (int)$reporte['resumen']['aprobados'] ?></strong> ·
                Reprobados: <strong><?= (int)$reporte['resumen']['reprobados'] ?></strong> ·
                Sin calificar: <strong><?= (int)$reporte['resumen']['sin_calificar'] ?></strong>
            </p>

        <?php endif; ?>

        <footer class="firmas">
            <div><span class="linea"></span>Docente titular</div>
            <div><span class="linea"></span>Director(a)</div>
        </footer>
    </main>

    <script src="<?= $e($assetsUrl) ?>js/reporte.js"></script>
</body>
</html>
