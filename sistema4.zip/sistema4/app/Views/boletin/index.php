<?php
$etiquetasTipo = ['estudio' => 'Constancia de Estudio', 'inscripcion' => 'Constancia de Inscripción', 'boletin' => 'Boletín de Calificaciones'];
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$rolVisual = ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaría'][$panel] ?? ucfirst($panel);
$urlDoc = static fn(string $tipo, int $estudianteId): string =>
    'index.php?controller=boletin&action=generar&tipo=' . rawurlencode($tipo) . '&estudiante=' . $estudianteId;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Constancias y Boletines | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/boletin.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!empty($error)): ?>
            <div class="alert-info-box doc-error" role="alert"><?= $e($error) ?></div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Constancias y Boletines</h1>
                <p class="page-subtitle">Emisión de constancias de estudio e inscripción, boletines, y reportes de asistencias y calificaciones</p>
            </div>
        </div>

        <form class="tarjeta filtro-card doc-filtros" method="get" action="<?= $e($baseUrl) ?>index.php">
            <input type="hidden" name="controller" value="boletin">
            <input type="hidden" name="action" value="index">

            <div class="campo-grupo">
                <label class="campo-etiqueta" for="selPeriodo">Período escolar</label>
                <select id="selPeriodo" name="periodo" class="campo" data-autosubmit>
                    <?php if (!$periodos): ?>
                        <option value="0">No hay períodos registrados</option>
                    <?php endif; ?>
                    <?php foreach ($periodos as $p): ?>
                        <option value="<?= (int)$p['id'] ?>" <?= (int)$p['id'] === $periodoId ? 'selected' : '' ?>>
                            <?= $e($p['nombre']) ?><?= $p['estado'] === 'activo' ? '' : ' (cerrado)' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo-grupo">
                <label class="campo-etiqueta" for="selSeccion">Sección</label>
                <select id="selSeccion" name="seccion" class="campo" data-autosubmit>
                    <option value="0">— Seleccione una sección —</option>
                    <?php foreach ($secciones as $s): ?>
                        <option value="<?= (int)$s['id'] ?>" <?= $seccion && (int)$s['id'] === (int)$seccion['id'] ? 'selected' : '' ?>>
                            <?= $e($s['etiqueta']) ?> (<?= (int)$s['total_estudiantes'] ?> estudiantes)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <noscript><button type="submit" class="boton boton-primario">Ver</button></noscript>
        </form>

        <?php if (!$seccion): ?>
            <div class="alert-info-box">Seleccione un período y una sección para emitir los documentos.</div>
        <?php else: ?>

            <section class="tarjeta panel-pad doc-seccion">
                <h2 class="doc-titulo">Reportes de <?= $e($seccion['etiqueta']) ?></h2>
                <div class="doc-reportes">

                    <form method="get" action="<?= $e($baseUrl) ?>index.php" class="doc-reporte" target="_blank">
                        <input type="hidden" name="controller" value="calificacion">
                        <input type="hidden" name="action" value="reporte">
                        <input type="hidden" name="seccion" value="<?= (int)$seccion['id'] ?>">
                        <label class="campo-etiqueta" for="selMomento">Reporte de calificaciones</label>
                        <select id="selMomento" name="momento" class="campo">
                            <option value="0">Consolidado (todos los momentos)</option>
                            <?php foreach ($momentos as $m): ?>
                                <option value="<?= (int)$m['id'] ?>"><?= $e($m['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="boton boton-primario boton-sm">Ver / Imprimir</button>
                    </form>

                    <div class="doc-reporte">
                        <span class="campo-etiqueta">Reporte de asistencias</span>
                        <p class="form-nota">Resumen de asistencias de la sección con filtro por fechas y exportación.</p>
                        <a class="boton boton-primario boton-sm" target="_blank" rel="noopener"
                           href="<?= $e($baseUrl) ?>index.php?controller=reporte&amp;action=index&amp;tipo=asistencias&amp;seccion=<?= (int)$seccion['id'] ?>">Ver / Imprimir</a>
                    </div>

                </div>
            </section>

            <section class="tarjeta">
                <div class="tarjeta-cabecera"><strong>Documentos por estudiante</strong></div>

                <?php if (!$estudiantes): ?>
                    <p class="vacio">Esta sección no tiene estudiantes inscritos.</p>
                <?php else: ?>
                    <div class="tabla-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Cédula escolar</th>
                                    <th>Estudiante</th>
                                    <th>Documentos</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($estudiantes as $i => $est): ?>
                                    <tr>
                                        <td><?= $i + 1 ?></td>
                                        <td><?= $e($est['cedula_escolar']) ?></td>
                                        <td><?= $e($est['apellidos'] . ', ' . $est['nombres']) ?></td>
                                        <td>
                                            <div class="doc-acciones">
                                                <?php foreach ($tipos as $clave): ?>
                                                    <a class="boton boton-contorno-secundario boton-sm" target="_blank" rel="noopener"
                                                       href="<?= $e($baseUrl . $urlDoc($clave, (int)$est['id'])) ?>"><?= $e($etiquetasTipo[$clave]) ?></a>
                                                <?php endforeach; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>

        <?php endif; ?>
    </main>

    <script src="<?= $e($assetsUrl) ?>js/boletin.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
