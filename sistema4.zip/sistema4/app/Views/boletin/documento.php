<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

$titulos = [
    'estudio'     => 'Constancia de Estudio',
    'inscripcion' => 'Constancia de Inscripción',
    'boletin'     => 'Boletín de Calificaciones',
];
$titulo = $titulos[$tipo];

$meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
$fechaLarga = static function (string $fecha) use ($meses): string {
    $ts = ($fecha === '' || strpos($fecha, '0000-00-00') === 0) ? false : strtotime($fecha);
    return $ts ? (int)date('j', $ts) . ' de ' . $meses[(int)date('n', $ts) - 1] . ' de ' . date('Y', $ts) : '—';
};

$concordancia   = ['M' => ['el estudiante', 'nacido', 'inscrito'], 'F' => ['la estudiante', 'nacida', 'inscrita']]
                  [$est['genero']] ?? ['el/la estudiante', 'nacido(a)', 'inscrito(a)'];
[$articulo, $nacido, $inscrito] = $concordancia;

$nombreCompleto  = mb_strtoupper(trim($est['nombres'] . ' ' . $est['apellidos']), 'UTF-8');
$fechaNacimiento = $fechaLarga((string)$est['fecha_nacimiento']);
$fechaIngreso    = $fechaLarga((string)$est['registrado_en']);
$periodoCerrado  = $est['periodo_estado'] !== 'activo';
$representante   = $est['rep_nombre'] !== null ? trim($est['rep_nombre'] . ' ' . $est['rep_apellido']) : '';

$ahora       = time();
$diaEmision  = (int)date('j', $ahora);
$mesEmision  = $meses[(int)date('n', $ahora) - 1];
$anioEmision = date('Y', $ahora);
$emitidoEn   = date('d/m/Y H:i', $ahora);

$claseEstado = static fn(?string $est): string => $est === 'Aprobado' ? 'est-aprobado' : ($est === 'Reprobado' ? 'est-reprobado' : 'est-sin');
$grado       = (int)$est['grado'] . '.° grado, sección ' . $est['seccion'];
$verbo       = $periodoCerrado ? 'cursó' : 'cursa';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $e($titulo) ?> | <?= $e($nombreCompleto) ?></title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/reporte.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/boletin.css">
    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
</head>
<body data-auto-imprimir="<?= $autoImprimir ? '1' : '0' ?>">

    <div class="barra-acciones no-imprimir">
        <button type="button" class="boton-doc boton-doc-primario" data-imprimir>🖨 Imprimir / Guardar PDF</button>
        <a class="boton-doc" href="<?= $e($baseUrl) ?>index.php?controller=boletin&amp;action=index&amp;periodo=<?= (int)$est['periodo_id'] ?>&amp;seccion=<?= (int)$est['seccion_id'] ?>">← Volver a documentos</a>
    </div>

    <main class="hoja">
        <header class="encabezado">
            <div>
                <p class="institucion">E.B. Olimpia Barrios</p>
                <h1><?= $e($titulo) ?></h1>
            </div>
            <p class="emision">Emitido el <?= $e($emitidoEn) ?><br>por <?= $e($emitidoPor) ?></p>
        </header>

        <?php if ($tipo === 'estudio'): ?>

            <p class="constancia-texto">
                Quien suscribe, Director(a) de la E.B. Olimpia Barrios, hace constar por medio de la presente que
                <?= $e($articulo) ?> <strong><?= $e($nombreCompleto) ?></strong>, portador(a) de la cédula escolar
                N.° <strong><?= $e($est['cedula_escolar']) ?></strong>, <?= $e($nacido) ?> el <?= $e($fechaNacimiento) ?>,
                <?= $e($verbo) ?> el <strong><?= $e($grado) ?></strong> en este plantel, durante el período escolar
                <strong><?= $e($est['periodo_nombre']) ?></strong>.
            </p>
            <p class="constancia-texto">
                Constancia que se expide a petición de la parte interesada, a los <?= (int)$diaEmision ?> días del mes de
                <?= $e($mesEmision) ?> de <?= $e($anioEmision) ?>.
            </p>

        <?php elseif ($tipo === 'inscripcion'): ?>

            <p class="constancia-texto">
                Quien suscribe, Director(a) de la E.B. Olimpia Barrios, hace constar por medio de la presente que
                <?= $e($articulo) ?> <strong><?= $e($nombreCompleto) ?></strong>, portador(a) de la cédula escolar
                N.° <strong><?= $e($est['cedula_escolar']) ?></strong>, <?= $e($nacido) ?> el <?= $e($fechaNacimiento) ?>,
                <?= $periodoCerrado ? 'estuvo' : 'se encuentra' ?> formalmente <?= $e($inscrito) ?> en este plantel
                (ingreso registrado el <?= $e($fechaIngreso) ?>), en el <strong><?= $e($grado) ?></strong>,
                período escolar <strong><?= $e($est['periodo_nombre']) ?></strong><?php if ($representante !== ''): ?>,
                bajo la representación de <strong><?= $e($representante) ?></strong>,
                titular de la cédula de identidad N.° <strong><?= $e($est['representante_cedula']) ?></strong><?php endif; ?>.
            </p>
            <p class="constancia-texto">
                Constancia que se expide a petición de la parte interesada, a los <?= (int)$diaEmision ?> días del mes de
                <?= $e($mesEmision) ?> de <?= $e($anioEmision) ?>.
            </p>

        <?php else: ?>

            <section class="datos-seccion">
                <div><span>Estudiante</span><strong><?= $e($nombreCompleto) ?></strong></div>
                <div><span>Cédula escolar</span><strong><?= $e($est['cedula_escolar']) ?></strong></div>
                <div><span>Grado y sección</span><strong><?= $e($grado) ?></strong></div>
                <div><span>Período</span><strong><?= $e($est['periodo_nombre']) ?><?= $periodoCerrado ? ' (cerrado)' : '' ?></strong></div>
                <div><span>Docente titular</span><strong><?= $e(trim((string)$est['docente_nombre']) !== '' ? $est['docente_nombre'] : 'Sin docente asignado') ?></strong></div>
                <div><span>Representante</span><strong><?= $e($representante !== '' ? $representante : '—') ?></strong></div>
            </section>

            <?php if (!$filas): ?>
                <p class="vacio">El período no tiene momentos académicos creados.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr><th>Momento</th><th class="centro">Estado</th><th>Descripción del desempeño</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($filas as $f): ?>
                            <tr>
                                <td>
                                    <?= $e($f['momento']) ?>
                                    <?php if ($f['momento_estado'] !== 'cerrado'): ?><br><small>(en curso)</small><?php endif; ?>
                                </td>
                                <td class="centro"><span class="<?= $e($claseEstado($f['estado'])) ?>"><?= $e($f['estado'] ?? 'Sin evaluar') ?></span></td>
                                <td><?= $f['descripcion'] !== null && trim($f['descripcion']) !== '' ? nl2br($e($f['descripcion'])) : '—' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h2 class="subtitulo-doc">Asistencia del período</h2>
            <?php if (!$asistencia || empty($asistencia['momentos'])): ?>
                <p class="vacio">No hay asistencias registradas para este estudiante en el período.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Momento académico</th>
                            <th class="centro">Asistencias</th>
                            <th class="centro">Inasistencias</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($asistencia['momentos'] as $m): ?>
                            <tr>
                                <td><?= $e($m['nombre']) ?></td>
                                <td class="centro"><?= (int)$m['asistencias'] ?></td>
                                <td class="centro"><?= (int)$m['inasistencias'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>Total del período</td>
                            <td class="centro"><?= (int)$asistencia['asistencias'] ?></td>
                            <td class="centro"><?= (int)$asistencia['inasistencias'] ?></td>
                        </tr>
                    </tfoot>
                </table>
                <?php if ($asistencia['porcentaje'] !== null): ?>
                    <p class="nota-doc">% de asistencia del período: <strong><?= $e(number_format((float)$asistencia['porcentaje'], 1, ',', '.')) ?> %</strong> (asistencias / días registrados).</p>
                <?php endif; ?>
            <?php endif; ?>

            <p class="constancia-texto nota-doc">
                Expedido el <?= (int)$diaEmision ?> de <?= $e($mesEmision) ?> de <?= $e($anioEmision) ?>.
            </p>

        <?php endif; ?>

        <footer class="firmas">
            <div><span class="linea"></span>Director(a)</div>
            <div><span class="linea"></span><?= $tipo === 'boletin' ? 'Docente titular' : 'Secretaría' ?></div>
            <div><span class="linea"></span>Sello de la institución</div>
        </footer>
    </main>

    <script src="<?= $e($assetsUrl) ?>js/boletin.js"></script>
</body>
</html>
