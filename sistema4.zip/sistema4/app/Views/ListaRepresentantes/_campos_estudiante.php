<?php
?>
<div class="grid-2">
    <div class="campo-grupo">
        <label class="campo-etiqueta" for="<?= $p ?>est_nombres">Nombres <span class="req">*</span></label>
        <input type="text" class="campo" id="<?= $p ?>est_nombres" name="est_nombres" maxlength="150">
        <small class="campo-error" data-error-for="est_nombres"></small>
    </div>
    <div class="campo-grupo">
        <label class="campo-etiqueta" for="<?= $p ?>est_apellidos">Apellidos <span class="req">*</span></label>
        <input type="text" class="campo" id="<?= $p ?>est_apellidos" name="est_apellidos" maxlength="150">
        <small class="campo-error" data-error-for="est_apellidos"></small>
    </div>
</div>
<div class="grid-3">
    <div class="campo-grupo">
        <label class="campo-etiqueta" for="<?= $p ?>est_fecha_nacimiento">Fecha de nacimiento <span class="req">*</span></label>
        <input type="date" class="campo" id="<?= $p ?>est_fecha_nacimiento" name="est_fecha_nacimiento">
        <small class="campo-error" data-error-for="est_fecha_nacimiento"></small>
    </div>
    <div class="campo-grupo">
        <label class="campo-etiqueta" for="<?= $p ?>est_genero">Género <span class="req">*</span></label>
        <select class="campo" id="<?= $p ?>est_genero" name="est_genero">
            <option value="">Seleccione...</option>
            <option value="M">Masculino</option>
            <option value="F">Femenino</option>
        </select>
        <small class="campo-error" data-error-for="est_genero"></small>
    </div>
    <div class="campo-grupo">
        <label class="campo-etiqueta" for="<?= $p ?>est_seccion_id">Sección / Grado</label>
        <select class="campo" id="<?= $p ?>est_seccion_id" name="est_seccion_id">
            <option value="">Sin asignar</option>
            <?php foreach ($secciones as $s): ?>
                <option value="<?= (int)$s['id'] ?>">
                    <?= $e($s['grado'] . '° Grado - Sección ' . $s['seccion']) ?>
                    (<?= $e($s['periodo']) ?><?= $s['periodo_estado'] === 'activo' ? '' : ' - cerrado' ?>)
                </option>
            <?php endforeach; ?>
        </select>
        <small class="campo-error" data-error-for="est_seccion_id"></small>
    </div>
</div>
