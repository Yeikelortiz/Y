<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Representantes | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/representantes.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body
    class="vista-listado rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-editar="<?= $puedeEditar ? '1' : '0' ?>"
    data-puede-eliminar="<?= $puedeEliminar ? '1' : '0' ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!$puedeEditar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura en este módulo.</div>
        <?php elseif (!$puedeEliminar): ?>
            <div class="alert-info-box">
                <strong>Nota de Secretaría:</strong> puedes registrar y editar representantes y agregar a sus estudiantes.
                La eliminación está reservada al administrador.
            </div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Listado de Representantes</h1>
                <p class="page-subtitle">Directorio general de tutores y los estudiantes que representan</p>
            </div>

            <div class="search-group">
                <input type="search" class="campo" id="inputBusqueda" maxlength="100"
                       placeholder="Buscar por cédula, nombre o teléfono..." autocomplete="off"
                       aria-label="Buscar representantes">
                <button type="button" id="btnLimpiarBusqueda" class="boton boton-contorno-secundario boton-sm" hidden>Limpiar</button>
            </div>

            <?php if ($puedeEditar): ?>
                <button type="button" class="boton boton-primario" id="btnNuevoRepresentante">+ Registrar Representante</button>
            <?php endif; ?>
        </div>

        <section class="tarjeta">
            <div class="tarjeta-cabecera">
                <strong>Representantes Registrados</strong>
                <span class="insignia-pildora insignia-primaria">Total: <span id="contadorTotal">0</span> representantes</span>
            </div>

            <div class="tabla-responsive">
                <table id="tablaRepresentantes">
                    <thead>
                        <tr>
                            <th>Cédula</th>
                            <th>Representante</th>
                            <th>Teléfono</th>
                            <th>Estudiantes</th>
                            <th class="u-der">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTabla"></tbody>
                </table>
            </div>

            <div id="estadoTabla" class="estado-tabla" role="status">Cargando representantes...</div>
            <nav id="paginacion" class="paginacion" aria-label="Paginación" hidden></nav>
        </section>
    </main>

    <div class="modal-backdrop" id="modalDetalle" role="dialog" aria-modal="true" aria-labelledby="tituloDetalle">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloDetalle">Información del Representante</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>
            <div class="modal-body">
                <div class="info-grid">
                    <div><span class="info-etiqueta">Cédula</span><span id="detCedula"></span></div>
                    <div><span class="info-etiqueta">Nombre completo</span><span id="detNombre"></span></div>
                    <div><span class="info-etiqueta">Teléfono</span><span id="detTelefono"></span></div>
                    <div><span class="info-etiqueta">Dirección</span><span id="detDireccion"></span></div>
                </div>

                <div class="seccion-hijos">
                    <div class="seccion-hijos-cabecera">
                        <strong>Estudiantes que representa <span class="insignia-pildora insignia-primaria" id="detTotal">0</span></strong>
                        <?php if ($puedeEditar): ?>
                            <button type="button" class="boton boton-primario boton-sm" id="btnAgregarDesdeDetalle">+ Agregar estudiante</button>
                        <?php endif; ?>
                    </div>

                    <div class="tabla-responsive" id="detTablaWrap">
                        <table class="tabla-hijos">
                            <thead>
                                <tr>
                                    <th>Cédula Escolar</th>
                                    <th>Estudiante</th>
                                    <th>Edad</th>
                                    <th>Sección / Grado</th>
                                </tr>
                            </thead>
                            <tbody id="detEstudiantes"></tbody>
                        </table>
                    </div>

                    <div class="vacio" id="detVacio" hidden>
                        <p>Este representante <strong>no tiene estudiantes registrados</strong>.</p>
                        <?php if ($puedeEditar): ?>
                            <button type="button" class="boton boton-primario boton-sm" id="btnAgregarVacio">+ Agregar estudiante</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="boton boton-contorno-secundario boton-sm" data-cerrar-modal>Cerrar</button>
            </div>
        </div>
    </div>

    <?php if ($puedeEditar): ?>
    <div class="modal-backdrop" id="modalRepresentante" role="dialog" aria-modal="true" aria-labelledby="tituloModalRepresentante">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloModalRepresentante">Registro de Representante</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formRepresentante" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="cedula_original" id="cedulaOriginal" value="">

                    <p class="form-nota">Los campos con <span class="req">*</span> son obligatorios.</p>

                    <fieldset>
                        <legend>Datos del Representante</legend>
                        <div class="grid-2">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="cedula">Cédula <span class="req">*</span></label>
                                <input type="text" class="campo" id="cedula" name="cedula" inputmode="numeric" maxlength="10" placeholder="Solo números">
                                <small class="campo-error" data-error-for="cedula"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="telefono">Teléfono <span class="req">*</span></label>
                                <input type="tel" class="campo" id="telefono" name="telefono" maxlength="20">
                                <small class="campo-error" data-error-for="telefono"></small>
                            </div>
                        </div>
                        <div class="grid-2">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="nombre">Nombres <span class="req">*</span></label>
                                <input type="text" class="campo" id="nombre" name="nombre" maxlength="150">
                                <small class="campo-error" data-error-for="nombre"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="apellido">Apellidos <span class="req">*</span></label>
                                <input type="text" class="campo" id="apellido" name="apellido" maxlength="150">
                                <small class="campo-error" data-error-for="apellido"></small>
                            </div>
                        </div>
                        <div class="campo-grupo">
                            <label class="campo-etiqueta" for="direccion">Dirección</label>
                            <textarea class="campo" id="direccion" name="direccion" rows="2" maxlength="500" placeholder="Dirección de habitación..."></textarea>
                            <small class="campo-error" data-error-for="direccion"></small>
                        </div>
                        <p class="form-nota" id="notaCambioCedula" hidden>
                            Si cambias la cédula, también se actualizarán las cédulas escolares de sus estudiantes.
                        </p>
                    </fieldset>

                    <fieldset id="bloqueEstudianteInicial">
                        <legend>Estudiante que representa</legend>
                        <label class="check">
                            <input type="checkbox" id="chkAgregarEstudiante" name="agregar_estudiante" value="1" checked>
                            Registrar un estudiante ahora
                        </label>
                        <p class="form-nota">La cédula escolar se genera automáticamente con la cédula del representante (ej. <code>12345678-1</code>).</p>
                        <div id="camposEstudianteInicial">
                            <?php $p = 'ini_'; include __DIR__ . '/_campos_estudiante.php'; ?>
                        </div>
                    </fieldset>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardarRep">Guardar</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal-backdrop" id="modalAgregarEstudiante" role="dialog" aria-modal="true" aria-labelledby="tituloAgregar">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloAgregar">Agregar Estudiante</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formAgregarEstudiante" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="representante_cedula" id="agregarRepCedula" value="">

                    <p class="form-nota" id="agregarContexto"></p>
                    <p class="form-nota">La cédula escolar se genera automáticamente con la cédula del representante.</p>

                    <?php $p = 'add_'; include __DIR__ . '/_campos_estudiante.php'; ?>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardarEst">Registrar estudiante</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/representante.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>