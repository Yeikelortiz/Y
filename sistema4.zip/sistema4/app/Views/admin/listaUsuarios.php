<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

$etiquetasRol = ['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaria'];

$activo = 'usuarios';
$menu = [
    'panel'          => ['Panel de Control',      'icono-speedometer2',          'admin',         'index'],
    'usuarios'       => ['Gestión de Usuarios',   'icono-people-fill',           'admin',         'listaUsuarios'],
    'docentes'       => ['Docentes',              'icono-person-badge-fill',     'docente',       'index'],
    'periodos'       => ['Períodos Académicos',   'icono-calendar-range-fill',   'periodo',       'index'],
    'secciones'      => ['Secciones',             'icono-door-open-fill',        'seccion',       'index'],
    'asistencia'     => ['Control Asistencia',    'icono-check2-square',         'asistencia',    'index'],
    'calificaciones' => ['Calificaciones',        'icono-journal-bookmark-fill', 'calificacion',  'index'],
    'estudiantes'    => ['Datos Estudiantes',     'icono-mortarboard-fill',      'estudiante',    'index'],
    'representantes' => ['Representantes',        'icono-person-lines-fill',     'representante', 'index'],
    'bitacora'       => ['Bitácora',              'icono-terminal-fill',         'bitacora',      'index'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios | E.B. Olimpia Barrios</title>

<link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/admin.css?v=20261028-5">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
</head>
<body class="rol-admin" data-base-url="<?= $e($baseUrl) ?>" data-csrf="<?= $e($csrfToken) ?>" data-yo="<?= (int)$usuarioActual ?>">

    <div class="contenedor-fluido">
        <div class="rejilla u-alto-pantalla">

            <aside class="rj-12 rj-md-3 rj-lg-2 sidebar u-t-blanco u-p-3 u-flex u-columna u-entre u-sombra">
                <div>
                    <div class="u-flex u-alinea-centro u-mb-3 u-borde-b u-borde-secundario u-borde-op-50 u-pb-3 u-px-1">
                        <i class="icono icono-cpu-fill u-fs-3 u-me-2 u-t-exito"></i>
                        <span class="u-negrita u-fs-6">E.B. Olimpia Barrios</span>
                    </div>

                    <div class="user-card u-p-3 u-mb-4 u-flex u-alinea-centro">
                        <div class="u-circulo u-t-blanco u-flex u-alinea-centro u-centrado u-me-3 u-no-encoger avatar-admin">
                            <i class="icono icono-shield-lock-fill u-fs-5"></i>
                        </div>
                        <div class="u-lh-sm u-sin-desborde">
                            <span class="u-bloque u-seminegrita u-truncar u-pequeno u-t-blanco"><?= $e($nombreMostrar) ?></span>
                            <span class="insignia u-f-exito u-t-blanco u-borde u-borde-exito-suave u-mt-1 insignia-rol-admin">Admin</span>
                        </div>
                    </div>

                    <nav class="menu menu-pildoras u-columna u-gap-1" aria-label="Menú principal">
                        <?php foreach ($menu as $clave => [$texto, $icono, $controlador, $accion]): ?>
                            <?php $esActivo = ($clave === $activo); ?>
                            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($controlador) ?>&amp;action=<?= $e($accion) ?>"
                               class="menu-enlace <?= $esActivo ? 'active' : '' ?>"
                               <?= $esActivo ? 'aria-current="page"' : '' ?>>
                                <i class="icono <?= $e($icono) ?> u-me-2"></i> <?= $e($texto) ?>
                            </a>
                        <?php endforeach; ?>
                    </nav>
                </div>

                <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-peligro u-ancho-100 u-izq u-mt-3">
                    <i class="icono icono-box-arrow-right u-me-2"></i> Cerrar sesión
                </a>
            </aside>

            <main class="rj-12 rj-md-9 rj-lg-10 u-p-4">

                <div class="u-flex u-entre u-alinea-centro u-envolver u-gap-2 u-mb-4">
                    <div>
                        <h2 class="u-h4 u-negrita u-mb-1 u-t-oscuro">
                            <i class="icono icono-person-gear u-t-exito u-me-2"></i>Gestión de Usuarios del Sistema
                        </h2>
                        <p class="u-t-suave u-mb-0">Consulte, cree y administre los permisos de acceso de Directores y Secretarias .</p>
                    </div>
                    <button type="button" class="boton boton-exito u-sombra-sm" id="btnNuevoUsuario">
                        <i class="icono icono-person-plus-fill u-me-1"></i> Nuevo Usuario
                    </button>
                </div>

                <?php if (!empty($mensajeError)): ?>
                    <div class="mensaje mensaje-peligro mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-exclamation-triangle-fill u-me-2"></i><?= $e($mensajeError) ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Cerrar"></button>
                    </div>
                <?php endif; ?>
                <?php if (!empty($mensajeExito)): ?>
                    <div class="mensaje mensaje-exito mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-check-circle-fill u-me-2"></i><?= $e($mensajeExito) ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Cerrar"></button>
                    </div>
                <?php endif; ?>

                <div class="tarjeta u-sin-borde u-sombra-sm u-mb-4">
                    <div class="tarjeta-cuerpo u-p-3">
                        <div class="rejilla rejilla-g3">
                            <div class="rj-12 rj-md-8">
                                <div class="grupo-input">
                                    <span class="grupo-input-texto u-f-blanco u-sin-borde-d u-t-suave"><i class="icono icono-search"></i></span>
                                    <input type="search" id="inputBusqueda" class="campo u-sin-borde-i u-ps-0" maxlength="100"
                                           placeholder="Buscar por nombre o correo electrónico..." autocomplete="off" aria-label="Buscar usuarios">
                                </div>
                            </div>
                            <div class="rj-12 rj-md-4">
                                <div class="grupo-input">
                                    <span class="grupo-input-texto u-f-blanco u-sin-borde-d u-t-suave"><i class="icono icono-funnel"></i></span>
                                    <select id="selectFiltroRol" class="campo u-sin-borde-i u-ps-0" aria-label="Filtrar por rol">
                                        <option value="">Todos los roles</option>
                                        <?php foreach ($roles as $r): ?>
                                            <option value="<?= $e($r) ?>"><?= $e($etiquetasRol[$r] ?? ucfirst($r)) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tarjeta u-sin-borde u-sombra-sm">
                    <div class="tarjeta-cabecera u-f-blanco u-flex u-entre u-alinea-centro">
                        <strong>Cuentas registradas</strong>
                        <span class="insignia u-f-primario-suave u-t-primario">Total: <span id="contadorTotal">0</span></span>
                    </div>
                    <div class="tarjeta-cuerpo u-p-0">
                        <div class="tabla-responsive">
                            <table class="tabla tabla-hover u-valign-medio u-mb-0" id="tablaUsuarios">
                                <thead class="tabla-clara">
                                    <tr>
                                        <th class="u-ps-4">ID</th>
                                        <th>Nombre</th>
                                        <th>Correo</th>
                                        <th>Rol</th>
                                        <th>Estado</th>
                                        <th>Registro</th>
                                        <th>Última sesión</th>
                                        <th class="u-der u-pe-4">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="cuerpoTabla"></tbody>
                            </table>
                        </div>
                        <div id="estadoTabla" class="u-centro u-t-suave u-py-4" role="status">Cargando usuarios...</div>
                    </div>
                </div>

                <div class="modal" id="modalUsuario" tabindex="-1" aria-labelledby="tituloModalUsuario" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <form id="formUsuario" novalidate>
                                <div class="modal-header">
                                    <h5 class="modal-title u-negrita" id="tituloModalUsuario">Registrar Nuevo Usuario</h5>
                                    <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Cerrar"></button>
                                </div>

                                <div class="modal-body u-p-4">
                                    <input type="hidden" name="id" id="usuarioId" value="0">

                                    <div class="rejilla rejilla-g3">
                                        <div class="rj-12 rj-md-6">
                                            <label for="nombre" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">NOMBRE COMPLETO <span class="u-t-peligro">*</span></label>
                                            <div class="grupo-input">
                                                <span class="grupo-input-texto"><i class="icono icono-person u-t-suave"></i></span>
                                                <input type="text" class="campo" id="nombre" name="nombre" maxlength="100" placeholder="Ej. Juan Pérez">
                                            </div>
                                            <small class="u-t-peligro" data-error-for="nombre"></small>
                                        </div>

                                        <div class="rj-12 rj-md-6">
                                            <label for="email" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">CORREO ELECTRÓNICO <span class="u-t-peligro">*</span></label>
                                            <div class="grupo-input">
                                                <span class="grupo-input-texto"><i class="icono icono-envelope u-t-suave"></i></span>
                                                <input type="email" class="campo" id="email" name="email" maxlength="100" placeholder="usuario@dominio.com" autocomplete="off">
                                            </div>
                                            <small class="u-t-peligro" data-error-for="email"></small>
                                        </div>

                                        <div class="rj-12 rj-md-6">
                                            <label for="rol" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">ROL DEL USUARIO <span class="u-t-peligro">*</span></label>
                                            <div class="grupo-input">
                                                <span class="grupo-input-texto"><i class="icono icono-shield-check u-t-suave"></i></span>
                                                <select class="campo" id="rol" name="rol">
                                                    <option value="">Seleccione un rol...</option>
                                                    <?php foreach ($roles as $r): ?>
                                                        <option value="<?= $e($r) ?>"><?= $e($etiquetasRol[$r] ?? ucfirst($r)) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <small class="u-t-peligro" data-error-for="rol"></small>
                                            <div class="campo-ayuda u-oculto" id="notaRolPropio">No puedes cambiar tu propio rol de administrador.</div>
                                        </div>

                                        <div class="rj-12 rj-md-6">
                                            <label for="password" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">
                                                CONTRASEÑA <span class="u-t-peligro" id="marcaPasswordObligatoria">*</span>
                                                <span class="u-normal u-t-suave u-oculto" id="marcaPasswordOpcional">(opcional)</span>
                                            </label>
                                            <div class="grupo-input">
                                                <span class="grupo-input-texto"><i class="icono icono-lock u-t-suave"></i></span>
                                                <input type="password" class="campo" id="password" name="password" maxlength="72"
                                                       placeholder="••••••••" autocomplete="new-password">
                                                <button type="button" class="boton boton-contorno-secundario" id="btnVerPassword" aria-label="Mostrar u ocultar contraseña">
                                                    <i class="icono icono-eye" id="iconoPassword"></i>
                                                </button>
                                            </div>
                                            <small class="u-t-peligro" data-error-for="password"></small>
                                            <div class="campo-ayuda" id="ayudaPassword">
                                                <i class="icono icono-info-circle u-me-1"></i>Mínimo 7 caracteres: mayúscula, minúscula, número y símbolo.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="boton boton-claro u-borde u-px-4" data-cerrar-modal="">Cancelar</button>
                                    <button type="submit" class="boton boton-esmeralda" id="btnGuardarUsuario">
                                        <i class="icono icono-check-circle u-me-1"></i> Guardar Usuario
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>
<script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/usuarios.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
