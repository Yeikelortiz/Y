<?php
$nombreMostrar = $nombreAdmin ?? $nombreUsuario ?? $_SESSION['usuario_nombre'] ?? 'Administrador';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario | E.B. Olimpia Barrios</title>

<link rel="stylesheet" href="/sistema4/assets/css/admin.css">
    
   
    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
</head>
<body>

    <div class="contenedor-fluido">
        <div class="rejilla u-alto-pantalla">
            
            <aside class="rj-12 rj-md-3 rj-lg-2 sidebar u-t-blanco u-p-3 u-flex u-columna u-entre u-sombra">
                <div>
                    <div class="u-flex u-alinea-centro u-mb-3 u-t-blanco u-sin-subrayado u-borde-b u-borde-secundario u-borde-op-50 u-pb-3 u-px-1">
                        <i class="icono icono-cpu-fill u-fs-3 u-me-2 u-t-exito"></i>
                        <span class="u-negrita u-fs-6">E.B. Olimpia Barrios</span>
                    </div>

                    <div class="user-card u-p-3 u-mb-4 u-flex u-alinea-centro">
                        <div class="u-circulo u-t-blanco u-flex u-alinea-centro u-centrado u-me-3 u-no-encoger avatar-usuario avatar-esmeralda">
                            <i class="icono icono-shield-lock-fill u-fs-5"></i>
                        </div>
                        <div class="u-lh-sm u-sin-desborde">
                            <span class="u-bloque u-seminegrita u-truncar u-pequeno u-t-blanco"><?= htmlspecialchars($nombreMostrar) ?></span>
                            <span class="insignia u-fs-xs u-f-exito u-t-blanco u-borde u-borde-exito-suave u-mt-1">
                                SuperAdmin
                            </span>
                        </div>
                    </div>

                    <nav class="menu menu-pildoras u-columna u-gap-1">
                        <a href="index.php?controller=admin&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-speedometer2 u-me-2"></i> Panel Control
                        </a>

                        <a href="index.php?controller=admin&action=listaUsuarios" class="menu-enlace u-t-blanco active u-f-exito u-f-op-25 u-borde u-borde-exito u-borde-op-50">
                            <i class="icono icono-people-fill u-me-2"></i> Gestión Usuarios (RF-02)
                        </a>

                        <a href="index.php?controller=admin&action=configuracion" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-sliders u-me-2"></i> Config. Sistema (RF-12)
                        </a>

                        <a href="index.php?controller=admin&action=respaldos" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-database-fill-down u-me-2"></i> Respaldos BD (RF-12)
                        </a>

                        <a href="index.php?controller=admin&action=bitacora" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-terminal-fill u-me-2"></i> Bitácora Logs (RF-11)
                        </a>

                        <a href="index.php?controller=estudiante&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-mortarboard-fill u-me-2"></i> Datos Estudiantes
                        </a>
                    </nav>
                </div>

                <a href="index.php?controller=auth&action=logout" class="boton boton-contorno-peligro u-ancho-100 u-izq u-mt-3">
                    <i class="icono icono-box-arrow-right u-me-2"></i> Cerrar sesión
                </a>
            </aside>

            <main class="rj-12 rj-md-9 rj-lg-10 u-p-4">
                
                <div class="u-flex u-entre u-alinea-centro u-mb-4">
                    <div>
                        <h2 class="u-h4 u-negrita u-mb-1 u-t-oscuro">
                            <i class="icono icono-pencil-square u-t-exito u-me-2"></i>Editar Usuario
                        </h2>
                        <p class="u-t-suave u-mb-0">Modifique los datos, la clave o el rol asignado al usuario #<?= htmlspecialchars($usuario['id']) ?> (RF-02).</p>
                    </div>
                    <a href="index.php?controller=admin&action=listaUsuarios" class="boton boton-contorno-secundario">
                        <i class="icono icono-arrow-left u-me-1"></i> Volver a la Lista
                    </a>
                </div>

                <?php if (!empty($_SESSION['flash_error'])): ?>
                    <div class="mensaje mensaje-peligro mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-exclamation-triangle-fill u-me-2"></i>
                        <?= htmlspecialchars($_SESSION['flash_error']) ?>
                        <?php unset($_SESSION['flash_error']); ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="tarjeta u-sin-borde u-sombra-sm">
                    <div class="tarjeta-cuerpo u-p-4 u-p-md-5">
                        <form action="index.php?controller=admin&action=editarUsuario&id=<?= $usuario['id'] ?>" method="POST">
                            
                            <div class="rejilla rejilla-g4">
                                <div class="rj-12 rj-md-6">
                                    <label for="nombre" class="campo-etiqueta u-seminegrita u-t-oscuro">Nombre Completo</label>
                                    <div class="grupo-input grupo-input-lg">
                                        <span class="grupo-input-texto u-f-claro u-t-suave"><i class="icono icono-person"></i></span>
                                        <input type="text" class="campo" id="nombre" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>
                                    </div>
                                </div>

                                <div class="rj-12 rj-md-6">
                                    <label for="email" class="campo-etiqueta u-seminegrita u-t-oscuro">Correo Electrónico</label>
                                    <div class="grupo-input grupo-input-lg">
                                        <span class="grupo-input-texto u-f-claro u-t-suave"><i class="icono icono-envelope"></i></span>
                                        <input type="email" class="campo" id="email" name="email" value="<?= htmlspecialchars($usuario['email']) ?>" required>
                                    </div>
                                </div>

                                <div class="rj-12 rj-md-6">
                                    <label for="password" class="campo-etiqueta u-seminegrita u-t-oscuro">Nueva Contraseña <span class="u-normal u-t-suave">(Opcional)</span></label>
                                    <div class="grupo-input grupo-input-lg">
                                        <span class="grupo-input-texto u-f-claro u-t-suave"><i class="icono icono-lock"></i></span>
                                        <input 
                                            type="password" 
                                            class="campo" 
                                            id="password" 
                                            name="password" 
                                            placeholder="Dejar en blanco para mantener actual" 
                                            minlength="7"
                                            pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{7,}"
                                        >
                                    </div>
                                    <div class="campo-ayuda u-t-suave">Complete solo si desea cambiar la clave. Mín. 7 caracteres (mayúscula, minúscula, número y símbolo).</div>
                                </div>

                                <div class="rj-12 rj-md-6">
                                    <label for="rol" class="campo-etiqueta u-seminegrita u-t-oscuro">Rol del Usuario</label>
                                    <div class="grupo-input grupo-input-lg">
                                        <span class="grupo-input-texto u-f-claro u-t-suave"><i class="icono icono-shield-check"></i></span>
                                        <select class="campo" id="rol" name="rol" required>
                                            <option value="secretaria" <?= $usuario['rol'] === 'secretaria' ? 'selected' : '' ?>>Secretaria</option>
                                            <option value="director" <?= $usuario['rol'] === 'director' ? 'selected' : '' ?>>Director</option>
                                            <option value="admin" <?= $usuario['rol'] === 'admin' ? 'selected' : '' ?>>Administrador</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <hr class="u-my-4 u-t-suave u-opacidad-25">

                            <div class="u-flex u-gap-3 u-fin">
                                <a href="index.php?controller=admin&action=listaUsuarios" class="boton boton-claro u-borde u-px-4 boton-lg">
                                    Cancelar
                                </a>
                                <button type="submit" class="boton boton-exito u-px-5 boton-lg u-sombra-sm">
                                    <i class="icono icono-save u-me-1"></i> Guardar Cambios
                                </button>
                            </div>

                        </form>
                    </div>
                </div>

            </main>
        </div>
    </div>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>