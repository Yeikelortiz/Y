<?php
$nombreMostrar = $nombreAdmin ?? $nombreUsuario ?? $_SESSION['usuario_nombre'] ?? 'Administrador';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Usuario | E.B. Olimpia Barrios</title>

<link rel="stylesheet" href="/sistema4/assets/css/admin.css">
    
  
    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
</head>
<body>

    <div class="contenedor-fluido">
        <div class="rejilla u-alto-pantalla">
            
            <aside class="rj-12 rj-md-3 rj-lg-2 sidebar u-t-blanco u-p-3 u-flex u-columna u-entre u-sombra">
                <div>
                    <div class="u-flex u-alinea-centro u-mb-3 u-t-blanco u-sin-subrayado u-borde-b u-borde-secundario u-borde-op-50 u-pb-3 u-px-1">
                        <i class="icono icono-cpu-fill u-fs-3 u-me-2 u-t-exito"></i>
                        <span class="u-negrita u-fs-6">E.B. Olimpia Barrios</span>
                    </div>

                    <div class="user-card u-p-3 u-mb-4 u-flex u-alinea-centro">
                        <div class="u-circulo u-t-blanco u-flex u-alinea-centro u-centrado u-me-3 u-no-encoger avatar-usuario avatar-esmeralda">
                            <i class="icono icono-shield-lock-fill u-fs-5"></i>
                        </div>
                        <div class="u-lh-sm u-sin-desborde">
                            <span class="u-bloque u-seminegrita u-truncar u-pequeno u-t-blanco"><?= htmlspecialchars($nombreMostrar) ?></span>
                            <span class="insignia u-fs-xs u-f-exito u-t-blanco u-borde u-borde-exito-suave u-mt-1">
                                SuperAdmin
                            </span>
                        </div>
                    </div>

                    <nav class="menu menu-pildoras u-columna u-gap-1">
                        <a href="index.php?controller=admin&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-speedometer2 u-me-2"></i> Panel Control
                        </a>

                        <a href="index.php?controller=admin&action=listaUsuarios" class="menu-enlace u-t-blanco active u-f-exito u-f-op-25 u-borde u-borde-exito u-borde-op-50">
                            <i class="icono icono-people-fill u-me-2"></i> Gestión Usuarios 
                        </a>

                        <a href="index.php?controller=admin&action=configuracion" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-sliders u-me-2"></i> Config. Sistema 
                        </a>



                        <a href="index.php?controller=admin&action=bitacora" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-terminal-fill u-me-2"></i> Bitácora Logs 
                        </a>

                        <a href="index.php?controller=estudiante&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-mortarboard-fill u-me-2"></i> Lista de  Estudiantes
                        </a>
                    </nav>
                </div>

                <a href="index.php?controller=auth&action=logout" class="boton boton-contorno-peligro u-ancho-100 u-izq u-mt-3">
                    <i class="icono icono-box-arrow-right u-me-2"></i> Cerrar sesión
                </a>
            </aside>

            <main class="rj-12 rj-md-9 rj-lg-10 u-p-4">
                
                <div class="u-flex u-entre u-alinea-centro u-mb-4">
                    <div>
                        <h2 class="u-h4 u-negrita u-mb-1 u-t-oscuro">
                            Registrar Nuevo Usuario
                        </h2>
                        <p class="u-t-suave u-mb-0">Complete el formulario para dar de alta accesos al sistema según el rol requerido.</p>
                    </div>
                    <a href="index.php?controller=admin&action=listaUsuarios" class="boton boton-contorno-secundario boton-sm u-px-3">
                        <i class="icono icono-arrow-left u-me-1"></i> Volver a la lista
                    </a>
                </div>

                <?php if (!empty($_SESSION['flash_error'])): ?>
                    <div class="mensaje mensaje-peligro mensaje-cerrable u-sin-borde u-sombra-sm u-mb-4" role="alert">
                        <i class="icono icono-exclamation-triangle-fill u-me-2"></i>
                        <?= htmlspecialchars($_SESSION['flash_error']) ?>
                        <?php unset($_SESSION['flash_error']); ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="tarjeta tarjeta-propia u-sombra-sm">
                    <div class="tarjeta-cuerpo u-p-4 u-p-md-5">
                        <form action="index.php?controller=admin&action=registrar" method="POST">
                            
                            <div class="rejilla rejilla-g4">
                                
                                <div class="rj-12 rj-md-6">
                                    <label for="rol" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">ROL DEL USUARIO</label>
                                    <div class="grupo-input">
                                        <span class="grupo-input-texto"><i class="icono icono-shield-check u-t-suave"></i></span>
                                        <select class="campo" id="rol" name="rol" required>
                                            <option value="" disabled selected>Seleccione un rol...</option>
                                            <option value="secretaria">Secretaria</option>
                                            <option value="director">Director</option>                               
                                            <option value="admin">Administrador</option>
                                         
                                        </select>
                                    </div>
                                </div>

                                <div class="rj-12 rj-md-6">
                                    <label for="nombre" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">NOMBRE COMPLETO</label>
                                    <div class="grupo-input">
                                        <span class="grupo-input-texto"><i class="icono icono-person u-t-suave"></i></span>
                                        <input type="text" class="campo" id="nombre" name="nombre" placeholder="Ej. Juan Pérez" required>
                                    </div>
                                </div>

                                <div class="rj-12 rj-md-6 u-oculto" id="campo-cedula">
                                    <label for="cedula" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">CÉDULA DE IDENTIDAD</label>
                                    <div class="grupo-input">
                                        <span class="grupo-input-texto"><i class="icono icono-card-heading u-t-suave"></i></span>
                                        <input type="text" class="campo" id="cedula" name="cedula" placeholder="Ej. V-12345678">
                                    </div>
                                </div>
                    

                                <div class="rj-12 rj-md-6">
                                    <label for="email" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">CORREO ELECTRÓNICO</label>
                                    <div class="grupo-input">
                                        <span class="grupo-input-texto"><i class="icono icono-envelope u-t-suave"></i></span>
                                        <input type="email" class="campo" id="email" name="email" placeholder="usuario@dominio.com" required>
                                    </div>
                                </div>

                                <div class="rj-12 rj-md-6">
                                    <label for="password" class="campo-etiqueta u-seminegrita u-t-secundario u-pequeno">CONTRASEÑA</label>
                                    <div class="grupo-input">
                                        <span class="grupo-input-texto"><i class="icono icono-lock u-t-suave"></i></span>
                                        <input 
                                            type="password" 
                                            class="campo" 
                                            id="password" 
                                            name="password" 
                                            placeholder="••••••••" 
                                            required 
                                            minlength="7"
                                            pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{7,}"
                                            title="La contraseña debe tener al menos 7 caracteres e incluir: mayúsculas, minúsculas, números y al menos un símbolo especial."
                                        >
                                    </div>
                                    <div class="campo-ayuda u-t-suave u-pequeno u-mt-1" id="passwordHelp">
                                        <i class="icono icono-info-circle u-me-1"></i>Mínimo 7 caracteres: incluir mayúscula, minúscula, número y símbolo.
                                    </div>
                                </div>

                            </div>

                            <hr class="u-my-4 u-t-suave u-opacidad-25">

                            <div class="u-flex u-gap-2 u-fin">
                                <a href="index.php?controller=admin&action=listaUsuarios" class="boton boton-claro u-px-4">
                                    Cancelar
                                </a>
                                <button type="submit" class="boton boton-esmeralda">
                                    <i class="icono icono-check-circle u-me-1"></i> Guardar Usuario
                                </button>
                            </div>

                        </form>
                    </div>
                </div>

            </main>
        </div>
    </div>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>