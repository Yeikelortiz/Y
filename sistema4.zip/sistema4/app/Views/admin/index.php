<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$nombreMostrar = $nombreUsuario ?? $_SESSION['usuario_nombre'] ?? 'Administrador';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración | E.B. Olimpia Barrios</title>

<link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/admin.css?v=20261028-5">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
</head>
<body class="rol-admin">

    <div class="contenedor-fluido">
        <div class="rejilla u-alto-pantalla">

            <!-- Barra Lateral / Sidebar (Enlaces explícitos) -->
            <aside class="rj-12 rj-md-3 rj-lg-2 sidebar u-t-blanco u-p-3 u-flex u-columna u-entre u-sombra">
                <div>
                    <div class="u-flex u-alinea-centro u-mb-3 u-borde-b u-borde-secundario u-borde-op-50 u-pb-3 u-px-1">
                        <i class="icono icono-cpu-fill u-fs-3 u-me-2 u-t-exito"></i>
                        <span class="u-negrita u-fs-6">E.B. Olimpia Barrios</span>
                    </div>

                    <div class="user-card u-p-3 u-mb-4 u-flex u-alinea-centro">
                        <div class="u-circulo u-t-blanco u-flex u-alinea-centro u-centrado u-me-3 u-no-encoger avatar-admin" >
                            <i class="icono icono-shield-lock-fill u-fs-5"></i>
                        </div>
                        <div class="u-lh-sm u-sin-desborde">
                            <span class="u-bloque u-seminegrita u-truncar u-pequeno u-t-blanco"><?= htmlspecialchars($nombreMostrar) ?></span>
                            <span class="insignia insignia-rol-admin u-mt-1">
                                Admin
                            </span>
                        </div>
                    </div>

                    <?php
                    $activo = 'panel';
                    $menu = [
                        'panel'          => ['Panel de Control',      'icono-speedometer2',          'admin',         'index'],
                        'usuarios'       => ['Gestión de Usuarios',   'icono-people-fill',           'admin',         'listaUsuarios'],
                        'docentes'       => ['Docentes',              'icono-person-badge-fill',     'docente',       'index'],
                        'periodos'       => ['Períodos Académicos',   'icono-calendar-range-fill',   'periodo',       'index'],
                        'secciones'      => ['Secciones',             'icono-door-open-fill',        'seccion',       'index'],
                        'asistencia'     => ['Control Asistencia',    'icono-check2-square',         'asistencia',    'index'],
                        'calificaciones' => ['Calificaciones',        'icono-journal-bookmark-fill', 'calificacion',  'index'],
                        'estudiantes'    => ['Datos Estudiantes',     'icono-mortarboard-fill',      'estudiante',    'index'],
                        'representantes' => ['Representantes',        'icono-person-lines-fill',     'representante', 'index'],
                        'bitacora'       => ['Bitácora',              'icono-terminal-fill',         'bitacora',      'index'],
                    ];
                    ?>
                    <nav class="menu menu-pildoras u-columna u-gap-1" aria-label="Menú principal">
                        <?php foreach ($menu as $clave => [$texto, $icono, $controlador, $accion]): ?>
                            <?php $esActivo = ($clave === $activo); ?>
                            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($controlador) ?>&amp;action=<?= $e($accion) ?>"
                               class="menu-enlace <?= $esActivo ? 'active' : '' ?>"
                               <?= $esActivo ? 'aria-current="page"' : '' ?>>
                                <i class="icono <?= $e($icono) ?> u-me-2"></i> <?= $e($texto) ?>
                            </a>
                        <?php endforeach; ?>
                    </nav>
                </div>

                <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-peligro u-ancho-100 u-izq u-mt-3">
                    <i class="icono icono-box-arrow-right u-me-2"></i> Cerrar sesión
                </a>
            </aside>

            <!-- Contenido Principal -->
            <main class="rj-12 rj-md-9 rj-lg-10 u-p-4">

                <div class="u-flex u-entre u-alinea-centro u-envolver u-gap-2 u-mb-4">
                    <div>
                        <h2 class="u-h4 u-negrita u-mb-1 u-t-oscuro">Panel de Administración</h2>
                        <p class="u-t-suave u-mb-0">Bienvenido/a, <?= htmlspecialchars($nombreMostrar) ?>. Administre las credenciales y módulos académicos del Sistema Escolar.</p>
                    </div>
                    <span class="insignia u-f-oscuro u-t-blanco u-borde u-sombra-sm u-px-3 u-py-2">
                        <i class="icono icono-gear-wide-connected u-me-1"></i> Perfil: Administrador del Sistema
                    </span>
                </div>

                <?php if (!empty($mensajeError)): ?>
                    <div class="mensaje mensaje-peligro mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-exclamation-triangle-fill u-me-2"></i><?= htmlspecialchars($mensajeError) ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Cerrar"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($mensajeExito)): ?>
                    <div class="mensaje mensaje-exito mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-check-circle-fill u-me-2"></i><?= htmlspecialchars($mensajeExito) ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Cerrar"></button>
                    </div>
                <?php endif; ?>

                <!-- Tarjetas de Estadísticas / Resumen -->
                <div class="rejilla rejilla-g3 u-mb-4">
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta u-sin-borde u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-flex u-alinea-centro u-p-3">
                                <div class="u-f-primario u-f-op-10 u-t-primario u-p-3 u-redondeado-3 u-me-3"><i class="icono icono-people-fill u-fs-3"></i></div>
                                <div>
                                    <span class="u-t-suave u-pequeno">Cuentas Registradas</span>
                                    <h3 class="u-negrita u-mb-0 u-t-oscuro"><?= (int)($totalUsers ?? 0) ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta u-sin-borde u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-flex u-alinea-centro u-p-3">
                                <div class="u-f-exito u-f-op-10 u-t-exito u-p-3 u-redondeado-3 u-me-3"><i class="icono icono-database-check u-fs-3"></i></div>
                                <div>
                                    <span class="u-t-suave u-pequeno">Estado Servidor / BD</span>
                                    <h3 class="u-fs-5 u-negrita u-mb-0 u-t-exito">Operativo</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta u-sin-borde u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-flex u-alinea-centro u-p-3">
                                <div class="u-f-info u-f-op-10 u-t-info u-p-3 u-redondeado-3 u-me-3"><i class="icono icono-clock-history u-fs-3"></i></div>
                                <div>
                                    <span class="u-t-suave u-pequeno">Última Sesión</span>
                                    <h3 class="u-fs-6 u-negrita u-mb-0 u-t-oscuro"><?= htmlspecialchars($ultimaSesion ?? 'N/D') ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

               
                <div class="rejilla rejilla-g4">

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-primario u-f-op-10 u-t-primario u-p-2 u-redondeado">
                                            <i class="icono icono-person-gear u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-primario-suave u-t-primario">Usuarios</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Gestión de Usuarios</h5>
                                    <p class="u-t-suave u-pequeno">Crear cuentas para Director y Secretarias. Resetear claves y restaurar accesos bloqueados.</p>
                                </div>
                                <div class="u-flex u-gap-2 u-mt-3">
                                    <a href="<?= $e($baseUrl) ?>index.php?controller=admin&amp;action=listaUsuarios" class="boton boton-contorno-primario boton-sm u-flex-1">
                                        Ver Lista
                                    </a>
                                    <a href="<?= $e($baseUrl) ?>index.php?controller=admin&amp;action=listaUsuarios&amp;nuevo=1" class="boton boton-primario boton-sm u-flex-1">
                                        <i class="icono icono-plus-lg u-me-1"></i>Crear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado">
                                            <i class="icono icono-person-badge-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito">Académico</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Personal Docente</h5>
                                    <p class="u-t-suave u-pequeno">Registrar maestros y profesores titulados, modificar datos de contacto e imparte asignaciones.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=docente&amp;action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-3">
                                    Gestión de Docentes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado">
                                            <i class="icono icono-calendar-range-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info">Estructura</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Períodos Académicos</h5>
                                    <p class="u-t-suave u-pequeno">Aperturar años escolares (ej: 2026-2027), gestionar el estado de cierre y momentos lectivos.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=periodo&amp;action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-3">
                                    Ver Períodos <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-peligro u-f-op-10 u-t-peligro u-p-2 u-redondeado">
                                            <i class="icono icono-door-open-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-peligro-suave u-t-peligro">Aulas</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Aulas y Secciones</h5>
                                    <p class="u-t-suave u-pequeno">Configurar grados y secciones (1° a 6° A/B), asignar aulas, horarios y docentes titulares.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=seccion&amp;action=index" class="boton boton-contorno-peligro boton-sm u-ancho-100 u-mt-3">
                                    Administrar Secciones <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-aviso u-f-op-10 u-t-aviso u-p-2 u-redondeado">
                                            <i class="icono icono-check2-square u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-aviso-suave u-t-aviso">Por momento</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Control de Asistencia</h5>
                                    <p class="u-t-suave u-pequeno">Registrar las asistencias e inasistencias de cada sección por momento académico y generar reportes.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=asistencia&amp;action=index" class="boton boton-contorno-aviso boton-sm u-ancho-100 u-mt-3">
                                    Tomar Asistencia <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-secundario u-f-op-10 u-t-secundario u-p-2 u-redondeado">
                                            <i class="icono icono-journal-bookmark-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-secundario-suave u-t-oscuro">Evaluación</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Notas y Calificaciones</h5>
                                    <p class="u-t-suave u-pequeno">Cargar boletines académicos por momentos, estados cuantitativos/cualitativos e incidencias.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=calificacion&amp;action=index" class="boton boton-contorno-secundario boton-sm u-ancho-100 u-mt-3">
                                    Cargar Calificaciones <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                  
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado">
                                            <i class="icono icono-mortarboard-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info">Global</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Base de Datos Estudiantil</h5>
                                    <p class="u-t-suave u-pequeno">Supervisar la lista global de alumnos matriculados y corregir incongruencias de datos.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=estudiante&amp;action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-3">
                                    Ver Estudiantes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado">
                                            <i class="icono icono-person-lines-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito">Módulo</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Gestión de Representantes</h5>
                                    <p class="u-t-suave u-pequeno">Administrar la lista de representantes, registrar nuevos tutores y datos de contacto.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=representante&amp;action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-3">
                                    Ver Representantes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-oscuro u-f-op-10 u-t-oscuro u-p-2 u-redondeado">
                                            <i class="icono icono-terminal-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-secundario-suave u-t-oscuro">Bitácora</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Logs y Bitácora </h5>
                                    <p class="u-t-suave u-pequeno">Revisar registros del sistema para diagnosticar errores de ejecución e inconsistencias.</p>
                                </div>
                                <a href="<?= $e($baseUrl) ?>index.php?controller=bitacora&amp;action=index" class="boton boton-contorno-oscuro boton-sm u-ancho-100 u-mt-3">
                                    Auditar Registros <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>

            </main>
        </div>
    </div>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>