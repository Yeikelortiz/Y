<?php
$nombreMostrar = $nombreUsuario ?? $_SESSION['usuario_nombre'] ?? 'Director(a)';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Dirección | E.B. Olimpia Barrios</title>

<link rel="stylesheet" href="/sistema4/assets/css/director.css">
    <link rel="stylesheet" href="/sistema4/assets/css/vistas-referencia.css?v=20261028-12">

    <style>
        /* Estilos personalizados para darle más vida y color a la barra lateral del Director */
        aside.sidebar {
            background: linear-gradient(180deg, #1e1b4b 0%, #312e81 50%, #0f172a 100%) !important;
            border-right: 1px solid rgba(99, 102, 241, 0.25);
        }
        aside.sidebar .nav-link {
            transition: all 0.3s ease;
            border-radius: 0.375rem;
            margin-bottom: 2px;
        }
        aside.sidebar .nav-link:hover {
            background-color: rgba(99, 102, 241, 0.2);
            color: #ffffff !important;
            transform: translateX(4px);
        }
        aside.sidebar .nav-link.active {
            background-color: rgba(99, 102, 241, 0.35) !important;
            color: #ffffff !important;
            border: 1px solid rgba(129, 140, 248, 0.6);
        }
        .user-card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(129, 140, 248, 0.3);
            border-radius: 0.5rem;
        }
    </style>
    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
</head>
<body class="rol-director">

    <div class="contenedor-fluido">
        <div class="rejilla u-alto-pantalla">
            
            <!-- Sidebar / Barra Lateral con nuevo diseño de color -->
            <aside class="rj-12 rj-md-3 rj-lg-2 sidebar u-t-blanco u-p-3 u-flex u-columna u-entre u-sombra">
                <div>
                    <div class="u-flex u-alinea-centro u-mb-3 u-t-blanco u-sin-subrayado u-borde-b u-borde-indigo u-borde-op-50 u-pb-3 u-px-1">
                        <i class="icono icono-building-fill-gear u-fs-3 u-me-2 u-t-aviso"></i>
                        <span class="u-negrita u-fs-6">E.B. Olimpia Barrios</span>
                    </div>

                    <div class="user-card u-p-3 u-mb-4 u-flex u-alinea-centro u-sombra-sm">
                        <div class="u-circulo u-t-blanco u-flex u-alinea-centro u-centrado u-me-3 u-no-encoger avatar-usuario avatar-indigo">
                            <i class="icono icono-person-badge u-fs-5"></i>
                        </div>
                        <div class="u-lh-sm u-sin-desborde">
                            <span class="u-bloque u-seminegrita u-truncar u-pequeno u-t-blanco"><?= htmlspecialchars($nombreMostrar) ?></span>
                            <span class="insignia u-fs-xs u-f-aviso u-t-oscuro u-borde u-borde-aviso-suave u-mt-1">
                                Director
                            </span>
                        </div>
                    </div>

                    <nav class="menu menu-pildoras u-columna u-gap-1">
                        <a href="index.php?controller=director&action=index" class="menu-enlace u-t-blanco active">
                            <i class="icono icono-speedometer2 u-me-2 u-t-aviso"></i> Panel Principal
                        </a>
                        <a href="index.php?controller=docente&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-person-badge-fill u-me-2 u-t-exito"></i> Lista de Docentes
                        </a>
                        <a href="index.php?controller=estudiante&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-mortarboard-fill u-me-2 u-t-info"></i> Lista de Estudiantes
                        </a>
                        <a href="index.php?controller=representante&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-person-lines-fill u-me-2 u-t-exito"></i> Lista de Representantes
                        </a>
                        <a href="index.php?controller=seccion&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-door-open-fill u-me-2 u-t-peligro"></i> Secciones
                        </a>
                        <a href="index.php?controller=periodo&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-calendar-range-fill u-me-2 u-t-info"></i> Períodos Académicos
                        </a>
                        <a href="index.php?controller=asistencia&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-check2-square u-me-2 u-t-aviso"></i> Control Asistencia
                        </a>
                        <a href="index.php?controller=calificacion&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-journal-bookmark-fill u-me-2 u-t-secundario"></i> Calificaciones
                        </a>
                        <a href="index.php?controller=boletin&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-file-earmark-check u-me-2 u-t-exito"></i> Revisión de Boletines
                        </a>
                        <a href="index.php?controller=reporte&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-graph-up-arrow u-me-2 u-t-info"></i> Reportes Generales
                        </a>
                        <a href="index.php?controller=bitacora&action=index" class="menu-enlace u-t-blanco-50">
                            <i class="icono icono-terminal-fill u-me-2 u-t-claro"></i> Bitácora
                        </a>
                    </nav>
                </div>

                <a href="index.php?controller=auth&action=logout" class="boton boton-contorno-peligro u-ancho-100 u-izq u-mt-3">
                    <i class="icono icono-box-arrow-right u-me-2"></i> Cerrar sesión
                </a>
            </aside>

            <!-- Contenido Principal -->
            <main class="rj-12 rj-md-9 rj-lg-10 u-p-4 u-f-claro">
                
                <div class="u-flex u-entre u-alinea-centro u-mb-4">
                    <div>
                        <h2 class="u-h4 u-negrita u-mb-1 u-t-oscuro">
                            Panel Estratégico y Directivo
                        </h2>
                        <p class="u-t-suave u-mb-0">Bienvenido/a, <?= htmlspecialchars($nombreMostrar) ?>. Gestione las aprobaciones y supervisión del plantel.</p>
                    </div>
                    <span class="insignia u-f-blanco u-t-oscuro u-borde u-sombra-sm u-px-3 u-py-2">
                        <i class="icono icono-shield-check u-t-indigo u-me-1"></i> Perfil: Director
                    </span>
                </div>

                <?php if (!empty($mensajeError)): ?>
                    <div class="mensaje mensaje-peligro mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-exclamation-triangle-fill u-me-2"></i><?= htmlspecialchars($mensajeError) ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($mensajeExito)): ?>
                    <div class="mensaje mensaje-exito mensaje-cerrable u-mb-4 u-sombra-sm" role="alert">
                        <i class="icono icono-check-circle-fill u-me-2"></i><?= htmlspecialchars($mensajeExito) ?>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Grid de Tarjetas (10 cuadros exactos según el menú) -->
                <div class="rejilla rejilla-g4">

                    <!-- 1. Cuadro: Lista de Docentes -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado">
                                            <i class="icono icono-person-badge-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito">Académico</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Personal Docente</h5>
                                    <p class="u-t-suave u-pequeno">Registrar maestros y profesores titulados, modificar datos de contacto e imparte asignaciones.</p>
                                </div>
                                <a href="index.php?controller=docente&action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-3">
                                    Gestión de Docentes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 2. Cuadro: Lista de Estudiantes -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado">
                                            <i class="icono icono-mortarboard-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info">Global</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Base de Datos Estudiantil</h5>
                                    <p class="u-t-suave u-pequeno">Supervisar la lista global de alumnos matriculados y corregir incongruencias de datos.</p>
                                </div>
                                <a href="index.php?controller=estudiante&action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-3">
                                    Ver Estudiantes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 3. Cuadro: Lista de Representantes -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado">
                                            <i class="icono icono-person-lines-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito">Módulo</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Gestión de Representantes</h5>
                                    <p class="u-t-suave u-pequeno">Administrar la lista de representantes, registrar nuevos tutores y datos de contacto.</p>
                                </div>
                                <a href="index.php?controller=representante&action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-3">
                                    Ver Representantes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Cuadro: Secciones -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-peligro u-f-op-10 u-t-peligro u-p-2 u-redondeado">
                                            <i class="icono icono-door-open-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-peligro-suave u-t-peligro">Aulas</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Aulas y Secciones</h5>
                                    <p class="u-t-suave u-pequeno">Configurar grados y secciones (1° a 6° A/B), asignar aulas, horarios y docentes titulares.</p>
                                </div>
                                <a href="index.php?controller=seccion&action=index" class="boton boton-contorno-peligro boton-sm u-ancho-100 u-mt-3">
                                    Administrar Secciones <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 5. Cuadro: Periodos Académicos -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado">
                                            <i class="icono icono-calendar-range-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info">Estructura</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Períodos Académicos</h5>
                                    <p class="u-t-suave u-pequeno">Aperturar años escolares (ej: 2026-2027), gestionar el estado de cierre y momentos lectivos.</p>
                                </div>
                                <a href="index.php?controller=periodo&action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-3">
                                    Ver Períodos <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 6. Cuadro: Control Asistencia -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-aviso u-f-op-10 u-t-aviso u-p-2 u-redondeado">
                                            <i class="icono icono-check2-square u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-aviso-suave u-t-aviso">Por momento</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Control de Asistencia</h5>
                                    <p class="u-t-suave u-pequeno">Registrar las asistencias e inasistencias de cada sección por momento académico y generar reportes.</p>
                                </div>
                                <a href="index.php?controller=asistencia&action=index" class="boton boton-contorno-aviso boton-sm u-ancho-100 u-mt-3">
                                    Tomar Asistencia <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 7. Cuadro: Calificaciones -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-secundario u-f-op-10 u-t-secundario u-p-2 u-redondeado">
                                            <i class="icono icono-journal-bookmark-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-secundario-suave u-t-oscuro">Evaluación</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Notas y Calificaciones</h5>
                                    <p class="u-t-suave u-pequeno">Cargar boletines académicos por momentos, estados cuantitativos/cualitativos e incidencias.</p>
                                </div>
                                <a href="index.php?controller=calificacion&action=index" class="boton boton-contorno-secundario boton-sm u-ancho-100 u-mt-3">
                                    Cargar Calificaciones <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 8. Cuadro: Revisión de Boletines -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado">
                                            <i class="icono icono-file-earmark-check u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito">Boletines</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Supervisión de Boletines</h5>
                                    <p class="u-t-suave u-pequeno">Revisar y validar el rendimiento evaluativo previo a la firma y sellado institucional.</p>
                                </div>
                                <a href="index.php?controller=boletin&action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-3">
                                    Revisar y Autorizar <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 9. Cuadro: Reportes Generales -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado">
                                            <i class="icono icono-graph-up-arrow u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info">Métricas</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Reportes Institucionales</h5>
                                    <p class="u-t-suave u-pequeno">Consultar índices de rendimiento, matrículas consolidadas y estadísticas generales.</p>
                                </div>
                                <a href="index.php?controller=reporte&action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-3">
                                    Ver Estadísticas <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 10. Cuadro: Bitácora y Auditoría -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-oscuro u-f-op-10 u-t-oscuro u-p-2 u-redondeado">
                                            <i class="icono icono-terminal-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-secundario-suave u-t-oscuro">Bitácora</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Logs y Bitácora Técnica</h5>
                                    <p class="u-t-suave u-pequeno">Revisar registros del sistema para diagnosticar errores de ejecución e inconsistencias.</p>
                                </div>
                                <a href="index.php?controller=bitacora&action=index" class="boton boton-contorno-oscuro boton-sm u-ancho-100 u-mt-3">
                                    Auditar Registros <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>

            </main>
        </div>
    </div>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>