<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Docente | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-editar="<?= $puedeEditar ? '1' : '0' ?>"
    data-puede-eliminar="<?= $puedeEliminar ? '1' : '0' ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!$puedeEditar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura en este módulo.</div>
        <?php elseif (!$puedeEliminar): ?>
            <div class="alert-info-box">
                <strong>Nota:</strong> puedes registrar y editar docentes. La eliminación está reservada a administrador y director.
            </div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Personal Docente</h1>
                <p class="page-subtitle">Registro de maestros y profesores titulados</p>
            </div>

            <div class="search-group">
                <input type="search" class="campo" id="inputBusqueda" maxlength="100"
                       placeholder="Buscar por cédula, nombre o correo..." autocomplete="off"
                       aria-label="Buscar docentes">
                <button type="button" id="btnLimpiarBusqueda" class="boton boton-contorno-secundario boton-sm" hidden>Limpiar</button>
            </div>

            <?php if ($puedeEditar): ?>
                <button type="button" class="boton boton-primario" id="btnNuevoDocente">+ Registrar Docente</button>
            <?php endif; ?>
        </div>

        <section class="tarjeta">
            <div class="tarjeta-cabecera">
                <strong>Docentes Registrados</strong>
                <span class="insignia-pildora insignia-primaria">Total: <span id="contadorTotal">0</span> docentes</span>
            </div>

            <div class="tabla-responsive">
                <table id="tablaDocentes">
                    <thead>
                        <tr>
                            <th>Cédula</th>
                            <th>Docente</th>
                            <th>Contacto</th>
                            <th>Secciones</th>
                            <?php if ($puedeEditar): ?><th class="u-der">Acciones</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTabla"></tbody>
                </table>
            </div>

            <div id="estadoTabla" class="estado-tabla" role="status">Cargando docentes...</div>
            <nav id="paginacion" class="paginacion" aria-label="Paginación" hidden></nav>
        </section>
    </main>

    <?php if ($puedeEditar): ?>
    <div class="modal-backdrop" id="modalDocente" role="dialog" aria-modal="true" aria-labelledby="tituloModalDocente">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloModalDocente">Registrar Docente</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formDocente" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="id" id="docenteId" value="0">

                    <p class="form-nota">Los campos con <span class="req">*</span> son obligatorios.</p>

                    <fieldset>
                        <legend>Datos personales</legend>
                        <div class="grid-3">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="cedula">Cédula <span class="req">*</span></label>
                                <input type="text" class="campo" id="cedula" name="cedula" inputmode="numeric" maxlength="20" placeholder="Solo números">
                                <small class="campo-error" data-error-for="cedula"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="fecha_nacimiento">Fecha de nacimiento <span class="req">*</span></label>
                                <input type="date" class="campo" id="fecha_nacimiento" name="fecha_nacimiento">
                                <small class="campo-error" data-error-for="fecha_nacimiento"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="genero">Género <span class="req">*</span></label>
                                <select class="campo" id="genero" name="genero">
                                    <option value="">Seleccione...</option>
                                    <option value="M">Masculino</option>
                                    <option value="F">Femenino</option>
                                    <option value="Otro">Otro</option>
                                </select>
                                <small class="campo-error" data-error-for="genero"></small>
                            </div>
                        </div>
                        <div class="grid-2">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="nombres">Nombres <span class="req">*</span></label>
                                <input type="text" class="campo" id="nombres" name="nombres" maxlength="100">
                                <small class="campo-error" data-error-for="nombres"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="apellidos">Apellidos <span class="req">*</span></label>
                                <input type="text" class="campo" id="apellidos" name="apellidos" maxlength="100">
                                <small class="campo-error" data-error-for="apellidos"></small>
                            </div>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Contacto</legend>
                        <div class="grid-2">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="correo">Correo electrónico <span class="req">*</span></label>
                                <input type="email" class="campo" id="correo" name="correo" maxlength="150" autocomplete="off">
                                <small class="campo-error" data-error-for="correo"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="telefono">Teléfono</label>
                                <input type="tel" class="campo" id="telefono" name="telefono" maxlength="20">
                                <small class="campo-error" data-error-for="telefono"></small>
                            </div>
                        </div>
                        <div class="campo-grupo">
                            <label class="campo-etiqueta" for="direccion">Dirección</label>
                            <input type="text" class="campo" id="direccion" name="direccion" maxlength="200">
                            <small class="campo-error" data-error-for="direccion"></small>
                        </div>
                    </fieldset>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardar">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/docente.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
