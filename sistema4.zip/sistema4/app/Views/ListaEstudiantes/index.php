<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Matrícula General | E.B. Olimpia Barrios</title>
   <link rel="stylesheet" href="<?= $e($assetsUrl) ?>/css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body
    class="vista-listado rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-editar="<?= $puedeEditar ? '1' : '0' ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <!-- El enlace del panel apunta estrictamente al rol correcto ($panel) -->
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

   <main class="contenedor">

        <?php if ($puedeEditar && !$esAdmin): ?>
            <div class="alert-info-box">
                <strong>Nota de Secretaría:</strong> puedes registrar, editar y eliminar estudiantes y los datos de sus representantes.
            </div>
        <?php elseif (!$puedeEditar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura en este módulo.</div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Matrícula General</h1>
                <p class="page-subtitle">Listado general de alumnos inscritos</p>
            </div>

            <div class="search-group">
                <input type="search" class="campo" id="inputBusqueda" maxlength="100"
                       placeholder="Buscar por cédula, nombre o representante..." autocomplete="off"
                       aria-label="Buscar estudiantes">
                <button type="button" id="btnLimpiarBusqueda" class="boton boton-contorno-secundario boton-sm" hidden>Limpiar</button>
            </div>

            <?php if ($puedeEditar): ?>
                <button type="button" class="boton boton-primario" id="btnNuevoEstudiante">+ Inscribir Estudiante</button>
            <?php endif; ?>
        </div>

        <section class="tarjeta">
            <div class="tarjeta-cabecera">
                <strong>Estudiantes Registrados</strong>
                <span class="insignia-pildora insignia-primaria">Total: <span id="contadorTotal">0</span> alumnos</span>
            </div>

            <div class="tabla-responsive">
                <table id="tablaEstudiantes">
                    <thead>
                        <tr>
                            <th>Cédula Escolar</th>
                            <th>Estudiante</th>
                            <th>Edad</th>
                            <th>Sección / Grado</th>
                            <th>Representante (Cédula)</th>
                            <?php if ($puedeEditar): ?><th class="u-der">Acciones</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTabla"></tbody>
                </table>
            </div>

            <div id="estadoTabla" class="estado-tabla" role="status">Cargando estudiantes...</div>

            <nav id="paginacion" class="paginacion" aria-label="Paginación" hidden></nav>
        </section>
    </main>

    <?php if ($puedeEditar): ?>
    <div class="modal-backdrop" id="modalEstudiante" role="dialog" aria-modal="true" aria-labelledby="tituloModalEstudiante">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloModalEstudiante">Registro de Inscripción</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formEstudiante" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="id" id="estudianteId" value="0">

                    <p class="form-nota">
                        Los campos con <span class="req">*</span> son obligatorios. La <strong>cédula escolar se genera
                        automáticamente</strong> con la cédula del representante (ej. <code>12345678-1</code>, <code>12345678-2</code>).
                    </p>

                    <fieldset>
                        <legend>1. Datos del Estudiante</legend>
                        <div class="grid-2">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="nombres">Nombres <span class="req">*</span></label>
                                <input type="text" class="campo" id="nombres" name="nombres" maxlength="150" required>
                                <small class="campo-error" data-error-for="nombres"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="apellidos">Apellidos <span class="req">*</span></label>
                                <input type="text" class="campo" id="apellidos" name="apellidos" maxlength="150" required>
                                <small class="campo-error" data-error-for="apellidos"></small>
                            </div>
                        </div>
                        <div class="grid-3">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="fecha_nacimiento">Fecha de nacimiento <span class="req">*</span></label>
                                <input type="date" class="campo" id="fecha_nacimiento" name="fecha_nacimiento" required>
                                <small class="campo-error" data-error-for="fecha_nacimiento"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="genero">Género <span class="req">*</span></label>
                                <select name="genero" id="genero" class="campo" required>
                                    <option value="">Seleccione...</option>
                                    <option value="M">Masculino</option>
                                    <option value="F">Femenino</option>
                                </select>
                                <small class="campo-error" data-error-for="genero"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="seccion_id">Sección / Grado</label>
                                <select name="seccion_id" id="seccion_id" class="campo">
                                    <option value="">Sin asignar</option>
                                    <?php foreach ($secciones as $s): ?>
                                        <option value="<?= (int)$s['id'] ?>">
                                            <?= $e($s['grado'] . '° Grado - Sección ' . $s['seccion']) ?>
                                            (<?= $e($s['periodo']) ?><?= $s['periodo_estado'] === 'activo' ? '' : ' - cerrado' ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="campo-error" data-error-for="seccion_id"></small>
                            </div>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>2. Datos del Representante</legend>
                        <div class="grid-3">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="representante_cedula">Cédula <span class="req">*</span></label>
                                <input type="text" class="campo" id="representante_cedula" name="representante_cedula"
                                       inputmode="numeric" maxlength="10" placeholder="Solo números" required>
                                <small class="campo-error" data-error-for="representante_cedula"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="rep_nombre">Nombres <span class="req">*</span></label>
                                <input type="text" class="campo" id="rep_nombre" name="rep_nombre" maxlength="150" required>
                                <small class="campo-error" data-error-for="rep_nombre"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="rep_apellido">Apellidos <span class="req">*</span></label>
                                <input type="text" class="campo" id="rep_apellido" name="rep_apellido" maxlength="150" required>
                                <small class="campo-error" data-error-for="rep_apellido"></small>
                            </div>
                        </div>
                        <div class="grid-2">
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="rep_telefono">Teléfono <span class="req">*</span></label>
                                <input type="tel" class="campo" id="rep_telefono" name="rep_telefono" maxlength="20" required>
                                <small class="campo-error" data-error-for="rep_telefono"></small>
                            </div>
                            <div class="campo-grupo">
                                <label class="campo-etiqueta" for="rep_direccion">Dirección <span class="req">*</span></label>
                                <input type="text" class="campo" id="rep_direccion" name="rep_direccion" maxlength="500" required>
                                <small class="campo-error" data-error-for="rep_direccion"></small>
                            </div>
                        </div>
                        <p class="form-nota" id="notaRepresentante" hidden></p>
                    </fieldset>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardar">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="modal-backdrop" id="modalVerRepresentante" role="dialog" aria-modal="true" aria-labelledby="tituloModalRep">
        <div class="modal-content modal-sm">
            <div class="modal-header">
                <strong id="tituloModalRep">Información del Representante</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>
            <div class="modal-body detalle">
                <p><strong>Cédula:</strong> <span id="verRepCedula"></span></p>
                <p><strong>Nombre completo:</strong> <span id="verRepNombre"></span></p>
                <p><strong>Teléfono:</strong> <span id="verRepTelefono"></span></p>
                <p><strong>Dirección:</strong> <span id="verRepDireccion"></span></p>
                <p><strong>Hijos registrados:</strong> <span class="insignia-pildora insignia-primaria" id="verRepHijos">0</span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="boton boton-contorno-secundario boton-sm" data-cerrar-modal>Cerrar</button>
            </div>
        </div>
    </div>

    <script src="<?= $e($assetsUrl) ?>/js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>/js/estudiante.js"></script>
    

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>