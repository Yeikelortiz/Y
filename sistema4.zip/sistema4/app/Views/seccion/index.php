<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$etiquetaDocente = static fn(array $d): string => $d['apellidos'] . ' ' . $d['nombres'] . ' (C.I. ' . $d['cedula'] . ')';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secciones | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/representantes.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/secciones.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-gestionar="<?= $puedeGestionar ? '1' : '0' ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index">
            🏫 E.B. Olimpia Barrios
        </a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $e($baseUrl) ?>index.php?controller=<?= $e($panel) ?>&amp;action=index" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!$puedeGestionar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura: puedes consultar las secciones y sus estudiantes.</div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Secciones</h1>
                <p class="page-subtitle">Grados, docentes titulares y estudiantes por sección</p>
            </div>

            <div class="search-group">
                <label class="campo-etiqueta filtro-etiqueta" for="filtroPeriodo">Período</label>
                <select id="filtroPeriodo" class="campo">
                    <option value="0">Todos los períodos</option>
                    <?php foreach ($periodos as $p): ?>
                        <option value="<?= (int)$p['id'] ?>" <?= (int)$p['id'] === (int)$periodoInicial ? 'selected' : '' ?>>
                            <?= $e($p['nombre']) ?><?= $p['estado'] === 'activo' ? '' : ' (cerrado)' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php if ($puedeGestionar): ?>
                <button type="button" class="boton boton-primario" id="btnNuevaSeccion">+ Nueva Sección</button>
            <?php endif; ?>
        </div>

        <section class="tarjeta">
            <div class="tarjeta-cabecera">
                <strong>Secciones Registradas</strong>
                <span class="insignia-pildora insignia-primaria">Total: <span id="contadorTotal">0</span> secciones</span>
            </div>

            <div class="tabla-responsive">
                <table id="tablaSecciones">
                    <thead>
                        <tr>
                            <th>Sección</th>
                            <th>Período</th>
                            <th>Docente titular</th>
                            <th>Aula</th>
                            <th>Horario</th>
                            <th>Estudiantes</th>
                            <?php if ($puedeGestionar): ?><th class="u-der">Acciones</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTabla"></tbody>
                </table>
            </div>

            <div id="estadoTabla" class="estado-tabla" role="status">Cargando secciones...</div>
        </section>
    </main>

    <div class="modal-backdrop" id="modalEstudiantes" role="dialog" aria-modal="true" aria-labelledby="tituloEstudiantes">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloEstudiantes">Estudiantes de la sección</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>
            <div class="modal-body">
                <div class="info-grid">
                    <div><span class="info-etiqueta">Sección</span><span id="estSeccion"></span></div>
                    <div><span class="info-etiqueta">Período</span><span id="estPeriodo"></span></div>
                    <div><span class="info-etiqueta">Docente titular</span><span id="estDocente"></span></div>
                    <div><span class="info-etiqueta">Aula / Horario</span><span id="estAulaHorario"></span></div>
                </div>

                <div class="seccion-hijos">
                    <div class="seccion-hijos-cabecera">
                        <strong>Estudiantes inscritos <span class="insignia-pildora insignia-primaria" id="estTotal">0</span></strong>
                    </div>

                    <div class="tabla-responsive" id="estTablaWrap">
                        <table class="tabla-hijos">
                            <thead>
                                <tr>
                                    <th>Cédula Escolar</th>
                                    <th>Estudiante</th>
                                    <th>Edad</th>
                                    <th>Representante</th>
                                    <?php if ($puedeGestionar): ?><th class="u-der">Acción</th><?php endif; ?>
                                </tr>
                            </thead>
                            <tbody id="estLista"></tbody>
                        </table>
                    </div>

                    <div class="vacio" id="estVacio" hidden>
                        <p>Esta sección <strong>no tiene estudiantes inscritos</strong>.</p>
                    </div>

                    <?php if ($puedeGestionar): ?>
                    <div class="agregar-estudiante" id="bloqueAsignar" hidden>
                        <strong>Agregar estudiante a esta sección</strong>
                        <p class="form-nota" id="notaSinDisponibles" hidden>No hay estudiantes sin sección disponibles.</p>
                        <div class="fila-asignar" id="filaAsignar">
                            <input type="search" class="campo" id="filtroDisponibles" placeholder="Filtrar por nombre o cédula escolar..." aria-label="Filtrar estudiantes sin sección" autocomplete="off">
                            <select class="campo" id="selectDisponibles" aria-label="Estudiante sin sección"></select>
                            <button type="button" class="boton boton-primario boton-sm" id="btnAsignarEstudiante">Agregar</button>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="boton boton-contorno-secundario boton-sm" data-cerrar-modal>Cerrar</button>
            </div>
        </div>
    </div>

    <?php if ($puedeGestionar): ?>
    <div class="modal-backdrop" id="modalSeccion" role="dialog" aria-modal="true" aria-labelledby="tituloModalSeccion">
        <div class="modal-content modal-md">
            <div class="modal-header">
                <strong id="tituloModalSeccion">Nueva Sección</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formSeccion" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="id" id="seccionId" value="0">

                    <p class="form-nota">Los campos con <span class="req">*</span> son obligatorios. El docente titular puede asignarse después.</p>

                    <div class="campo-grupo">
                        <label class="campo-etiqueta" for="periodo_id">Período <span class="req">*</span></label>
                        <select class="campo" id="periodo_id" name="periodo_id">
                            <option value="">Seleccione...</option>
                            <?php foreach ($periodos as $p): ?>
                                <?php if ($p['estado'] === 'activo'): ?>
                                    <option value="<?= (int)$p['id'] ?>"><?= $e($p['nombre']) ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                        <small class="campo-error" data-error-for="periodo_id"></small>
                    </div>

                    <div class="grid-2">
                        <div class="campo-grupo">
                            <label class="campo-etiqueta" for="grado">Grado <span class="req">*</span></label>
                            <select class="campo" id="grado" name="grado">
                                <option value="">Seleccione...</option>
                                <?php for ($g = 1; $g <= 6; $g++): ?>
                                    <option value="<?= $g ?>"><?= $g ?>° Grado</option>
                                <?php endfor; ?>
                            </select>
                            <small class="campo-error" data-error-for="grado"></small>
                        </div>
                        <div class="campo-grupo">
                            <label class="campo-etiqueta" for="seccion">Sección <span class="req">*</span></label>
                            <select class="campo" id="seccion" name="seccion">
                                <option value="">Seleccione...</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                            </select>
                            <small class="campo-error" data-error-for="seccion"></small>
                        </div>
                    </div>

                    <div class="campo-grupo">
                        <label class="campo-etiqueta" for="docente_id">Docente titular</label>
                        <select class="campo" id="docente_id" name="docente_id">
                            <option value="">Sin docente (asignar después)</option>
                            <?php foreach ($docentes as $d): ?>
                                <option value="<?= (int)$d['id'] ?>"><?= $e($etiquetaDocente($d)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="campo-error" data-error-for="docente_id"></small>
                    </div>

                    <div class="grid-2">
                        <div class="campo-grupo">
                            <label class="campo-etiqueta" for="aula">Aula</label>
                            <input type="text" class="campo" id="aula" name="aula" maxlength="30">
                            <small class="campo-error" data-error-for="aula"></small>
                        </div>
                        <div class="campo-grupo">
                            <label class="campo-etiqueta" for="horario">Horario</label>
                            <input type="text" class="campo" id="horario" name="horario" maxlength="100" placeholder="Ej. 7:00 am - 12:00 m">
                            <small class="campo-error" data-error-for="horario"></small>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardarSeccion">Guardar</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal-backdrop" id="modalDocente" role="dialog" aria-modal="true" aria-labelledby="tituloDocente">
        <div class="modal-content modal-sm">
            <div class="modal-header">
                <strong id="tituloDocente">Docente titular</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formDocente" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="seccion_id" id="docenteSeccionId" value="">
                    <p class="form-nota" id="docenteContexto"></p>

                    <div class="campo-grupo">
                        <label class="campo-etiqueta" for="docente_asignar">Docente <span class="req">*</span></label>
                        <select class="campo" id="docente_asignar" name="docente_id">
                            <option value="">Seleccione un docente...</option>
                            <?php foreach ($docentes as $d): ?>
                                <option value="<?= (int)$d['id'] ?>"><?= $e($etiquetaDocente($d)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="campo-error" data-error-for="docente_id"></small>
                    </div>
                    <?php if (!$docentes): ?>
                        <p class="form-nota">No hay docentes registrados todavía.</p>
                    <?php endif; ?>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardarDocente">Asignar</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/seccion.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
