<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión | Mi Plataforma</title>

    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
    <link rel="stylesheet" href="/sistema4/assets/css/login.css?v=20261028-1">
    <!-- Animate.css para las animaciones de SweetAlert2 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
</head>

<body class="login-body">

    <main class="login-main">
        <div class="login-card">

            <!-- Logo en la esquina superior izquierda -->
            <img class="login-logo" src="/sistema4/assets/img/Logo.jpg" alt="Logo de la institución">

            <div class="login-contenido">

                <div class="login-encabezado">
                    <i class="icono icono-mortarboard-fill login-icono" aria-hidden="true"></i>
                    <h1 class="login-titulo">Iniciar Sesión</h1>
                    <p class="login-subtitulo">Ingresa tus credenciales para acceder</p>
                </div>

                <?php 
                if (!isset($error)) {
                    $error = $_SESSION['flash_error'] ?? null;
                    if (isset($_SESSION['flash_error'])) {
                        unset($_SESSION['flash_error']);
                    }
                }
                ?>

                <!-- Elemento que lee JavaScript para mostrar el SweetAlert2 -->
                <?php if (!empty($error)): ?>
                <div id="error-card" class="login-error" role="alert" style="display:none;">
                    <span><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <?php endif; ?>

                <!-- Formulario -->
                <form action="index.php?controller=auth&action=authenticate" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                    <!-- Seleccionar Rol -->
                    <div class="login-campo">
                        <label for="rol">Rol de usuario</label>
                        <div class="login-entrada">
                            <i class="icono icono-person-badge" aria-hidden="true"></i>
                            <select id="rol" name="rol" required>
                                <option value="" disabled <?php echo empty($rolSeleccionado) ? 'selected' : ''; ?>>Seleccione su rol</option>
                                <?php foreach (['admin' => 'Administrador', 'director' => 'Director', 'secretaria' => 'Secretaria'] as $valor => $texto): ?>
                                    <option value="<?php echo htmlspecialchars($valor, ENT_QUOTES, 'UTF-8'); ?>" <?php echo ($rolSeleccionado ?? '') === $valor ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($texto, ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="login-campo">
                        <label for="email">Correo electrónico</label>
                        <div class="login-entrada">
                            <i class="icono icono-envelope" aria-hidden="true"></i>
                            <input id="email" type="email" required
                                   name="email"
                                   placeholder="correo@ejemplo.com"
                                   autocomplete="username"
                                   maxlength="100">
                        </div>
                        <span class="login-ayuda-error">Formato de correo inválido</span>
                    </div>

                    <!-- Password -->
                    <div class="login-campo">
                        <label for="password">Contraseña</label>
                        <div class="login-entrada">
                            <i class="icono icono-lock" aria-hidden="true"></i>
                            <input id="password" type="password" required
                                   name="password"
                                   placeholder="••••••••"
                                   autocomplete="current-password"
                                   minlength="6"
                                   maxlength="128">
                        </div>
                    </div>

                    <button type="submit" class="login-boton">
                        Entrar
                    </button>

                </form>

            </div>
        </div>
    </main>

    <!-- Scripts externos -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="/sistema4/assets/js/login.js?v=20261028-3"></script>

</body>

</html>