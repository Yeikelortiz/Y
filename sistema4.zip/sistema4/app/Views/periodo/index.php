<?php
$e = static fn($v): string => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$urlPanel = $e($baseUrl) . 'index.php?controller=' . $e($panel) . '&amp;action=index';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Períodos Académicos | E.B. Olimpia Barrios</title>
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/estudiantes.css?v=20261028-6">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/periodos.css">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/app.css?v=20261028-7">
    <link rel="stylesheet" href="<?= $e($assetsUrl) ?>css/vistas-referencia.css?v=20261028-12">
</head>
<body class="rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>"
    data-base-url="<?= $e($baseUrl) ?>"
    data-csrf="<?= $e($csrfToken) ?>"
    data-puede-gestionar="<?= $puedeGestionar ? '1' : '0' ?>"
    data-puede-reabrir="<?= $puedeReabrir ? '1' : '0' ?>">

    <nav class="barra-nav barra-rol-<?= $e(strtolower((string)($panel ?? 'admin'))) ?>">
        <a class="barra-marca" href="<?= $urlPanel ?>">🏫 E.B. Olimpia Barrios</a>
        <div class="barra-menu">
            <span class="barra-usuario">
                <?= $e($nombreUsuario) ?>
                <span class="insignia-rol"><?= $e($rolVisual) ?></span>
            </span>
            <a href="<?= $urlPanel ?>" class="boton boton-contorno-claro boton-sm">Panel</a>
            <a href="<?= $e($baseUrl) ?>index.php?controller=auth&amp;action=logout" class="boton boton-contorno-claro boton-sm btn-salir">Salir</a>
        </div>
    </nav>

    <main class="contenedor">

        <?php if (!$puedeGestionar): ?>
            <div class="alert-info-box">Tu rol tiene acceso de solo lectura: puedes consultar los períodos y el estado de sus momentos.</div>
        <?php elseif (!$puedeReabrir): ?>
            <div class="alert-info-box">
                <strong>Director:</strong> puedes crear períodos y cerrar sus momentos. Reabrir un período o un momento cerrado
                (y eliminar períodos) está reservado al administrador.
            </div>
        <?php endif; ?>

        <div class="row-header">
            <div>
                <h1 class="page-title">Períodos Académicos</h1>
                <p class="page-subtitle">Años escolares y cierre de sus momentos (1er, 2do y 3er Momento)</p>
            </div>

            <div class="search-group">
                <input type="search" class="campo" id="inputBusqueda" maxlength="20"
                       placeholder="Buscar período (ej. 2026-2027)..." autocomplete="off" aria-label="Buscar período">
            </div>

            <div class="acciones-cabecera">
                <a class="boton boton-contorno-secundario" data-volver href="<?= $urlPanel ?>">← Volver</a>
                <?php if ($puedeGestionar): ?>
                    <button type="button" class="boton boton-primario" id="btnNuevoPeriodo">+ Nuevo Período</button>
                <?php endif; ?>
            </div>
        </div>

        <section class="tarjeta">
            <div class="tarjeta-cabecera">
                <strong>Listado de Períodos</strong>
                <span class="insignia-pildora insignia-primaria">Total: <span id="contadorTotal">0</span></span>
            </div>

            <div class="tabla-responsive">
                <table id="tablaPeriodos">
                    <thead>
                        <tr>
                            <th>Año escolar</th>
                            <th>Estado</th>
                            <th>Secciones</th>
                            <th>Momentos cerrados</th>
                            <th class="u-der">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTabla"></tbody>
                </table>
            </div>
            <div id="estadoTabla" class="estado-tabla" role="status">Cargando períodos...</div>
        </section>

        <p class="form-nota nota-reglas">
            <strong>Cierre de momentos:</strong> al cerrar un momento se bloquea la modificación de sus calificaciones y de su
            asistencia. Los momentos se cierran en orden (1er → 2do → 3er).
        </p>
    </main>

    <div class="modal-backdrop" id="modalPeriodo" role="dialog" aria-modal="true" aria-labelledby="tituloModalPeriodo">
        <div class="modal-content modal-sm">
            <div class="modal-header">
                <strong id="tituloModalPeriodo">Nuevo Período Académico</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <form id="formPeriodo" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="id" id="periodoId" value="0">

                    <div class="campo-grupo">
                        <label class="campo-etiqueta" for="periodoNombre">Año escolar (AAAA-AAAA) <span class="req">*</span></label>
                        <input type="text" class="campo" id="periodoNombre" name="nombre" maxlength="9"
                               placeholder="Ej. 2026-2027" inputmode="numeric" autocomplete="off">
                        <small class="campo-error" data-error-for="nombre"></small>
                    </div>
                    <p class="form-nota" id="notaNuevoPeriodo">
                        Se crea activo, con sus tres momentos (1er, 2do y 3er). Solo puede haber un período activo a la vez.
                    </p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="boton boton-contorno-secundario" data-cerrar-modal>Cancelar</button>
                    <button type="submit" class="boton boton-primario" id="btnGuardarPeriodo">Guardar</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal-backdrop" id="modalMomentos" role="dialog" aria-modal="true" aria-labelledby="tituloMomentos">
        <div class="modal-content">
            <div class="modal-header">
                <strong id="tituloMomentos">Momentos académicos</strong>
                <button type="button" class="modal-close-btn" data-cerrar-modal aria-label="Cerrar">&times;</button>
            </div>

            <div class="modal-body">
                <p class="estado-lista" id="avisoPeriodo" role="status"></p>

                <ul class="lista-momentos" id="listaMomentos"></ul>

                <div class="vacio" id="momentosVacio" hidden>
                    <p>Este período <strong>no tiene momentos académicos</strong>, por eso no se puede calificar.</p>
                    <?php if ($puedeGestionar): ?>
                        <button type="button" class="boton boton-primario boton-sm" id="btnCrearMomentos">➕ Crear los 3 momentos</button>
                    <?php endif; ?>
                </div>

                <p class="form-nota">
                    <strong>Cerrar un momento</strong> bloquea la modificación de sus calificaciones y de su asistencia.
                </p>
            </div>

            <div class="modal-footer">
                <button type="button" class="boton boton-contorno-secundario boton-sm" data-cerrar-modal>Cerrar ventana</button>
            </div>
        </div>
    </div>

    <script src="<?= $e($assetsUrl) ?>js/sweetalert2@11.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/comun.js"></script>
    <script src="<?= $e($assetsUrl) ?>js/periodo.js"></script>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>
