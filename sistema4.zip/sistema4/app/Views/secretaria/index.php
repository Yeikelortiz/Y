<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$nombreMostrar = $nombreUsuario ?? $_SESSION['usuario_nombre'] ?? $_SESSION['usuario'] ?? 'Secretaria';
$mensajeError  = $mensajeError ?? $_SESSION['mensajeError'] ?? null;
$mensajeExito  = $mensajeExito ?? $_SESSION['mensajeExito'] ?? null;

unset($_SESSION['mensajeError'], $_SESSION['mensajeExito']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Secretaría | E.B. Olimpia Barrios</title>

<link rel="stylesheet" href="/sistema4/assets/css/secretaria.css">
    <link rel="stylesheet" href="/sistema4/assets/css/vistas-referencia.css?v=20261028-12">

    <style>
        /* Estilos de realce de color para la barra lateral de secretaría */
        aside.sidebar {
            background: linear-gradient(180deg, #134e5e 0%, #203a43 50%, #0f2027 100%) !important;
            border-right: 1px solid rgba(13, 202, 240, 0.2);
        }
        aside.sidebar .nav-link {
            transition: all 0.3s ease;
            border-radius: 0.375rem;
            margin-bottom: 2px;
        }
        aside.sidebar .nav-link:hover {
            background-color: rgba(13, 202, 240, 0.15);
            color: #ffffff !important;
            transform: translateX(4px);
        }
        aside.sidebar .nav-link.active {
            background-color: rgba(13, 202, 240, 0.25) !important;
            color: #ffffff !important;
            border: 1px solid rgba(13, 202, 240, 0.5);
        }
        .user-card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(13, 202, 240, 0.25);
            border-radius: 0.5rem;
        }
    </style>
    <link rel="stylesheet" href="/sistema4/assets/css/app.css?v=20261028-7">
</head>
<body class="rol-secretaria">

    <div class="contenedor-fluido">
        <div class="rejilla">
            
            <aside class="rj-12 rj-md-3 rj-lg-2 sidebar u-t-blanco u-p-3 u-flex u-columna u-entre u-sombra u-fijo-arriba u-alto-pantalla">
                <div>
                    <div class="u-flex u-alinea-centro u-entre u-mb-3 u-t-blanco u-sin-subrayado u-borde-b u-borde-info u-borde-op-50 u-pb-3 u-px-1">
                        <div class="u-flex u-alinea-centro">
                            <i class="icono icono-building-fill-check u-fs-3 u-me-2 u-t-info"></i>
                            <span class="u-negrita u-fs-6 u-espaciado u-t-info">E.B. Olimpia Barrios</span>
                        </div>
                        <button class="boton boton-sm u-t-blanco u-md-oculto" type="button" data-menu-toggle="sidebarMenu"  aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="icono icono-list u-fs-4"></i>
                        </button>
                    </div>

                    <div class="colapsable u-md-bloque" id="sidebarMenu">
                        <div class="user-card u-p-3 u-mb-4 u-flex u-alinea-centro u-sombra-sm">
                            <div class="u-circulo u-t-blanco u-flex u-alinea-centro u-centrado u-me-3 u-no-encoger avatar-usuario avatar-cian">
                                <i class="icono icono-person-workspace u-fs-5 u-t-oscuro"></i>
                            </div>
                            <div class="u-lh-sm u-sin-desborde">
                                <span class="u-bloque u-seminegrita u-truncar u-pequeno u-t-blanco" title="<?= htmlspecialchars($nombreMostrar) ?>">
                                    <?= htmlspecialchars($nombreMostrar) ?>
                                </span>
                                <span class="insignia u-fs-xs u-f-info u-t-oscuro u-borde u-borde-info u-mt-1 u-negrita">
                                    Secretaría
                                </span>
                            </div>
                        </div>

                        <nav class="menu menu-pildoras u-columna u-gap-1">
                            <a href="index.php?controller=secretaria&action=index" class="menu-enlace u-t-blanco active">
                                <i class="icono icono-speedometer2 u-me-2 u-t-info"></i> Inicio
                            </a>
                            <a href="index.php?controller=estudiante&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-mortarboard-fill u-me-2 u-t-info"></i> Lista de Estudiantes
                            </a>
                            <a href="index.php?controller=representante&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-person-lines-fill u-me-2 u-t-exito"></i> Lista de Representantes
                            </a>
                            <a href="index.php?controller=docente&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-person-badge-fill u-me-2 u-t-exito"></i> Lista de Docentes
                            </a>
                            <a href="index.php?controller=seccion&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-door-open-fill u-me-2 u-t-peligro"></i> Secciones
                            </a>
                            <a href="index.php?controller=periodo&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-calendar-range-fill u-me-2 u-t-info"></i> Períodos Académicos
                            </a>
                            <a href="index.php?controller=asistencia&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-check2-square u-me-2 u-t-aviso"></i> Control Asistencia
                            </a>
                            <a href="index.php?controller=calificacion&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-journal-bookmark-fill u-me-2 u-t-secundario"></i> Calificaciones
                            </a>
                            <a href="index.php?controller=boletin&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-file-earmark-check u-me-2 u-t-exito"></i> Revisión de Boletines
                            </a>
                            <a href="index.php?controller=reporte&action=index" class="menu-enlace u-t-blanco-50">
                                <i class="icono icono-graph-up-arrow u-me-2 u-t-info"></i> Reportes Generales
                            </a>
                        </nav>
                    </div>
                </div>

                <div class="u-pt-3 u-borde-t u-borde-info u-borde-op-25 u-mt-3">
                    <a href="index.php?controller=auth&action=logout" class="boton boton-contorno-peligro u-ancho-100 u-izq">
                        <i class="icono icono-box-arrow-right u-me-2"></i> Cerrar sesión
                    </a>
                </div>
            </aside>

            <main class="rj-12 rj-md-9 rj-lg-10 u-p-4 u-alto-pantalla u-f-claro">
                
                <div class="u-flex u-columna u-sm-fila u-entre u-sm-alinea-centro u-gap-3 u-mb-4 u-pb-3 u-borde-b">
                    <div>
                        <h1 class="u-h4 u-negrita u-mb-1 u-t-oscuro">Panel Operativo - Secretaría</h1>
                        <p class="u-t-suave u-pequeno u-mb-0">Bienvenida, <strong><?= htmlspecialchars($nombreMostrar) ?></strong>. Seleccione el trámite o módulo al que desea ingresar.</p>
                    </div>
                    <div>
                        <span class="insignia u-f-blanco u-t-secundario u-borde u-sombra-sm u-px-3 u-py-2 u-fs-6 u-normal">
                            <i class="icono icono-person-badge-fill u-t-info u-me-1"></i> Perfil: <strong>Secretaría</strong>
                        </span>
                    </div>
                </div>

                <?php if (!empty($mensajeError)): ?>
                    <div class="mensaje mensaje-peligro mensaje-cerrable u-mb-4 u-sombra-sm u-sin-borde u-borde-i u-borde-peligro u-borde-4" role="alert">
                        <div class="u-flex u-alinea-centro">
                            <i class="icono icono-exclamation-triangle-fill u-fs-5 u-me-2 u-t-peligro"></i>
                            <div><?= htmlspecialchars($mensajeError) ?></div>
                        </div>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($mensajeExito)): ?>
                    <div class="mensaje mensaje-exito mensaje-cerrable u-mb-4 u-sombra-sm u-sin-borde u-borde-i u-borde-exito u-borde-4" role="alert">
                        <div class="u-flex u-alinea-centro">
                            <i class="icono icono-check-circle-fill u-fs-5 u-me-2 u-t-exito"></i>
                            <div><?= htmlspecialchars($mensajeExito) ?></div>
                        </div>
                        <button type="button" class="boton-cerrar" data-cerrar-modal="" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="rejilla rejilla-g4">

                    <!-- 1. Lista de Estudiantes -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado-3">
                                            <i class="icono icono-mortarboard-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info u-borde u-borde-info-suave">Global</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Lista de Estudiantes</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Supervisar la lista global de alumnos matriculados y corregir incongruencias de datos.</p>
                                </div>
                                <a href="index.php?controller=estudiante&action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Ver Estudiantes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 2. Lista de Representantes -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado-3">
                                            <i class="icono icono-person-lines-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito u-borde u-borde-exito-suave">Módulo</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Lista de Representantes</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Administrar la lista de representantes, registrar nuevos tutores y datos de contacto.</p>
                                </div>
                                <a href="index.php?controller=representante&action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Ver Representantes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 3. Lista de Docentes -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado-3">
                                            <i class="icono icono-person-badge-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito u-borde u-borde-exito-suave">Académico</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Lista de Docentes</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Registrar maestros y profesores titulados, modificar datos de contacto e imparte asignaciones.</p>
                                </div>
                                <a href="index.php?controller=docente&action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Gestión de Docentes <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Secciones -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-peligro u-f-op-10 u-t-peligro u-p-2 u-redondeado-3">
                                            <i class="icono icono-door-open-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-peligro-suave u-t-peligro u-borde u-borde-peligro-suave">Aulas</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Secciones</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Configurar grados y secciones (1° a 6° A/B), asignar aulas, horarios y docentes titulares.</p>
                                </div>
                                <a href="index.php?controller=seccion&action=index" class="boton boton-contorno-peligro boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Administrar Secciones <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 5. Períodos Académicos -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado-3">
                                            <i class="icono icono-calendar-range-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info u-borde u-borde-info-suave">Estructura</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Períodos Académicos</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Aperturar años escolares (ej: 2026-2027), gestionar el estado de cierre y momentos lectivos.</p>
                                </div>
                                <a href="index.php?controller=periodo&action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Ver Períodos <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 6. Control Asistencia -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-aviso u-f-op-10 u-t-aviso u-p-2 u-redondeado-3">
                                            <i class="icono icono-check2-square u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-aviso-suave u-t-aviso u-borde u-borde-aviso-suave">Por momento</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Control Asistencia</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Registrar las asistencias e inasistencias de cada sección por momento académico y generar reportes.</p>
                                </div>
                                <a href="index.php?controller=asistencia&action=index" class="boton boton-contorno-aviso boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Tomar Asistencia <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 7. Calificaciones -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-secundario u-f-op-10 u-t-secundario u-p-2 u-redondeado-3">
                                            <i class="icono icono-journal-bookmark-fill u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-secundario-suave u-t-oscuro u-borde u-borde-secundario-suave">Evaluación</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Calificaciones</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Cargar boletines académicos por momentos, estados cuantitativos/cualitativos e incidencias.</p>
                                </div>
                                <a href="index.php?controller=calificacion&action=index" class="boton boton-contorno-secundario boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Cargar Calificaciones <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 8. Revisión de Boletines -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-exito u-f-op-10 u-t-exito u-p-2 u-redondeado-3">
                                            <i class="icono icono-file-earmark-check u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-exito-suave u-t-exito u-borde u-borde-exito-suave">Boletines</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Revisión de Boletines</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Revisar y validar el rendimiento evaluativo previo a la firma y sellado institucional.</p>
                                </div>
                                <a href="index.php?controller=boletin&action=index" class="boton boton-contorno-exito boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Revisar y Autorizar <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 9. Reportes Generales -->
                    <div class="rj-12 rj-sm-6 rj-xl-4">
                        <div class="tarjeta dashboard-card u-f-blanco u-sombra-sm u-alto-100">
                            <div class="tarjeta-cuerpo u-p-4 u-flex u-columna u-entre">
                                <div>
                                    <div class="u-flex u-alinea-centro u-entre u-mb-3">
                                        <div class="icon-shape u-f-info u-f-op-10 u-t-info u-p-2 u-redondeado-3">
                                            <i class="icono icono-graph-up-arrow u-fs-4"></i>
                                        </div>
                                        <span class="insignia u-f-info-suave u-t-info u-borde u-borde-info-suave">Métricas</span>
                                    </div>
                                    <h5 class="u-negrita u-t-oscuro u-mb-2">Reportes Generales</h5>
                                    <p class="u-t-suave u-pequeno u-mb-0">Consultar índices de rendimiento, matrículas consolidadas y estadísticas generales.</p>
                                </div>
                                <a href="index.php?controller=reporte&action=index" class="boton boton-contorno-info boton-sm u-ancho-100 u-mt-4 u-medio">
                                    Ver Estadísticas <i class="icono icono-arrow-right u-ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>

            </main>
        </div>
    </div>

<script>
/* Deja Cerrar sesión justo después del último enlace del menú, con separación moderada. */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('aside.sidebar').forEach(function (sidebar) {
    var logout = sidebar.querySelector('a[href*="controller=auth"][href*="action=logout"]');
    var nav = sidebar.querySelector('nav.nav, #sidebarMenu .nav, .sidebar-menu .nav');
    if (logout && nav) {
      var collapse = nav.closest('.collapse');
      (collapse || nav).insertAdjacentElement('afterend', logout);
    }
    if (logout) {
      logout.classList.add('sidebar-logout-visible');
      logout.style.marginTop = '14px';
    }
  });
});
</script>

</body>
</html>