<?php
class Estudiante
{
    private PDO $db;

    private const SELECT_LISTA = "
        SELECT
            e.id,
            e.cedula_escolar,
            e.nombres,
            e.apellidos,
            e.fecha_nacimiento,
            CASE WHEN e.fecha_nacimiento = '0000-00-00' THEN NULL
                 ELSE TIMESTAMPDIFF(YEAR, e.fecha_nacimiento, CURDATE()) END AS edad,
            e.genero,
            e.seccion_id,
            s.grado,
            s.seccion,
            CASE WHEN s.id IS NULL THEN NULL
                 ELSE CONCAT(s.grado, '° Grado - Sección ', s.seccion) END AS seccion_nombre,
            e.representante_cedula,
            r.nombre    AS rep_nombre,
            r.apellido  AS rep_apellido,
            r.telefono  AS rep_telefono,
            r.direccion AS rep_direccion
        FROM estudiantes e
        LEFT JOIN representantes r ON r.cedula = e.representante_cedula
        LEFT JOIN secciones s      ON s.id = e.seccion_id
    ";

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function listar(int $limite, int $offset, string $busqueda = ''): array
    {
        [$where, $params] = $this->filtroBusqueda($busqueda);

        $stmt = $this->db->prepare(
            self::SELECT_LISTA . $where . ' ORDER BY e.id DESC LIMIT :limite OFFSET :offset'
        );
        foreach ($params as $clave => $valor) {
            $stmt->bindValue($clave, $valor, PDO::PARAM_STR);
        }
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function contar(string $busqueda = ''): int
    {
        [$where, $params] = $this->filtroBusqueda($busqueda);

        $stmt = $this->db->prepare('SELECT COUNT(*) FROM estudiantes e ' . $where);
        $stmt->execute($params);

        return (int)$stmt->fetchColumn();
    }

    public function obtenerPorId(int $id): ?array
    {
        $stmt = $this->db->prepare(self::SELECT_LISTA . ' WHERE e.id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function obtenerSecciones(): array
    {
        $sql = "
            SELECT s.id, s.grado, s.seccion, p.nombre AS periodo, p.estado AS periodo_estado
            FROM secciones s
            INNER JOIN periodos p ON p.id = s.periodo_id
            ORDER BY (p.estado = 'activo') DESC, p.id DESC, s.grado ASC, s.seccion ASC
        ";

        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerRepresentantePorCedula(string $cedula): ?array
    {
        $sql = "
            SELECT r.cedula, r.nombre, r.apellido, r.telefono, r.direccion,
                   (SELECT COUNT(*) FROM estudiantes e WHERE e.representante_cedula = r.cedula) AS num_hijo
            FROM representantes r
            WHERE r.cedula = :cedula
            LIMIT 1
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':cedula' => $cedula]);

        $rep = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$rep) {
            return null;
        }
        $rep['num_hijo'] = (int)$rep['num_hijo'];

        return $rep;
    }

    
    public function registrar(array $d): array
    {
        return $this->enTransaccion(function () use ($d) {
            $this->validarSeccion($d['seccion_id']);
            $this->guardarRepresentante($d);

            $cedulaEscolar = $this->generarCedulaEscolar($d['representante_cedula']);

            $stmt = $this->db->prepare("
                INSERT INTO estudiantes
                    (cedula_escolar, nombres, apellidos, representante_cedula, fecha_nacimiento, genero, seccion_id)
                VALUES
                    (:cedula_escolar, :nombres, :apellidos, :representante_cedula, :fecha_nacimiento, :genero, :seccion_id)
            ");
            $stmt->execute([
                ':cedula_escolar'       => $cedulaEscolar,
                ':nombres'              => $d['nombres'],
                ':apellidos'            => $d['apellidos'],
                ':representante_cedula' => $d['representante_cedula'],
                ':fecha_nacimiento'     => $d['fecha_nacimiento'],
                ':genero'               => $d['genero'],
                ':seccion_id'           => $d['seccion_id'],
            ]);
            $id = (int)$this->db->lastInsertId();

            $this->sincronizarNumHijos($d['representante_cedula']);

            return ['id' => $id, 'cedula_escolar' => $cedulaEscolar];
        });
    }

    public function actualizar(int $id, array $d): array
    {
        return $this->enTransaccion(function () use ($id, $d) {
            $stmt = $this->db->prepare('SELECT cedula_escolar, representante_cedula FROM estudiantes WHERE id = :id FOR UPDATE');
            $stmt->execute([':id' => $id]);
            $actual = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$actual) {
                throw new DomainException('El estudiante que intenta editar no existe.', 404);
            }

            $this->validarSeccion($d['seccion_id']);
            $this->guardarRepresentante($d);

            $repAnterior   = (string)$actual['representante_cedula'];
            $cambioRep     = $repAnterior !== $d['representante_cedula'];
            $cedulaEscolar = $cambioRep
                ? $this->generarCedulaEscolar($d['representante_cedula'])
                : $actual['cedula_escolar'];

            $stmt = $this->db->prepare("
                UPDATE estudiantes SET
                    cedula_escolar       = :cedula_escolar,
                    nombres              = :nombres,
                    apellidos            = :apellidos,
                    representante_cedula = :representante_cedula,
                    fecha_nacimiento     = :fecha_nacimiento,
                    genero               = :genero,
                    seccion_id           = :seccion_id
                WHERE id = :id
            ");
            $stmt->execute([
                ':id'                   => $id,
                ':cedula_escolar'       => $cedulaEscolar,
                ':nombres'              => $d['nombres'],
                ':apellidos'            => $d['apellidos'],
                ':representante_cedula' => $d['representante_cedula'],
                ':fecha_nacimiento'     => $d['fecha_nacimiento'],
                ':genero'               => $d['genero'],
                ':seccion_id'           => $d['seccion_id'],
            ]);

            $this->sincronizarNumHijos($d['representante_cedula']);
            if ($cambioRep) {
                $this->sincronizarNumHijos($repAnterior);
            }

            return ['id' => $id, 'cedula_escolar' => $cedulaEscolar];
        });
    }

    public function eliminar(int $id): bool
    {
        return $this->enTransaccion(function () use ($id) {
            $stmt = $this->db->prepare('SELECT representante_cedula FROM estudiantes WHERE id = :id FOR UPDATE');
            $stmt->execute([':id' => $id]);
            $rep = $stmt->fetchColumn();

            if ($rep === false) {
                return false;
            }

            $stmt = $this->db->prepare('DELETE FROM estudiantes WHERE id = :id');
            $stmt->execute([':id' => $id]);

            $this->sincronizarNumHijos((string)$rep);

            return $stmt->rowCount() > 0;
        });
    }

    public function porSeccion(int $seccionId): array
    {
        $stmt = $this->db->prepare("
            SELECT
                e.id,
                e.cedula_escolar,
                e.nombres,
                e.apellidos,
                e.genero,
                CASE WHEN e.fecha_nacimiento = '0000-00-00' THEN NULL
                     ELSE TIMESTAMPDIFF(YEAR, e.fecha_nacimiento, CURDATE()) END AS edad,
                e.representante_cedula,
                CONCAT(r.nombre, ' ', r.apellido) AS representante_nombre
            FROM estudiantes e
            LEFT JOIN representantes r ON r.cedula = e.representante_cedula
            WHERE e.seccion_id = :seccion
            ORDER BY e.apellidos ASC, e.nombres ASC
        ");
        $stmt->execute([':seccion' => $seccionId]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function sinSeccion(): array
    {
        return $this->db->query("
            SELECT id, cedula_escolar, nombres, apellidos
            FROM estudiantes
            WHERE seccion_id IS NULL
            ORDER BY apellidos ASC, nombres ASC
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function asignarSeccion(int $estudianteId, int $seccionId): bool
    {
        $stmt = $this->db->prepare('UPDATE estudiantes SET seccion_id = :seccion WHERE id = :id');

        return $stmt->execute([':seccion' => $seccionId, ':id' => $estudianteId]);
    }

    public function quitarSeccion(int $estudianteId): bool
    {
        $stmt = $this->db->prepare('UPDATE estudiantes SET seccion_id = NULL WHERE id = :id');

        return $stmt->execute([':id' => $estudianteId]);
    }

    private function guardarRepresentante(array $d): void
    {
        // Bloquea la fila del representante para serializar altas simultáneas de sus hijos
        $stmt = $this->db->prepare('SELECT cedula FROM representantes WHERE cedula = :cedula FOR UPDATE');
        $stmt->execute([':cedula' => $d['representante_cedula']]);
        $existe = $stmt->fetchColumn() !== false;

        $params = [
            ':cedula'    => $d['representante_cedula'],
            ':nombre'    => $d['rep_nombre'],
            ':apellido'  => $d['rep_apellido'],
            ':telefono'  => $d['rep_telefono'],
            ':direccion' => $d['rep_direccion'],
        ];

        if ($existe) {
            $sql = 'UPDATE representantes
                    SET nombre = :nombre, apellido = :apellido, telefono = :telefono, direccion = :direccion
                    WHERE cedula = :cedula';
        } else {
            $sql = 'INSERT INTO representantes (cedula, nombre, apellido, telefono, direccion, num_hijo)
                    VALUES (:cedula, :nombre, :apellido, :telefono, :direccion, 0)';
        }

        $this->db->prepare($sql)->execute($params);
    }

    // Se usa el máximo (y no un conteo) para no repetir números si se eliminó algún hijo
    private function generarCedulaEscolar(string $cedulaRep): string
    {
        $stmt = $this->db->prepare('SELECT cedula_escolar FROM estudiantes WHERE representante_cedula = :cedula');
        $stmt->execute([':cedula' => $cedulaRep]);

        $max = 0;
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $existente) {
            if (preg_match('/-(\d+)$/', (string)$existente, $m)) {
                $max = max($max, (int)$m[1]);
            }
        }

        $n = $max + 1;
        while ($this->existeCedulaEscolar($cedulaRep . '-' . $n)) {
            $n++;
        }

        return $cedulaRep . '-' . $n;
    }

    private function existeCedulaEscolar(string $cedulaEscolar): bool
    {
        $stmt = $this->db->prepare('SELECT 1 FROM estudiantes WHERE cedula_escolar = :ce LIMIT 1');
        $stmt->execute([':ce' => $cedulaEscolar]);

        return $stmt->fetchColumn() !== false;
    }

    private function sincronizarNumHijos(string $cedulaRep): void
    {
        $stmt = $this->db->prepare("
            UPDATE representantes
            SET num_hijo = (SELECT COUNT(*) FROM estudiantes WHERE representante_cedula = :c1)
            WHERE cedula = :c2
        ");
        $stmt->execute([':c1' => $cedulaRep, ':c2' => $cedulaRep]);
    }

    private function validarSeccion(?int $seccionId): void
    {
        if ($seccionId === null) {
            return;
        }
        $stmt = $this->db->prepare('SELECT 1 FROM secciones WHERE id = :id');
        $stmt->execute([':id' => $seccionId]);
        if ($stmt->fetchColumn() === false) {
            throw new DomainException('La sección seleccionada no existe.', 422);
        }
    }

    // Con ATTR_EMULATE_PREPARES = false un mismo marcador no puede repetirse, por eso cada LIKE usa su propio parámetro
    private function filtroBusqueda(string $busqueda): array
    {
        if ($busqueda === '') {
            return ['', []];
        }

        $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $busqueda) . '%';

        $where = " WHERE e.cedula_escolar LIKE :b1
                      OR e.nombres LIKE :b2
                      OR e.apellidos LIKE :b3
                      OR CONCAT(e.nombres, ' ', e.apellidos) LIKE :b4
                      OR e.representante_cedula LIKE :b5 ";

        return [$where, [':b1' => $like, ':b2' => $like, ':b3' => $like, ':b4' => $like, ':b5' => $like]];
    }

    private function enTransaccion(callable $operacion)
    {
        if ($this->db->inTransaction()) {
            return $operacion();
        }

        $this->db->beginTransaction();
        try {
            $resultado = $operacion();
            $this->db->commit();
            return $resultado;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }
}
