<?php
class Periodo
{
    public const MOMENTOS = ['1er Momento', '2do Momento', '3er Momento'];

    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function obtenerTodos(): array
    {
        $filas = $this->db->query("
            SELECT
                p.id, p.nombre, p.estado, p.created_at,
                (SELECT COUNT(*) FROM secciones s WHERE s.periodo_id = p.id) AS total_secciones,
                (SELECT COUNT(*) FROM momentos_academicos m WHERE m.periodo_id = p.id) AS total_momentos,
                (SELECT COUNT(*) FROM momentos_academicos m WHERE m.periodo_id = p.id AND m.estado = 'cerrado') AS momentos_cerrados
            FROM periodos p
            ORDER BY p.nombre DESC
        ")->fetchAll(PDO::FETCH_ASSOC);

        return array_map([$this, 'tiparPeriodo'], $filas);
    }

    public function obtenerPorId(int $id): ?array
    {
        $st = $this->db->prepare("
            SELECT p.id, p.nombre, p.estado, p.created_at,
                   (SELECT COUNT(*) FROM secciones s WHERE s.periodo_id = p.id) AS total_secciones,
                   (SELECT COUNT(*) FROM momentos_academicos m WHERE m.periodo_id = p.id) AS total_momentos,
                   (SELECT COUNT(*) FROM momentos_academicos m WHERE m.periodo_id = p.id AND m.estado = 'cerrado') AS momentos_cerrados
            FROM periodos p
            WHERE p.id = :id
        ");
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->tiparPeriodo($fila) : null;
    }

    public function obtenerActivo(): ?array
    {
        $fila = $this->db->query("SELECT id FROM periodos WHERE estado = 'activo' ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->obtenerPorId((int)$fila['id']) : null;
    }

    public function existeNombre(string $nombre, int $exceptoId = 0): bool
    {
        $st = $this->db->prepare('SELECT 1 FROM periodos WHERE nombre = :nombre AND id <> :id LIMIT 1');
        $st->execute([':nombre' => $nombre, ':id' => $exceptoId]);

        return $st->fetchColumn() !== false;
    }

    public function tieneSecciones(int $id): bool
    {
        $st = $this->db->prepare('SELECT 1 FROM secciones WHERE periodo_id = :id LIMIT 1');
        $st->execute([':id' => $id]);

        return $st->fetchColumn() !== false;
    }

    public function tieneCalificaciones(int $id): bool
    {
        $st = $this->db->prepare("
            SELECT 1 FROM calificaciones c
            INNER JOIN momentos_academicos m ON m.id = c.momento_id
            WHERE m.periodo_id = :id LIMIT 1
        ");
        $st->execute([':id' => $id]);

        return $st->fetchColumn() !== false;
    }

    public function momentos(int $periodoId): array
    {
        $st = $this->db->prepare("
            SELECT
                m.*,
                (SELECT COUNT(*) FROM calificaciones c WHERE c.momento_id = m.id) AS total_calificaciones,
                (SELECT COUNT(*)
                   FROM estudiantes e
                   INNER JOIN secciones s ON s.id = e.seccion_id
                  WHERE s.periodo_id = m.periodo_id
                    AND NOT EXISTS (SELECT 1 FROM calificaciones c2 WHERE c2.estudiante_id = e.id AND c2.momento_id = m.id)
                ) AS sin_calificar
            FROM momentos_academicos m
            WHERE m.periodo_id = :p
            ORDER BY m.id
        ");
        $st->execute([':p' => $periodoId]);

        return array_map([$this, 'tiparMomento'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public function momento(int $id): ?array
    {
        $st = $this->db->prepare('SELECT * FROM momentos_academicos WHERE id = :id');
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->tiparMomento($fila) : null;
    }

    public function cambiarEstadoMomento(int $id, string $estado): bool
    {
        $sql = $estado === 'cerrado'
            ? "UPDATE momentos_academicos SET estado = 'cerrado', fecha_cierre = CURDATE() WHERE id = :id"
            : "UPDATE momentos_academicos SET estado = 'activo', fecha_cierre = NULL WHERE id = :id";

        return $this->db->prepare($sql)->execute([':id' => $id]);
    }

    public function crearMomentosPorDefecto(int $periodoId): int
    {
        return $this->enTransaccion(function () use ($periodoId) {
            $st = $this->db->prepare('SELECT COUNT(*) FROM momentos_academicos WHERE periodo_id = :p FOR UPDATE');
            $st->execute([':p' => $periodoId]);
            if ((int)$st->fetchColumn() > 0) {
                return 0;
            }

            return $this->insertarMomentos($periodoId);
        });
    }

    public function crear(string $nombre): int
    {
        return $this->enTransaccion(function () use ($nombre) {
            $this->db->prepare("INSERT INTO periodos (nombre, estado) VALUES (:nombre, 'activo')")
                     ->execute([':nombre' => $nombre]);
            $id = (int)$this->db->lastInsertId();
            $this->insertarMomentos($id);

            return $id;
        });
    }

    public function renombrar(int $id, string $nombre): bool
    {
        return $this->db->prepare('UPDATE periodos SET nombre = :nombre WHERE id = :id')
                        ->execute([':nombre' => $nombre, ':id' => $id]);
    }

    public function cambiarEstado(int $id, string $estado): bool
    {
        return $this->enTransaccion(function () use ($id, $estado) {
            $this->db->prepare('UPDATE periodos SET estado = :estado WHERE id = :id')
                     ->execute([':estado' => $estado, ':id' => $id]);

            if ($estado === 'cerrado') {
                $this->db->prepare("
                    UPDATE momentos_academicos
                    SET estado = 'cerrado', fecha_cierre = CURDATE()
                    WHERE periodo_id = :id AND estado = 'activo'
                ")->execute([':id' => $id]);
            }

            return true;
        });
    }

    public function eliminar(int $id): bool
    {
        $st = $this->db->prepare('DELETE FROM periodos WHERE id = :id');
        $st->execute([':id' => $id]);

        return $st->rowCount() > 0;
    }

    private function insertarMomentos(int $periodoId): int
    {
        $st = $this->db->prepare("INSERT INTO momentos_academicos (periodo_id, nombre, estado) VALUES (:p, :nombre, 'activo')");
        foreach (self::MOMENTOS as $nombre) {
            $st->execute([':p' => $periodoId, ':nombre' => $nombre]);
        }

        return count(self::MOMENTOS);
    }

    private function tiparPeriodo(array $p): array
    {
        foreach (['id', 'total_secciones', 'total_momentos', 'momentos_cerrados'] as $campo) {
            $p[$campo] = (int)$p[$campo];
        }

        return $p;
    }

    private function tiparMomento(array $m): array
    {
        $m['id']                   = (int)$m['id'];
        $m['periodo_id']           = (int)$m['periodo_id'];
        $m['fecha_cierre']         = $m['fecha_cierre'] ?? null;
        $m['total_calificaciones'] = (int)($m['total_calificaciones'] ?? 0);
        $m['sin_calificar']        = (int)($m['sin_calificar'] ?? 0);

        return $m;
    }

    private function enTransaccion(callable $operacion)
    {
        if ($this->db->inTransaction()) {
            return $operacion();
        }

        $this->db->beginTransaction();
        try {
            $resultado = $operacion();
            $this->db->commit();
            return $resultado;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }
}
