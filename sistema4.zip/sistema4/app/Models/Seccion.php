<?php
class Seccion
{
    private PDO $db;

    private const SELECT = "
        SELECT
            s.*,
            COALESCE(p.nombre, 'Sin Período') AS periodo_nombre,
            COALESCE(p.estado, 'inactivo')    AS periodo_estado,
            COALESCE(CONCAT(d.nombres, ' ', d.apellidos), 'Sin Docente Titular') AS docente_nombre,
            d.cedula AS docente_cedula,
            (s.docente_id IS NULL) AS sin_docente,
            CONCAT(s.grado, '° Grado - Sección ', s.seccion) AS etiqueta,
            (SELECT COUNT(*) FROM estudiantes e WHERE e.seccion_id = s.id) AS total_estudiantes
        FROM secciones s
        LEFT JOIN periodos p ON p.id = s.periodo_id
        LEFT JOIN docentes d ON d.id = s.docente_id
    ";

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function obtenerTodos(?int $periodoId = null): array
    {
        if ($periodoId && $periodoId > 0) {
            $st = $this->db->prepare(self::SELECT . ' WHERE s.periodo_id = :p ORDER BY s.grado, s.seccion');
            $st->execute([':p' => $periodoId]);
        } else {
            $st = $this->db->query(self::SELECT . ' ORDER BY p.id DESC, s.grado, s.seccion');
        }

        return array_map([$this, 'normalizar'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public function obtenerTodas(?int $periodoId = null): array
    {
        return $this->obtenerTodos($periodoId);
    }

    public function obtenerPorId(int $id): ?array
    {
        $st = $this->db->prepare(self::SELECT . ' WHERE s.id = :id LIMIT 1');
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->normalizar($fila) : null;
    }

    public function existe(int $id): bool
    {
        $st = $this->db->prepare('SELECT 1 FROM secciones WHERE id = :id');
        $st->execute([':id' => $id]);

        return $st->fetchColumn() !== false;
    }

    public function paraSelect(): array
    {
        return $this->db->query("
            SELECT s.id, CONCAT(s.grado, '° Grado - Sección ', s.seccion) AS etiqueta
            FROM secciones s
            LEFT JOIN periodos p ON p.id = s.periodo_id
            WHERE p.estado = 'activo' OR p.id IS NULL
            ORDER BY s.grado, s.seccion
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function existeCombinacion(int $periodoId, int $grado, string $seccion, int $exceptoId = 0): bool
    {
        $st = $this->db->prepare(
            'SELECT 1 FROM secciones WHERE periodo_id = :p AND grado = :g AND seccion = :s AND id <> :id LIMIT 1'
        );
        $st->execute([':p' => $periodoId, ':g' => $grado, ':s' => $seccion, ':id' => $exceptoId]);

        return $st->fetchColumn() !== false;
    }

    public function contarEstudiantes(int $id): int
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM estudiantes WHERE seccion_id = :id');
        $st->execute([':id' => $id]);

        return (int)$st->fetchColumn();
    }

    public function contarAsistencias(int $id): int
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM asistencias_momento WHERE seccion_id = :id');
        $st->execute([':id' => $id]);

        return (int)$st->fetchColumn();
    }

    public function obtenerPeriodos(): array
    {
        return $this->db->query('SELECT id, nombre, estado FROM periodos ORDER BY id DESC')
                        ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerDocentes(): array
    {
        return $this->db->query('SELECT id, cedula, nombres, apellidos FROM docentes ORDER BY apellidos, nombres')
                        ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function existeDocente(int $id): bool
    {
        $st = $this->db->prepare('SELECT 1 FROM docentes WHERE id = :id');
        $st->execute([':id' => $id]);

        return $st->fetchColumn() !== false;
    }

    public function obtenerPeriodo(int $id): ?array
    {
        $st = $this->db->prepare('SELECT id, nombre, estado FROM periodos WHERE id = :id');
        $st->execute([':id' => $id]);

        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function guardar(int $id, array $d): int
    {
        $p = [
            ':p' => $d['periodo_id'],
            ':g' => $d['grado'],
            ':s' => $d['seccion'],
            ':d' => !empty($d['docente_id']) ? $d['docente_id'] : null,
            ':a' => !empty($d['aula']) ? $d['aula'] : null,
            ':h' => !empty($d['horario']) ? $d['horario'] : null,
        ];

        if ($id > 0) {
            $this->db->prepare(
                'UPDATE secciones SET periodo_id = :p, grado = :g, seccion = :s, docente_id = :d, aula = :a, horario = :h WHERE id = :id'
            )->execute($p + [':id' => $id]);

            return $id;
        }

        $this->db->prepare(
            'INSERT INTO secciones (periodo_id, grado, seccion, docente_id, aula, horario) VALUES (:p, :g, :s, :d, :a, :h)'
        )->execute($p);

        return (int)$this->db->lastInsertId();
    }

    public function asignarDocente(int $seccionId, ?int $docenteId): bool
    {
        $st = $this->db->prepare('UPDATE secciones SET docente_id = :d WHERE id = :id');
        $st->bindValue(':d', $docenteId, $docenteId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $st->bindValue(':id', $seccionId, PDO::PARAM_INT);

        return $st->execute();
    }

    public function eliminar(int $id): bool
    {
        $st = $this->db->prepare('DELETE FROM secciones WHERE id = :id');
        $st->execute([':id' => $id]);

        return $st->rowCount() > 0;
    }

    private function normalizar(array $s): array
    {
        $s['id']                = (int)$s['id'];
        $s['periodo_id']        = (int)$s['periodo_id'];
        $s['grado']             = (int)$s['grado'];
        $s['docente_id']        = $s['docente_id'] !== null ? (int)$s['docente_id'] : null;
        $s['sin_docente']       = $s['docente_id'] === null;
        $s['total_estudiantes'] = (int)$s['total_estudiantes'];

        return $s;
    }
}
