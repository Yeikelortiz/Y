<?php
class UserModel
{
    private PDO $pdo;

    public const ROLES = ['admin', 'director', 'secretaria'];

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function obtenerPorEmail(string $email)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM usuarios WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function actualizarUltimaSesion($id): bool
    {
        try {
            $stmt = $this->pdo->prepare('UPDATE usuarios SET ultima_sesion = NOW() WHERE id = :id');
            return $stmt->execute([':id' => (int)$id]);
        } catch (PDOException $e) {
            return false;
        }
    }
  

    public function obtenerUltimaSesion($id): ?string
    {
        try {
            $stmt = $this->pdo->prepare('SELECT ultima_sesion FROM usuarios WHERE id = :id');
            $stmt->execute([':id' => (int)$id]);
            $valor = $stmt->fetchColumn();

            return $valor !== false ? $valor : null;
        } catch (PDOException $e) {
            return null;
        }
    }

    // Suma un intento fallido; al llegar a 3 bloquea la cuenta 15 minutos
    public function registrarIntentoFallido(int $id, int $intentosActuales): int
    {
        $nuevos = $intentosActuales + 1;

        $sql = $nuevos >= 3
            ? 'UPDATE usuarios SET intentos_fallidos = :intentos, bloqueado_hasta = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE id = :id'
            : 'UPDATE usuarios SET intentos_fallidos = :intentos WHERE id = :id';

        $this->pdo->prepare($sql)->execute([':intentos' => $nuevos, ':id' => $id]);

        return $nuevos;
    }

    public function reiniciarIntentos(int $id): void
    {
        $this->pdo->prepare('UPDATE usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = :id')
                  ->execute([':id' => $id]);
    }

    // ¿Está bloqueado el usuario? Se usa UNIX_TIMESTAMP en MySQL para evitar diferencias de zona horaria entre PHP y la base de datos
    public function verificarBloqueoUsuario(int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT UNIX_TIMESTAMP(bloqueado_hasta) AS bloqueo_ts FROM usuarios WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$fila || empty($fila['bloqueo_ts'])) {
            return ['bloqueado' => false, 'minutos_restantes' => 0];
        }

        $diferencia = (int)$fila['bloqueo_ts'] - time();
        if ($diferencia > 0) {
            return ['bloqueado' => true, 'minutos_restantes' => (int)ceil($diferencia / 60)];
        }

        return ['bloqueado' => false, 'minutos_restantes' => 0];
    }

    // `bloqueado` lo calcula MySQL (bloqueado_hasta > NOW()) para ser coherente con la zona horaria de la BD
    public function listar(string $busqueda = '', string $rol = ''): array
    {
        $condiciones = [];
        $params      = [];

        if ($busqueda !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $busqueda) . '%';
            $condiciones[] = '(nombre LIKE :b1 OR email LIKE :b2)';
            $params[':b1'] = $like;
            $params[':b2'] = $like;
        }
        if ($rol !== '') {
            $condiciones[] = 'rol = :rol';
            $params[':rol'] = $rol;
        }

        $sql = "
            SELECT id, nombre, email, rol, intentos_fallidos, bloqueado_hasta, created_at, ultima_sesion,
                   (bloqueado_hasta IS NOT NULL AND bloqueado_hasta > NOW()) AS bloqueado
            FROM usuarios
            " . ($condiciones ? 'WHERE ' . implode(' AND ', $condiciones) : '') . "
            ORDER BY created_at DESC, id DESC
        ";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);

        $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['id']       = (int)$fila['id'];
            $fila['bloqueado'] = (bool)$fila['bloqueado'];
        }

        return $filas;
    }

    public function obtenerTodos(): array
    {
        return $this->listar();
    }

    public function contarTotal(): int
    {
        return (int)$this->pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn();
    }

    public function contarPorRol(string $rol): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM usuarios WHERE rol = :rol');
        $stmt->execute([':rol' => $rol]);

        return (int)$stmt->fetchColumn();
    }

    public function obtenerPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT id, nombre, email, rol, created_at, ultima_sesion FROM usuarios WHERE id = :id');
        $stmt->execute([':id' => $id]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function emailExiste(string $email, int $exceptoId = 0): bool
    {
        $stmt = $this->pdo->prepare('SELECT 1 FROM usuarios WHERE email = :email AND id <> :id LIMIT 1');
        $stmt->execute([':email' => $email, ':id' => $exceptoId]);

        return $stmt->fetchColumn() !== false;
    }

    public function crearUsuario(string $nombre, string $email, string $passwordHash, string $rol = 'secretaria'): int
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO usuarios (nombre, email, password, rol, intentos_fallidos)
             VALUES (:nombre, :email, :password, :rol, 0)'
        );
        $stmt->execute([
            ':nombre'   => $nombre,
            ':email'    => $email,
            ':password' => $passwordHash,
            ':rol'      => $rol,
        ]);

        return (int)$this->pdo->lastInsertId();
    }

    public function actualizarUsuario(int $id, string $nombre, string $email, string $rol, ?string $passwordHash = null): bool
    {
        $sql = $passwordHash
            ? 'UPDATE usuarios SET nombre = :nombre, email = :email, rol = :rol, password = :password WHERE id = :id'
            : 'UPDATE usuarios SET nombre = :nombre, email = :email, rol = :rol WHERE id = :id';

        $params = [':nombre' => $nombre, ':email' => $email, ':rol' => $rol, ':id' => $id];
        if ($passwordHash) {
            $params[':password'] = $passwordHash;
        }

        return $this->pdo->prepare($sql)->execute($params);
    }

    public function eliminarUsuario(int $id): bool
    {
        $stmt = $this->pdo->prepare('DELETE FROM usuarios WHERE id = :id');
        $stmt->execute([':id' => $id]);

        return $stmt->rowCount() > 0;
    }
}
