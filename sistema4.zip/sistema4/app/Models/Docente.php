<?php
class Docente
{
    private PDO $db;

    private const SELECT_LISTA = "
        SELECT
            d.id,
            d.cedula,
            d.nombres,
            d.apellidos,
            d.fecha_nacimiento,
            d.genero,
            d.direccion,
            d.telefono,
            d.correo,
            (SELECT COUNT(*) FROM secciones s WHERE s.docente_id = d.id) AS total_secciones
        FROM docentes d
    ";

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function contar(string $busqueda = ''): int
    {
        [$where, $params] = $this->filtroBusqueda($busqueda);

        $st = $this->db->prepare('SELECT COUNT(*) FROM docentes d ' . $where);
        $st->execute($params);

        return (int)$st->fetchColumn();
    }

    public function paginados(int $limite, int $offset, string $busqueda = ''): array
    {
        [$where, $params] = $this->filtroBusqueda($busqueda);

        $st = $this->db->prepare(self::SELECT_LISTA . $where . ' ORDER BY d.apellidos, d.nombres LIMIT :limite OFFSET :offset');
        foreach ($params as $clave => $valor) {
            $st->bindValue($clave, $valor, PDO::PARAM_STR);
        }
        $st->bindValue(':limite', $limite, PDO::PARAM_INT);
        $st->bindValue(':offset', $offset, PDO::PARAM_INT);
        $st->execute();

        $filas = $st->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['id']                = (int)$fila['id'];
            $fila['total_secciones']   = (int)$fila['total_secciones'];
        }

        return $filas;
    }

    public function todos(): array
    {
        return $this->db->query('SELECT id, cedula, nombres, apellidos FROM docentes ORDER BY apellidos, nombres')
                        ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId(int $id): ?array
    {
        $st = $this->db->prepare(self::SELECT_LISTA . ' WHERE d.id = :id LIMIT 1');
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        if (!$fila) {
            return null;
        }
        $fila['id']              = (int)$fila['id'];
        $fila['total_secciones'] = (int)$fila['total_secciones'];

        return $fila;
    }

    public function existeCampo(string $campo, string $valor, int $exceptoId = 0): bool
    {
        // El nombre de columna no se puede enlazar como parámetro: se acepta solo de una lista fija
        if (!in_array($campo, ['cedula', 'correo'], true)) {
            return false;
        }

        $st = $this->db->prepare("SELECT 1 FROM docentes WHERE {$campo} = :valor AND id <> :id LIMIT 1");
        $st->execute([':valor' => $valor, ':id' => $exceptoId]);

        return $st->fetchColumn() !== false;
    }

    public function tieneSecciones(int $id): bool
    {
        return $this->contarSecciones($id) > 0;
    }

    public function contarSecciones(int $id): int
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM secciones WHERE docente_id = :id');
        $st->execute([':id' => $id]);

        return (int)$st->fetchColumn();
    }

    public function guardar(int $id, array $d): int
    {
        $p = [
            ':cedula'    => $d['cedula'],
            ':nombres'   => $d['nombres'],
            ':apellidos' => $d['apellidos'],
            ':fecha'     => $d['fecha_nacimiento'],
            ':genero'    => $d['genero'],
            ':direccion' => $d['direccion'] !== '' ? $d['direccion'] : null,
            ':telefono'  => $d['telefono'] !== '' ? $d['telefono'] : null,
            ':correo'    => $d['correo'],
        ];

        if ($id > 0) {
            $this->db->prepare("
                UPDATE docentes SET
                    cedula = :cedula, nombres = :nombres, apellidos = :apellidos,
                    fecha_nacimiento = :fecha, genero = :genero,
                    direccion = :direccion, telefono = :telefono, correo = :correo
                WHERE id = :id
            ")->execute($p + [':id' => $id]);

            return $id;
        }

        $this->db->prepare("
            INSERT INTO docentes (cedula, nombres, apellidos, fecha_nacimiento, genero, direccion, telefono, correo)
            VALUES (:cedula, :nombres, :apellidos, :fecha, :genero, :direccion, :telefono, :correo)
        ")->execute($p);

        return (int)$this->db->lastInsertId();
    }

    public function eliminar(int $id): bool
    {
        $st = $this->db->prepare('DELETE FROM docentes WHERE id = :id');
        $st->execute([':id' => $id]);

        return $st->rowCount() > 0;
    }

    
    private function filtroBusqueda(string $busqueda): array
    {
        if ($busqueda === '') {
            return ['', []];
        }

        $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $busqueda) . '%';

        $where = " WHERE d.cedula LIKE :b1
                      OR d.nombres LIKE :b2
                      OR d.apellidos LIKE :b3
                      OR CONCAT(d.nombres, ' ', d.apellidos) LIKE :b4
                      OR d.correo LIKE :b5 ";

        return [$where, [':b1' => $like, ':b2' => $like, ':b3' => $like, ':b4' => $like, ':b5' => $like]];
    }
}
