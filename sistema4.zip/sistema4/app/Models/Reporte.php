<?php
// Consultas de solo lectura para los reportes académicos y estadísticos

class Reporte
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function periodos(): array
    {
        $filas = $this->db->query('SELECT id, nombre, estado FROM periodos ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC);

        return array_map([$this, 'tiparId'], $filas);
    }

    public function periodo(int $id): ?array
    {
        $st = $this->db->prepare('SELECT id, nombre, estado FROM periodos WHERE id = :id');
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->tiparId($fila) : null;
    }

    public function periodoActivo(): ?array
    {
        $fila = $this->db->query("SELECT id, nombre, estado FROM periodos WHERE estado = 'activo' ORDER BY id DESC LIMIT 1")
                         ->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->tiparId($fila) : null;
    }

    public function seccionesDePeriodo(int $periodoId): array
    {
        $st = $this->db->prepare("
            SELECT s.id, s.grado, s.seccion,
                   CONCAT(s.grado, '° Grado - Sección ', s.seccion) AS etiqueta,
                   CASE WHEN d.id IS NULL THEN NULL ELSE CONCAT(d.nombres, ' ', d.apellidos) END AS docente
            FROM secciones s
            LEFT JOIN docentes d ON d.id = s.docente_id
            WHERE s.periodo_id = :p
            ORDER BY s.grado, s.seccion
        ");
        $st->execute([':p' => $periodoId]);

        return array_map([$this, 'tiparId'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public function momentosDePeriodo(int $periodoId): array
    {
        $st = $this->db->prepare('SELECT id, nombre, estado FROM momentos_academicos WHERE periodo_id = :p ORDER BY id');
        $st->execute([':p' => $periodoId]);

        return array_map([$this, 'tiparId'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public function listadoEstudiantes(int $periodoId, int $seccionId = 0): array
    {
        $sql = "
            SELECT
                e.cedula_escolar,
                e.apellidos,
                e.nombres,
                e.genero,
                e.fecha_nacimiento,
                CASE WHEN e.fecha_nacimiento = '0000-00-00' THEN NULL
                     ELSE TIMESTAMPDIFF(YEAR, e.fecha_nacimiento, CURDATE()) END AS edad,
                s.grado,
                s.seccion,
                CASE WHEN d.id IS NULL THEN NULL ELSE CONCAT(d.nombres, ' ', d.apellidos) END AS docente,
                CASE WHEN r.cedula IS NULL THEN NULL ELSE CONCAT(r.nombre, ' ', r.apellido) END AS representante,
                e.representante_cedula,
                r.telefono AS rep_telefono
            FROM estudiantes e
            INNER JOIN secciones s ON s.id = e.seccion_id
            LEFT JOIN docentes d ON d.id = s.docente_id
            LEFT JOIN representantes r ON r.cedula = e.representante_cedula
            WHERE s.periodo_id = :p
        ";
        $params = [':p' => $periodoId];

        if ($seccionId > 0) {
            $sql .= ' AND s.id = :sec';
            $params[':sec'] = $seccionId;
        }
        $sql .= ' ORDER BY s.grado, s.seccion, e.apellidos, e.nombres';

        return $this->consultar($sql, $params);
    }

    public function rendimiento(int $periodoId, int $momentoId = 0): array
    {
        $params = [':p' => $periodoId];
        $filtroMomento = '';
        if ($momentoId > 0) {
            $filtroMomento = ' AND m.id = :m';
            $params[':m'] = $momentoId;
        }

        $sql = "
            SELECT
                s.grado,
                s.seccion,
                CASE WHEN d.id IS NULL THEN NULL ELSE CONCAT(d.nombres, ' ', d.apellidos) END AS docente,
                m.nombre AS momento,
                COUNT(DISTINCT e.id) AS matricula,
                COALESCE(SUM(c.literal_o_estado = 'Aprobado'), 0)  AS aprobados,
                COALESCE(SUM(c.literal_o_estado = 'Reprobado'), 0) AS reprobados
            FROM secciones s
            INNER JOIN momentos_academicos m ON m.periodo_id = s.periodo_id{$filtroMomento}
            LEFT JOIN docentes d ON d.id = s.docente_id
            LEFT JOIN estudiantes e ON e.seccion_id = s.id
            LEFT JOIN calificaciones c ON c.estudiante_id = e.id AND c.momento_id = m.id
            WHERE s.periodo_id = :p
            GROUP BY s.id, s.grado, s.seccion, d.id, d.nombres, d.apellidos, m.id, m.nombre
            ORDER BY s.grado, s.seccion, m.id
        ";

        return $this->consultar($sql, $params);
    }

    public function reprobados(int $periodoId, int $momentoId = 0, int $seccionId = 0): array
    {
        $sql = "
            SELECT
                e.cedula_escolar,
                e.apellidos,
                e.nombres,
                s.grado,
                s.seccion,
                CASE WHEN d.id IS NULL THEN NULL ELSE CONCAT(d.nombres, ' ', d.apellidos) END AS docente,
                m.nombre AS momento,
                c.descripcion_desempeno AS descripcion,
                CASE WHEN r.cedula IS NULL THEN NULL ELSE CONCAT(r.nombre, ' ', r.apellido) END AS representante,
                r.telefono AS rep_telefono
            FROM calificaciones c
            INNER JOIN estudiantes e ON e.id = c.estudiante_id
            INNER JOIN secciones s ON s.id = e.seccion_id AND s.periodo_id = :p
            INNER JOIN momentos_academicos m ON m.id = c.momento_id AND m.periodo_id = s.periodo_id
            LEFT JOIN docentes d ON d.id = s.docente_id
            LEFT JOIN representantes r ON r.cedula = e.representante_cedula
            WHERE c.literal_o_estado = 'Reprobado'
        ";
        $params = [':p' => $periodoId];

        if ($momentoId > 0) {
            $sql .= ' AND m.id = :m';
            $params[':m'] = $momentoId;
        }
        if ($seccionId > 0) {
            $sql .= ' AND s.id = :sec';
            $params[':sec'] = $seccionId;
        }
        $sql .= ' ORDER BY s.grado, s.seccion, e.apellidos, e.nombres, m.id';

        return $this->consultar($sql, $params);
    }

    public function asistencias(int $periodoId, int $seccionId, int $momentoId = 0): array
    {
        $sql = "
            SELECT
                e.cedula_escolar,
                e.apellidos,
                e.nombres,
                s.grado,
                s.seccion,
                COALESCE(SUM(a.asistencias), 0)   AS asistencias,
                COALESCE(SUM(a.inasistencias), 0) AS inasistencias,
                COUNT(a.id) AS momentos
            FROM estudiantes e
            INNER JOIN secciones s ON s.id = e.seccion_id
            LEFT JOIN asistencias_momento a ON a.estudiante_id = e.id
                AND a.momento_id IN (SELECT m.id FROM momentos_academicos m WHERE m.periodo_id = :pm)"
            . ($momentoId > 0 ? ' AND a.momento_id = :m' : '') . "
            WHERE s.periodo_id = :p
        ";
        $params = [':pm' => $periodoId, ':p' => $periodoId];
        if ($momentoId > 0) {
            $params[':m'] = $momentoId;
        }

        if ($seccionId > 0) {
            $sql .= ' AND s.id = :sec';
            $params[':sec'] = $seccionId;
        }
        $sql .= '
            GROUP BY e.id, e.cedula_escolar, e.apellidos, e.nombres, s.grado, s.seccion
            ORDER BY s.grado, s.seccion, e.apellidos, e.nombres
        ';

        return $this->consultar($sql, $params);
    }

    private function consultar(string $sql, array $params): array
    {
        $st = $this->db->prepare($sql);
        $st->execute($params);

        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    private function tiparId(array $fila): array
    {
        $fila['id'] = (int)$fila['id'];

        return $fila;
    }
}
