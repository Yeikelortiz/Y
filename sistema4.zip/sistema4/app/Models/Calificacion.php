<?php
class Calificacion
{
    public const ESTADOS = ['Aprobado', 'Reprobado'];

    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function momento(int $id): ?array
    {
        $st = $this->db->prepare('SELECT id, periodo_id, nombre, estado FROM momentos_academicos WHERE id = :id');
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        return $fila ? $this->tiparMomento($fila) : null;
    }

    public function momentosPorPeriodo(int $periodoId): array
    {
        $st = $this->db->prepare('SELECT id, periodo_id, nombre, estado FROM momentos_academicos WHERE periodo_id = :p ORDER BY id');
        $st->execute([':p' => $periodoId]);

        return array_map([$this, 'tiparMomento'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public function crearMomentosPorDefecto(int $periodoId): int
    {
        $this->db->beginTransaction();
        try {
            $st = $this->db->prepare('SELECT COUNT(*) FROM momentos_academicos WHERE periodo_id = :p FOR UPDATE');
            $st->execute([':p' => $periodoId]);
            if ((int)$st->fetchColumn() > 0) {
                $this->db->rollBack();
                return 0;
            }

            $ins = $this->db->prepare("INSERT INTO momentos_academicos (periodo_id, nombre, estado) VALUES (:p, :nombre, 'activo')");
            $nombres = ['1er Momento', '2do Momento', '3er Momento'];
            foreach ($nombres as $nombre) {
                $ins->execute([':p' => $periodoId, ':nombre' => $nombre]);
            }
            $this->db->commit();

            return count($nombres);
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }

    public function cambiarEstadoMomento(int $momentoId, string $estado): void
    {
        $this->db->prepare('UPDATE momentos_academicos SET estado = :estado WHERE id = :id')
                 ->execute([':estado' => $estado, ':id' => $momentoId]);
    }

    public function porSeccionMomento(int $seccionId, int $momentoId): array
    {
        $st = $this->db->prepare("
            SELECT
                e.id,
                e.cedula_escolar,
                e.nombres,
                e.apellidos,
                e.genero,
                CASE WHEN e.fecha_nacimiento = '0000-00-00' THEN NULL
                     ELSE TIMESTAMPDIFF(YEAR, e.fecha_nacimiento, CURDATE()) END AS edad,
                c.literal_o_estado     AS estado,
                c.descripcion_desempeno AS descripcion
            FROM estudiantes e
            LEFT JOIN calificaciones c ON c.estudiante_id = e.id AND c.momento_id = :m
            WHERE e.seccion_id = :s
            ORDER BY e.apellidos, e.nombres
        ");
        $st->execute([':m' => $momentoId, ':s' => $seccionId]);

        $filas = $st->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['id'] = (int)$fila['id'];
        }

        return $filas;
    }

    public function registrosGuardados(int $seccionId, int $limite = 1500): array
    {
        $st = $this->db->prepare("
            SELECT m.id AS momento_id, m.nombre AS momento, e.cedula_escolar, e.nombres, e.apellidos,
                   c.literal_o_estado AS estado, c.descripcion_desempeno AS descripcion, c.updated_at AS actualizado
            FROM calificaciones c
            INNER JOIN estudiantes e ON e.id = c.estudiante_id
            INNER JOIN secciones s ON s.id = e.seccion_id
            INNER JOIN momentos_academicos m ON m.id = c.momento_id AND m.periodo_id = s.periodo_id
            WHERE e.seccion_id = :s
            ORDER BY m.id, e.apellidos, e.nombres
            LIMIT :limite
        ");
        $st->bindValue(':s', $seccionId, PDO::PARAM_INT);
        $st->bindValue(':limite', max(1, $limite), PDO::PARAM_INT);
        $st->execute();

        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public function idsEstudiantesDeSeccion(int $seccionId): array
    {
        $st = $this->db->prepare('SELECT id FROM estudiantes WHERE seccion_id = :s');
        $st->execute([':s' => $seccionId]);

        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    public function guardar(int $estudianteId, int $momentoId, string $estado, string $descripcion): void
    {
        $this->db->prepare("
            INSERT INTO calificaciones (estudiante_id, momento_id, literal_o_estado, descripcion_desempeno)
            VALUES (:e, :m, :estado, :descripcion)
            ON DUPLICATE KEY UPDATE
                literal_o_estado = VALUES(literal_o_estado),
                descripcion_desempeno = VALUES(descripcion_desempeno)
        ")->execute([':e' => $estudianteId, ':m' => $momentoId, ':estado' => $estado, ':descripcion' => $descripcion]);
    }

    // Guarda varias calificaciones en una sola transacción: o se guardan todas o ninguna
    public function guardarLote(int $momentoId, array $filas): int
    {
        $this->db->beginTransaction();
        try {
            foreach ($filas as [$estudianteId, $estado, $descripcion]) {
                $this->guardar($estudianteId, $momentoId, $estado, $descripcion);
            }
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return count($filas);
    }

    public function consolidadoSeccion(int $seccionId, int $periodoId): array
    {
        $momentos = $this->momentosPorPeriodo($periodoId);

        $st = $this->db->prepare("
            SELECT
                e.id, e.cedula_escolar, e.nombres, e.apellidos, e.genero,
                CASE WHEN e.fecha_nacimiento = '0000-00-00' THEN NULL
                     ELSE TIMESTAMPDIFF(YEAR, e.fecha_nacimiento, CURDATE()) END AS edad
            FROM estudiantes e
            WHERE e.seccion_id = :s
            ORDER BY e.apellidos, e.nombres
        ");
        $st->execute([':s' => $seccionId]);
        $estudiantes = $st->fetchAll(PDO::FETCH_ASSOC);

        $st = $this->db->prepare("
            SELECT c.estudiante_id, c.momento_id, c.literal_o_estado AS estado
            FROM calificaciones c
            INNER JOIN estudiantes e ON e.id = c.estudiante_id
            WHERE e.seccion_id = :s
        ");
        $st->execute([':s' => $seccionId]);

        $mapa = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $mapa[(int)$c['estudiante_id']][(int)$c['momento_id']] = $c['estado'];
        }

        foreach ($estudiantes as &$e) {
            $e['id']    = (int)$e['id'];
            $e['notas'] = $mapa[$e['id']] ?? [];
        }

        return ['momentos' => $momentos, 'estudiantes' => $estudiantes];
    }

    public function boletin(int $estudianteId, int $periodoId): array
    {
        $st = $this->db->prepare("
            SELECT m.id AS momento_id, m.nombre AS momento, m.estado AS momento_estado,
                   c.literal_o_estado AS estado, c.descripcion_desempeno AS descripcion
            FROM momentos_academicos m
            LEFT JOIN calificaciones c ON c.momento_id = m.id AND c.estudiante_id = :e
            WHERE m.periodo_id = :p
            ORDER BY m.id
        ");
        $st->execute([':e' => $estudianteId, ':p' => $periodoId]);

        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public function resumenPorPeriodo(int $periodoId): array
    {
        $st = $this->db->prepare("
            SELECT m.nombre AS momento,
                   COALESCE(SUM(c.literal_o_estado = 'Aprobado'), 0)  AS aprobados,
                   COALESCE(SUM(c.literal_o_estado = 'Reprobado'), 0) AS reprobados
            FROM momentos_academicos m
            LEFT JOIN calificaciones c ON c.momento_id = m.id
            WHERE m.periodo_id = :p
            GROUP BY m.id
            ORDER BY m.id
        ");
        $st->execute([':p' => $periodoId]);

        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    private function tiparMomento(array $m): array
    {
        $m['id']         = (int)$m['id'];
        $m['periodo_id'] = (int)$m['periodo_id'];

        return $m;
    }
}
