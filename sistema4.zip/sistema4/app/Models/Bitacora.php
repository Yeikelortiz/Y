<?php
// Bitácora de auditoría 

class Bitacora
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

   public function registrar($usuario_id, $nombre_usuario, $rol_usuario, $accion, $modulo, $descripcion): bool
    {
        try {
            $st = $this->pdo->prepare("
                INSERT INTO bitacora (usuario_id, nombre_usuario, rol_usuario, accion, modulo, descripcion,  fecha_registro)
                VALUES (:usuario_id, :nombre_usuario, :rol_usuario, :accion, :modulo, :descripcion,  NOW())
            ");

            return $st->execute([
                ':usuario_id'     => $usuario_id !== null && $usuario_id !== '' ? (int)$usuario_id : null,
                ':nombre_usuario' => mb_substr((string)$nombre_usuario, 0, 100),
                ':rol_usuario'    => mb_substr((string)$rol_usuario, 0, 50),
                ':accion'         => mb_substr((string)$accion, 0, 50),
                ':modulo'         => mb_substr((string)$modulo, 0, 50),
                ':descripcion'    => mb_substr((string)$descripcion, 0, 5000),
               
            ]);
        } catch (PDOException $e) {
            error_log('[bitacora.registrar] ' . $e->getMessage());
            return false;
        }
    }

    public function obtenerTodas($limite = 150): array
    {
        return $this->listar([], (int)$limite, 0);
    }

    public function listar(array $filtros, int $limite, int $offset = 0): array
    {
        [$where, $params] = $this->condiciones($filtros);

        $st = $this->pdo->prepare(
            'SELECT id, usuario_id, nombre_usuario, rol_usuario, accion, modulo, descripcion, fecha_registro
             FROM bitacora' . $where . ' ORDER BY id DESC LIMIT :limite OFFSET :offset'
        );
        foreach ($params as $clave => $valor) {
            $st->bindValue($clave, $valor, is_int($valor) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $st->bindValue(':limite', max(1, $limite), PDO::PARAM_INT);
        $st->bindValue(':offset', max(0, $offset), PDO::PARAM_INT);
        $st->execute();

        $filas = $st->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['id']         = (int)$fila['id'];
            $fila['usuario_id'] = $fila['usuario_id'] !== null ? (int)$fila['usuario_id'] : null;
        }

        return $filas;
    }

    public function contar(array $filtros): int
    {
        [$where, $params] = $this->condiciones($filtros);

        $st = $this->pdo->prepare('SELECT COUNT(*) FROM bitacora' . $where);
        foreach ($params as $clave => $valor) {
            $st->bindValue($clave, $valor, is_int($valor) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $st->execute();

        return (int)$st->fetchColumn();
    }

    public function catalogos(): array
    {
        $columna = fn(string $sql): array => $this->pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN);

        $usuarios = $this->pdo->query(
            'SELECT usuario_id AS id, MAX(nombre_usuario) AS nombre
             FROM bitacora WHERE usuario_id IS NOT NULL
             GROUP BY usuario_id ORDER BY nombre'
        )->fetchAll(PDO::FETCH_ASSOC);

        return [
            'modulos'  => $columna('SELECT DISTINCT modulo FROM bitacora ORDER BY modulo'),
            'acciones' => $columna('SELECT DISTINCT accion FROM bitacora ORDER BY accion'),
            'roles'    => $columna('SELECT DISTINCT rol_usuario FROM bitacora ORDER BY rol_usuario'),
            'usuarios' => array_map(static fn(array $u): array => ['id' => (int)$u['id'], 'nombre' => $u['nombre']], $usuarios),
        ];
    }

    public function resumen(): array
    {
        $fila = $this->pdo->query("
            SELECT
                COUNT(*) AS total,
                COALESCE(SUM(DATE(fecha_registro) = CURDATE()), 0) AS hoy,
                COALESCE(SUM(DATE(fecha_registro) = CURDATE() AND accion = 'INICIO_SESION'), 0) AS inicios_hoy,
                COALESCE(SUM(accion = 'ELIMINAR'), 0) AS eliminaciones
            FROM bitacora
        ")->fetch(PDO::FETCH_ASSOC);

        return array_map('intval', $fila ?: ['total' => 0, 'hoy' => 0, 'inicios_hoy' => 0, 'eliminaciones' => 0]);
    }

    private function condiciones(array $f): array
    {
        $w = [];
        $p = [];

        if (!empty($f['q'])) {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], (string)$f['q']) . '%';
            $w[] = '(descripcion LIKE :q1 OR nombre_usuario LIKE :q2 OR modulo LIKE :q3 OR accion LIKE :q4 OR rol_usuario LIKE :q5)';
            $p[':q1'] = $p[':q2'] = $p[':q3'] = $p[':q4'] = $p[':q5'] = $like;
        }
        if (!empty($f['modulo'])) {
            $w[] = 'modulo = :modulo';
            $p[':modulo'] = (string)$f['modulo'];
        }
        if (!empty($f['accion'])) {
            $w[] = 'accion = :accion';
            $p[':accion'] = (string)$f['accion'];
        }
        if (!empty($f['rol'])) {
            $w[] = 'rol_usuario = :rol';
            $p[':rol'] = (string)$f['rol'];
        }
        if (!empty($f['usuario'])) {
            $w[] = 'usuario_id = :usuario';
            $p[':usuario'] = (int)$f['usuario'];
        }
        if (!empty($f['desde'])) {
            $w[] = 'fecha_registro >= :desde';
            $p[':desde'] = $f['desde'] . ' 00:00:00';
        }
        if (!empty($f['hasta'])) {
            $w[] = 'fecha_registro < DATE_ADD(:hasta, INTERVAL 1 DAY)';
            $p[':hasta'] = (string)$f['hasta'];
        }

        return [$w ? ' WHERE ' . implode(' AND ', $w) : '', $p];
    }
}