<?php
// Consultas de solo lectura para emitir constancias y boletines (módulo "boletin")

class Documento
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function estudiante(int $id): ?array
    {
        $st = $this->db->prepare("
            SELECT
                e.id, e.cedula_escolar, e.nombres, e.apellidos, e.genero,
                e.fecha_nacimiento, e.registrado_en, e.representante_cedula, e.seccion_id,
                s.grado, s.seccion, s.aula, s.periodo_id,
                p.nombre AS periodo_nombre, p.estado AS periodo_estado,
                CONCAT(d.nombres, ' ', d.apellidos) AS docente_nombre,
                r.nombre AS rep_nombre, r.apellido AS rep_apellido, r.telefono AS rep_telefono
            FROM estudiantes e
            LEFT JOIN secciones      s ON s.id = e.seccion_id
            LEFT JOIN periodos       p ON p.id = s.periodo_id
            LEFT JOIN docentes       d ON d.id = s.docente_id
            LEFT JOIN representantes r ON r.cedula = e.representante_cedula
            WHERE e.id = :id
            LIMIT 1
        ");
        $st->execute([':id' => $id]);
        $fila = $st->fetch(PDO::FETCH_ASSOC);

        if (!$fila) {
            return null;
        }
        $fila['id']         = (int)$fila['id'];
        $fila['seccion_id'] = $fila['seccion_id'] !== null ? (int)$fila['seccion_id'] : null;
        $fila['periodo_id'] = $fila['periodo_id'] !== null ? (int)$fila['periodo_id'] : null;

        return $fila;
    }

    public function estudiantesDeSeccion(int $seccionId): array
    {
        $st = $this->db->prepare("
            SELECT id, cedula_escolar, nombres, apellidos
            FROM estudiantes
            WHERE seccion_id = :s
            ORDER BY apellidos, nombres
        ");
        $st->execute([':s' => $seccionId]);

        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    // Asistencia del estudiante por momento académico dentro del período
    public function asistenciaResumen(int $estudianteId, int $periodoId): array
    {
        $st = $this->db->prepare("
            SELECT m.nombre, a.asistencias, a.inasistencias
            FROM asistencias_momento a
            INNER JOIN momentos_academicos m ON m.id = a.momento_id
            WHERE a.estudiante_id = :e AND m.periodo_id = :p
            ORDER BY m.id
        ");
        $st->execute([':e' => $estudianteId, ':p' => $periodoId]);

        $r = ['momentos' => [], 'asistencias' => 0, 'inasistencias' => 0, 'total' => 0];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $fila) {
            $a = (int)$fila['asistencias'];
            $i = (int)$fila['inasistencias'];
            $r['momentos'][]      = ['nombre' => $fila['nombre'], 'asistencias' => $a, 'inasistencias' => $i];
            $r['asistencias']    += $a;
            $r['inasistencias']  += $i;
            $r['total']          += $a + $i;
        }

        return $r;
    }
}
