<?php
class Representante
{
    private PDO $db;

    private const SELECT_LISTA = "
        SELECT
            r.cedula,
            r.nombre,
            r.apellido,
            r.telefono,
            r.direccion,
            r.registrado_en,
            (SELECT COUNT(*) FROM estudiantes e WHERE e.representante_cedula = r.cedula) AS total_estudiantes
        FROM representantes r
    ";

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function listar(int $limite, int $offset, string $busqueda = ''): array
    {
        [$where, $params] = $this->filtroBusqueda($busqueda);

        $stmt = $this->db->prepare(
            self::SELECT_LISTA . $where . ' ORDER BY r.registrado_en DESC, r.cedula DESC LIMIT :limite OFFSET :offset'
        );
        foreach ($params as $clave => $valor) {
            $stmt->bindValue($clave, $valor, PDO::PARAM_STR);
        }
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['total_estudiantes'] = (int)$fila['total_estudiantes'];
        }

        return $filas;
    }

    public function contar(string $busqueda = ''): int
    {
        [$where, $params] = $this->filtroBusqueda($busqueda);

        $stmt = $this->db->prepare('SELECT COUNT(*) FROM representantes r ' . $where);
        $stmt->execute($params);

        return (int)$stmt->fetchColumn();
    }

    public function obtenerPorCedula(string $cedula): ?array
    {
        $stmt = $this->db->prepare(self::SELECT_LISTA . ' WHERE r.cedula = :cedula LIMIT 1');
        $stmt->execute([':cedula' => $cedula]);

        $rep = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$rep) {
            return null;
        }
        $rep['total_estudiantes'] = (int)$rep['total_estudiantes'];

        return $rep;
    }

    public function existe(string $cedula): bool
    {
        $stmt = $this->db->prepare('SELECT 1 FROM representantes WHERE cedula = :cedula LIMIT 1');
        $stmt->execute([':cedula' => $cedula]);

        return $stmt->fetchColumn() !== false;
    }

    public function obtenerEstudiantes(string $cedula): array
    {
        $sql = "
            SELECT
                e.id,
                e.cedula_escolar,
                e.nombres,
                e.apellidos,
                e.genero,
                e.fecha_nacimiento,
                CASE WHEN e.fecha_nacimiento = '0000-00-00' THEN NULL
                     ELSE TIMESTAMPDIFF(YEAR, e.fecha_nacimiento, CURDATE()) END AS edad,
                e.seccion_id,
                CASE WHEN s.id IS NULL THEN NULL
                     ELSE CONCAT(s.grado, '° Grado - Sección ', s.seccion) END AS seccion_nombre
            FROM estudiantes e
            LEFT JOIN secciones s ON s.id = e.seccion_id
            WHERE e.representante_cedula = :cedula
            ORDER BY e.id ASC
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':cedula' => $cedula]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function crear(array $d): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO representantes (cedula, nombre, apellido, telefono, direccion, num_hijo)
            VALUES (:cedula, :nombre, :apellido, :telefono, :direccion, 0)
        ");

        return $stmt->execute([
            ':cedula'    => $d['cedula'],
            ':nombre'    => $d['nombre'],
            ':apellido'  => $d['apellido'],
            ':telefono'  => $d['telefono'],
            ':direccion' => $d['direccion'],
        ]);
    }

    public function actualizar(string $cedulaOriginal, array $d): bool
    {
        return $this->enTransaccion(function () use ($cedulaOriginal, $d) {
            $stmt = $this->db->prepare("
                UPDATE representantes
                SET cedula = :nueva, nombre = :nombre, apellido = :apellido,
                    telefono = :telefono, direccion = :direccion
                WHERE cedula = :original
            ");
            $stmt->execute([
                ':nueva'     => $d['cedula'],
                ':nombre'    => $d['nombre'],
                ':apellido'  => $d['apellido'],
                ':telefono'  => $d['telefono'],
                ':direccion' => $d['direccion'],
                ':original'  => $cedulaOriginal,
            ]);

            if ($d['cedula'] !== $cedulaOriginal) {
                $stmt = $this->db->prepare("
                    UPDATE estudiantes
                    SET cedula_escolar = CONCAT(:nueva_ce, SUBSTRING(cedula_escolar, :pos))
                    WHERE representante_cedula = :nueva_rep
                      AND cedula_escolar LIKE :patron
                ");
                $stmt->bindValue(':nueva_ce', $d['cedula'], PDO::PARAM_STR);
                $stmt->bindValue(':pos', strlen($cedulaOriginal) + 1, PDO::PARAM_INT);
                $stmt->bindValue(':nueva_rep', $d['cedula'], PDO::PARAM_STR);
                $stmt->bindValue(':patron', $cedulaOriginal . '-%', PDO::PARAM_STR);
                $stmt->execute();
            }

            return true;
        });
    }

    public function eliminar(string $cedula): bool
    {
        $stmt = $this->db->prepare('DELETE FROM representantes WHERE cedula = :cedula');
        $stmt->execute([':cedula' => $cedula]);

        return $stmt->rowCount() > 0;
    }

    // Cada LIKE usa su propio marcador (con EMULATE_PREPARES = false no se pueden repetir)
    private function filtroBusqueda(string $busqueda): array
    {
        if ($busqueda === '') {
            return ['', []];
        }

        $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $busqueda) . '%';

        $where = " WHERE r.cedula LIKE :b1
                      OR r.nombre LIKE :b2
                      OR r.apellido LIKE :b3
                      OR CONCAT(r.nombre, ' ', r.apellido) LIKE :b4
                      OR r.telefono LIKE :b5 ";

        return [$where, [':b1' => $like, ':b2' => $like, ':b3' => $like, ':b4' => $like, ':b5' => $like]];
    }

    private function enTransaccion(callable $operacion)
    {
        if ($this->db->inTransaction()) {
            return $operacion();
        }

        $this->db->beginTransaction();
        try {
            $resultado = $operacion();
            $this->db->commit();
            return $resultado;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }
}
