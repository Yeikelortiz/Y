<?php
// Asistencia por momento académico: por estudiante se guardan los totales de asistencias e inasistencias del momento
class Asistencia
{
    public const MAX_DIAS = 366;

    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    // Momentos de los períodos activos (los que se pueden consultar y registrar)
    public function momentosActivos(): array
    {
        $st = $this->db->query("
            SELECT m.id, m.nombre, m.estado, m.periodo_id, p.nombre AS periodo_nombre
            FROM momentos_academicos m
            INNER JOIN periodos p ON p.id = m.periodo_id
            WHERE p.estado = 'activo'
            ORDER BY p.id DESC, m.id
        ");

        $filas = $st->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['id']         = (int)$fila['id'];
            $fila['periodo_id'] = (int)$fila['periodo_id'];
        }

        return $filas;
    }

    public function momento(int $momentoId): ?array
    {
        $st = $this->db->prepare('SELECT id, periodo_id, nombre, estado FROM momentos_academicos WHERE id = :id');
        $st->execute([':id' => $momentoId]);

        $fila = $st->fetch(PDO::FETCH_ASSOC);
        if (!$fila) {
            return null;
        }
        $fila['id']         = (int)$fila['id'];
        $fila['periodo_id'] = (int)$fila['periodo_id'];

        return $fila;
    }

    // Estudiantes de la sección con lo ya registrado en el momento (NULL = pendiente)
    public function lista(int $seccionId, int $momentoId): array
    {
        $st = $this->db->prepare("
            SELECT
                e.id,
                e.cedula_escolar,
                e.nombres,
                e.apellidos,
                a.asistencias,
                a.inasistencias,
                (a.id IS NOT NULL) AS registrado
            FROM estudiantes e
            LEFT JOIN asistencias_momento a ON a.estudiante_id = e.id AND a.momento_id = :m
            WHERE e.seccion_id = :s
            ORDER BY e.apellidos, e.nombres
        ");
        $st->execute([':m' => $momentoId, ':s' => $seccionId]);

        $filas = $st->fetchAll(PDO::FETCH_ASSOC);
        foreach ($filas as &$fila) {
            $fila['id']            = (int)$fila['id'];
            $fila['registrado']    = (bool)$fila['registrado'];
            $fila['asistencias']   = $fila['registrado'] ? (int)$fila['asistencias'] : null;
            $fila['inasistencias'] = $fila['registrado'] ? (int)$fila['inasistencias'] : null;
        }

        return $filas;
    }

    public function idsEstudiantesDeSeccion(int $seccionId): array
    {
        $st = $this->db->prepare('SELECT id FROM estudiantes WHERE seccion_id = :s');
        $st->execute([':s' => $seccionId]);

        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    public function contarRegistrados(int $seccionId, int $momentoId): int
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM asistencias_momento WHERE seccion_id = :s AND momento_id = :m');
        $st->execute([':s' => $seccionId, ':m' => $momentoId]);

        return (int)$st->fetchColumn();
    }

    // Guarda o actualiza varios estudiantes en una sola transacción.
    // $datos: [estudiante_id => ['asistencias' => int, 'inasistencias' => int]]
    public function guardarLote(int $seccionId, int $momentoId, array $datos): int
    {
        $st = $this->db->prepare("
            INSERT INTO asistencias_momento (estudiante_id, seccion_id, momento_id, asistencias, inasistencias)
            VALUES (:e, :s, :m, :a, :i)
            ON DUPLICATE KEY UPDATE asistencias = VALUES(asistencias), inasistencias = VALUES(inasistencias), seccion_id = VALUES(seccion_id)
        ");

        $this->db->beginTransaction();
        try {
            foreach ($datos as $estudianteId => $d) {
                $st->execute([
                    ':e' => (int)$estudianteId,
                    ':s' => $seccionId,
                    ':m' => $momentoId,
                    ':a' => (int)$d['asistencias'],
                    ':i' => (int)$d['inasistencias'],
                ]);
            }
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return count($datos);
    }

    public function registrosGuardados(int $seccionId, int $limite = 1500): array
    {
        $st = $this->db->prepare("
            SELECT m.nombre AS momento, a.asistencias, a.inasistencias, e.cedula_escolar, e.nombres, e.apellidos
            FROM asistencias_momento a
            INNER JOIN estudiantes e ON e.id = a.estudiante_id
            INNER JOIN momentos_academicos m ON m.id = a.momento_id
            WHERE a.seccion_id = :s
            ORDER BY m.id, e.apellidos, e.nombres
            LIMIT :limite
        ");
        $st->bindValue(':s', $seccionId, PDO::PARAM_INT);
        $st->bindValue(':limite', max(1, $limite), PDO::PARAM_INT);
        $st->execute();

        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
