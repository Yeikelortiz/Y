<?php
class XlsxWriter
{
    private const ESTILOS = [
        'normal'     => 0,
        'negrita'    => 1,
        'titulo'     => 2,
        'encabezado' => 3,
        'dato'       => 4,
        'centro'     => 5,
        'numero'     => 6,
        'porcentaje' => 7,
        'total'      => 8,
        'totalnum'   => 9,
    ];

    private const XML_CONTENT_TYPES = <<<'XML'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>
XML;

    private const XML_RELS = <<<'XML'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>
XML;

    private const XML_WORKBOOK_RELS = <<<'XML'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>
XML;

    private const XML_STYLES = <<<'XML'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="0.0%"/></numFmts><fonts count="4"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="14"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1E293B"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFCBD5E1"/></left><right style="thin"><color rgb="FFCBD5E1"/></right><top style="thin"><color rgb="FFCBD5E1"/></top><bottom style="thin"><color rgb="FFCBD5E1"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="10"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="3" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf><xf numFmtId="1" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf><xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="1" fontId="1" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>
XML;

    private string $nombreHoja;
    private array $filas = [];
    private array $anchos = [];
    private int $filaCongelada = 0;

    public function __construct(string $nombreHoja = 'Reporte')
    {
        $limpio = trim(str_replace(['[', ']', ':', '*', '?', '/', '\\'], ' ', $nombreHoja));
        $this->nombreHoja = mb_substr($limpio !== '' ? $limpio : 'Reporte', 0, 31);
    }

    public function agregarFila(array $celdas, string $estilo = 'normal', int $medir = 0): int
    {
        $base = self::ESTILOS[$estilo] ?? 0;
        $fila = [];

        foreach (array_values($celdas) as $col => $celda) {
            [$valor, $idx] = is_array($celda)
                ? [$celda[0] ?? null, self::ESTILOS[$celda[1] ?? ''] ?? $base]
                : [$celda, $base];

            $fila[$col] = [$valor, $idx];

            if ($medir > 0 && $valor !== null) {
                $largo = min($medir, is_string($valor) ? mb_strlen($valor) : strlen((string)$valor));
                $this->anchos[$col] = max($this->anchos[$col] ?? 0, $largo);
            }
        }

        $this->filas[] = $fila;

        return count($this->filas);
    }

    public function agregarFilaVacia(): void
    {
        $this->filas[] = [];
    }

    // Fija las filas 1..$fila para que no se desplacen (encabezado visible)
    public function congelarHasta(int $fila): void
    {
        $this->filaCongelada = max(0, $fila);
    }

    public function contenido(): string
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('La extensión zip de PHP no está habilitada. Active "extension=zip" en php.ini y reinicie Apache.');
        }

        $ruta = tempnam(sys_get_temp_dir(), 'xlsx');
        $zip  = new ZipArchive();

        if ($zip->open($ruta, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($ruta);
            throw new RuntimeException('No se pudo crear el archivo temporal del Excel.');
        }

        $zip->addFromString('[Content_Types].xml', self::XML_CONTENT_TYPES);
        $zip->addFromString('_rels/.rels', self::XML_RELS);
        $zip->addFromString('xl/workbook.xml', $this->xmlLibro());
        $zip->addFromString('xl/_rels/workbook.xml.rels', self::XML_WORKBOOK_RELS);
        $zip->addFromString('xl/styles.xml', self::XML_STYLES);
        $zip->addFromString('xl/worksheets/sheet1.xml', $this->xmlHoja());
        $zip->close();

        $binario = (string)file_get_contents($ruta);
        @unlink($ruta);

        return $binario;
    }

    public function enviar(string $nombreArchivo): void
    {
        $binario = $this->contenido();

        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $nombreArchivo) . '"');
        header('Content-Length: ' . strlen($binario));
        header('Cache-Control: private, max-age=0, must-revalidate');
        echo $binario;
        exit;
    }

    private function xmlLibro(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . $this->esc($this->nombreHoja) . '" sheetId="1" r:id="rId1"/></sheets></workbook>';
    }

    private function xmlHoja(): string
    {
        $totalFilas = count($this->filas);
        $maxCol     = 0;
        $datos      = '';

        foreach ($this->filas as $i => $celdas) {
            $nFila = $i + 1;
            $datos .= '<row r="' . $nFila . '">';
            foreach ($celdas as $col => [$valor, $idx]) {
                $maxCol = max($maxCol, $col + 1);
                $ref    = self::letra($col) . $nFila;

                if ($valor === null || $valor === '') {
                    $datos .= '<c r="' . $ref . '" s="' . $idx . '"/>';
                } elseif (is_int($valor) || is_float($valor)) {
                    $datos .= '<c r="' . $ref . '" s="' . $idx . '"><v>' . $this->numero($valor) . '</v></c>';
                } else {
                    $datos .= '<c r="' . $ref . '" s="' . $idx . '" t="inlineStr"><is><t xml:space="preserve">'
                        . $this->esc((string)$valor) . '</t></is></c>';
                }
            }
            $datos .= '</row>';
        }

        $dimension = ($totalFilas > 0 && $maxCol > 0) ? 'A1:' . self::letra($maxCol - 1) . $totalFilas : 'A1';

        $vista = '<sheetViews><sheetView workbookViewId="0">';
        if ($this->filaCongelada > 0) {
            $tl = 'A' . ($this->filaCongelada + 1);
            $vista .= '<pane ySplit="' . $this->filaCongelada . '" topLeftCell="' . $tl . '" activePane="bottomLeft" state="frozen"/>'
                    . '<selection pane="bottomLeft" activeCell="' . $tl . '" sqref="' . $tl . '"/>';
        }
        $vista .= '</sheetView></sheetViews>';

        $cols = '';
        if ($this->anchos) {
            ksort($this->anchos);
            $cols = '<cols>';
            foreach ($this->anchos as $col => $largo) {
                $ancho = min(60, max(8, $largo + 3));
                $cols .= '<col min="' . ($col + 1) . '" max="' . ($col + 1) . '" width="' . $ancho . '" customWidth="1"/>';
            }
            $cols .= '</cols>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
            . '<dimension ref="' . $dimension . '"/>'
            . $vista
            . '<sheetFormatPr defaultRowHeight="15"/>'
            . $cols
            . '<sheetData>' . $datos . '</sheetData>'
            . '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
            . '<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/>'
            . '</worksheet>';
    }

    private function esc(string $texto): string
    {
        $texto = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $texto);

        return htmlspecialchars($texto, ENT_XML1 | ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    private function numero($valor): string
    {
        if (is_int($valor)) {
            return (string)$valor;
        }

        return rtrim(rtrim(number_format((float)$valor, 6, '.', ''), '0'), '.') ?: '0';
    }

    private static function letra(int $indice): string
    {
        $n = $indice + 1;
        $letras = '';
        while ($n > 0) {
            $m = ($n - 1) % 26;
            $letras = chr(65 + $m) . $letras;
            $n = intdiv($n - 1, 26);
        }

        return $letras;
    }
}
