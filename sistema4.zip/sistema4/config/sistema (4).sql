-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-10-2026 a las 22:21:18
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Crear la base de datos si no existe y seleccionarla
--
CREATE DATABASE IF NOT EXISTS `sistema` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sistema`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencias_momento`
--

CREATE TABLE `asistencias_momento` (
  `id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `momento_id` int(11) NOT NULL,
  `asistencias` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Días asistidos en el momento',
  `inasistencias` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Días de inasistencia en el momento',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `asistencias_momento`
--

INSERT INTO `asistencias_momento` (`id`, `estudiante_id`, `seccion_id`, `momento_id`, `asistencias`, `inasistencias`, `created_at`, `updated_at`) VALUES
(1, 27, 1, 5, 17, 12, '2026-10-29 02:15:06', '2026-10-29 02:31:58'),
(2, 31, 1, 5, 12, 10, '2026-10-29 02:15:08', '2026-10-29 02:15:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora`
--

CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `rol_usuario` enum('admin','director','secretaria','') NOT NULL,
  `accion` varchar(50) NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bitacora` (Vacío según la solicitud)
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificaciones`
--

CREATE TABLE `calificaciones` (
  `id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `momento_id` int(11) NOT NULL COMMENT '1er, 2do o 3er Momento',
  `literal_o_estado` enum('Aprobado','Reprobado') NOT NULL,
  `descripcion_desempeno` text NOT NULL COMMENT 'Descripción cualitativa del desempeño del alumno',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `calificaciones`
--

INSERT INTO `calificaciones` (`id`, `estudiante_id`, `momento_id`, `literal_o_estado`, `descripcion_desempeno`, `updated_at`) VALUES
(11, 27, 4, 'Aprobado', '', '2026-10-24 11:58:00'),
(12, 27, 5, 'Aprobado', '', '2026-10-27 22:13:16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docentes`
--

CREATE TABLE `docentes` (
  `id` int(11) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` enum('M','F','Otro') NOT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `docentes`
--

INSERT INTO `docentes` (`id`, `cedula`, `nombres`, `apellidos`, `fecha_nacimiento`, `genero`, `direccion`, `telefono`, `correo`, `created_at`) VALUES
(2, '27228534', 'beikel', 'ortiz', '1999-07-03', 'M', 'tocuyito', '04244191962', 'beikell@gmail.com', '2026-10-04 14:18:25'),
(3, '13810664', 'Juan Carlos', 'isaac', '2005-11-04', 'M', 'safari', '04244940553', 'yeikelortizhjhh@gmail.com', '2026-10-15 16:21:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE `estudiantes` (
  `id` int(11) NOT NULL,
  `cedula_escolar` varchar(13) DEFAULT NULL,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `representante_cedula` varchar(12) NOT NULL,
  `registrado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_nacimiento` date NOT NULL,
  `genero` enum('M','F','Otro') NOT NULL,
  `seccion_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`id`, `cedula_escolar`, `nombres`, `apellidos`, `representante_cedula`, `registrado_en`, `fecha_nacimiento`, `genero`, `seccion_id`) VALUES
(27, '129961616-1', 'juan', 'isaac', '129961616', '2026-10-15 16:20:25', '2005-06-30', 'M', 1),
(30, '11816804-1', 'Yeikel Ezequiel', 'ortiz', '11816804', '2026-10-27 21:29:45', '2023-08-05', 'M', 2),
(31, '11816804-2', 'Yeikel Ezequiel', 'Ortiz Baldayo', '11816804', '2026-10-29 02:00:34', '2016-03-11', 'M', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `momentos_academicos`
--

CREATE TABLE `momentos_academicos` (
  `id` int(11) NOT NULL,
  `periodo_id` int(11) NOT NULL COMMENT 'Año escolar al que pertenece',
  `nombre` varchar(50) NOT NULL COMMENT 'Ej: 1er Momento, 2do Momento, 3er Momento',
  `estado` enum('activo','cerrado') NOT NULL DEFAULT 'activo' COMMENT 'RF-10: Cierre por el Director',
  `fecha_cierre` date DEFAULT NULL COMMENT 'Fecha en que el Director cerró el momento (bloquea asistencias hasta esa fecha)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `momentos_academicos`
--

INSERT INTO `momentos_academicos` (`id`, `periodo_id`, `nombre`, `estado`, `fecha_cierre`, `created_at`) VALUES
(4, 1, '1er Momento', 'cerrado', '2026-10-25', '2026-10-07 01:22:50'),
(5, 1, '2do Momento', 'activo', NULL, '2026-10-07 01:22:50'),
(6, 1, '3er Momento', 'activo', NULL, '2026-10-07 01:22:50');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periodos`
--

CREATE TABLE `periodos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `estado` enum('activo','cerrado') NOT NULL DEFAULT 'activo',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `periodos`
--

INSERT INTO `periodos` (`id`, `nombre`, `estado`, `created_at`) VALUES
(1, '2026-2027', 'activo', '2026-10-01 01:26:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representantes`
--

CREATE TABLE `representantes` (
  `cedula` varchar(12) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `direccion` text DEFAULT NULL,
  `num_hijo` int(2) NOT NULL,
  `registrado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `representantes`
--

INSERT INTO `representantes` (`cedula`, `nombre`, `apellido`, `telefono`, `direccion`, `num_hijo`, `registrado_en`) VALUES
('11816804', 'Ezequiel', 'antonio', '04121708833', 'tocuyito', 2, '2026-10-27 21:29:45'),
('129961616', 'luis', 'Perez', '042449551423', 'tocuyito', 1, '2026-10-27 21:00:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secciones`
--

CREATE TABLE `secciones` (
  `id` int(11) NOT NULL,
  `periodo_id` int(11) DEFAULT NULL,
  `grado` tinyint(4) NOT NULL CHECK (`grado` between 1 and 6),
  `seccion` char(1) NOT NULL CHECK (`seccion` in ('A','B')),
  `docente_id` int(11) DEFAULT NULL COMMENT 'Profesor guía o titular de la sección (NULL = sin asignar)',
  `aula` varchar(30) DEFAULT NULL,
  `horario` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `secciones`
--

INSERT INTO `secciones` (`id`, `periodo_id`, `grado`, `seccion`, `docente_id`, `aula`, `horario`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'A', 2, 'Aula 1', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-04 14:34:37'),
(2, 1, 1, 'B', NULL, 'Aula 2', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-27 04:12:41'),
(3, 1, 2, 'A', 3, 'Aula 3', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-26 03:29:59'),
(4, 1, 2, 'B', NULL, 'Aula 4', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(5, 1, 3, 'A', NULL, 'Aula 5', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(6, 1, 3, 'B', NULL, 'Aula 6', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(7, 1, 4, 'A', NULL, 'Aula 7', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(8, 1, 4, 'B', NULL, 'Aula 8', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(9, 1, 5, 'A', NULL, 'Aula 9', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(10, 1, 5, 'B', NULL, 'Aula 10', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(11, 1, 6, 'A', NULL, 'Aula 11', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22'),
(12, 1, 6, 'B', NULL, 'Aula 12', '7:00 AM - 12:00 PM', '2026-10-01 01:50:22', '2026-10-01 01:50:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','director','secretaria') NOT NULL,
  `intentos_fallidos` int(11) DEFAULT 0,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultima_sesion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `rol`, `intentos_fallidos`, `bloqueado_hasta`, `created_at`, `ultima_sesion`) VALUES
(1, 'Juan Pérez', 'usuario@test.com', '$2y$10$tt2eTmFoeAObz.4BYnoIZOtC44zFXrJOz28gtalju7XE.mktyXaze', 'secretaria', 0, NULL, '2026-08-23 20:04:30', '2026-10-22 02:31:12'),
(5, 'Yeikel Ortiz', 'beikel@gmail.com', '$2y$10$NnYfwIDTK8pJ.glv2WQIk.UjmaRnFmWD5LAhnYh39X1oG3Di6yQxe', 'secretaria', 1, NULL, '2026-08-25 00:46:07', '2026-10-06 03:07:16'),
(6, 'Beikel ortiz', 'beikel.13@gmail.com', '$2y$10$.wscOZ58aYLF4qiyKrRTMuiv9uJPHcgKJGzRVasBTv2nJlQD5liJO', 'admin', 0, NULL, '2026-08-25 01:03:54', '2026-10-29 21:06:28'),
(7, 'Beikel ortiz', 'tt@gmail.com', '$2y$10$PzVS8mG.0KPqrb067umhCOLdO7gJVRNTdzN6BG/Y8czSGeywzbsMu', 'director', 0, NULL, '2026-08-25 01:44:00', '2026-10-04 02:02:49'),
(8, 'Yeikel Ortiz', 'yeikel@gmail.com', '$2y$10$bQrPPBOS1aPrauwChA8qm.tIFBJzB0MihHWwBGOvMrR12IErs0Bx2', 'director', 0, NULL, '2026-09-13 15:03:47', '2026-10-29 20:43:51'),
(10, 'Juan Isaac', 'juan@gmail.com', '$2y$10$nFsarZO4Uty7PSfUfocbhuSysTEQ0cAecWS/6QM8fagayfyG9OWOu', 'director', 1, NULL, '2026-09-21 02:43:02', '2026-10-29 03:18:23'),
(11, 'Angel Jesus', 'angel@gmail.com', '$2y$10$7LZbA6WoSIKED92LN4t0luKVUH8k.XLZjsFPgQe9q63tvCfw8MIc2', 'director', 0, NULL, '2026-08-25 01:44:00', '2026-10-04 02:02:49'),
(12, 'Carlosss', 'carlos@gmail.com', '$2y$10$bHuILfT5J2g5rIt0e7dmfODXoypej4axeRFwYLtUWVzBPnYgZQZ.2', 'secretaria', 0, NULL, '2026-09-21 02:49:56', '2026-10-04 02:02:49'),
(14, 'Baldayo', 'baldayo@gmail.com', '$2y$10$/tpaCXrEq0GxPneaNVhzXuPBvrvxQf9GcDKmK5.P5MjjstNdLsgTC', 'secretaria', 0, NULL, '2026-10-04 01:49:45', '2026-10-29 20:47:31'),
(16, 'Luis Yarso', 'luis@gmail.com', '$2y$10$tBgvl2uo9V/5zKfWOkCSKOPWpMJCUbltb3jerLPJgrpPi6XFJ.Bs2', 'director', 0, NULL, '2026-10-20 01:36:17', '2026-10-20 01:36:58'),
(18, 'Yeikel Ortiz', 'yeikelortiz@gmail.com', '$2y$10$t45nRbQFVgb.wPs4UKElNO0BoVgJI4crj04CEdyrcZdmVfFJmH6u2', 'admin', 0, NULL, '2026-10-29 21:07:21', '2026-10-29 21:19:57');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asistencias_momento`
--
ALTER TABLE `asistencias_momento`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_asistencia_estudiante_momento` (`estudiante_id`,`momento_id`),
  ADD KEY `fk_asistencia_seccion` (`seccion_id`),
  ADD KEY `fk_asistencia_momento` (`momento_id`);

--
-- Indices de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_filtros` (`modulo`,`accion`,`fecha_registro`),
  ADD KEY `fk_bitacora_usuario` (`usuario_id`);

--
-- Indices de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_calificacion_estudiante_momento` (`estudiante_id`,`momento_id`),
  ADD KEY `fk_calificacion_momento` (`momento_id`);

--
-- Indices de la tabla `docentes`
--
ALTER TABLE `docentes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cedula` (`cedula`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cedula_escolar_unique` (`cedula_escolar`),
  ADD KEY `seccion_id` (`seccion_id`),
  ADD KEY `estudiantes_representante` (`representante_cedula`);

--
-- Indices de la tabla `momentos_academicos`
--
ALTER TABLE `momentos_academicos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_momento_periodo` (`periodo_id`);

--
-- Indices de la tabla `periodos`
--
ALTER TABLE `periodos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `representantes`
--
ALTER TABLE `representantes`
  ADD PRIMARY KEY (`cedula`);

--
-- Indices de la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_grado_seccion_periodo` (`periodo_id`,`grado`,`seccion`),
  ADD KEY `fk_seccion_profesor` (`docente_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asistencias_momento`
--
ALTER TABLE `asistencias_momento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `bitacora`
--
ALTER TABLE `bitacora`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `docentes`
--
ALTER TABLE `docentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `momentos_academicos`
--
ALTER TABLE `momentos_academicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `periodos`
--
ALTER TABLE `periodos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `secciones`
--
ALTER TABLE `secciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asistencias_momento`
--
ALTER TABLE `asistencias_momento`
  ADD CONSTRAINT `fk_asistencia_estudiante` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_asistencia_momento` FOREIGN KEY (`momento_id`) REFERENCES `momentos_academicos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_asistencia_seccion` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `bitacora`
--
ALTER TABLE `bitacora`
  ADD CONSTRAINT `fk_bitacora_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `fk_calificacion_estudiante` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiantes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_calificacion_momento` FOREIGN KEY (`momento_id`) REFERENCES `momentos_academicos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD CONSTRAINT `estudiantes_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`),
  ADD CONSTRAINT `estudiantes_representante` FOREIGN KEY (`representante_cedula`) REFERENCES `representantes` (`cedula`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_estudiantes_representante` FOREIGN KEY (`representante_cedula`) REFERENCES `representantes` (`cedula`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `momentos_academicos`
--
ALTER TABLE `momentos_academicos`
  ADD CONSTRAINT `fk_momento_periodo` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD CONSTRAINT `fk_seccion_periodo` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`),
  ADD CONSTRAINT `fk_seccion_profesor` FOREIGN KEY (`docente_id`) REFERENCES `docentes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;